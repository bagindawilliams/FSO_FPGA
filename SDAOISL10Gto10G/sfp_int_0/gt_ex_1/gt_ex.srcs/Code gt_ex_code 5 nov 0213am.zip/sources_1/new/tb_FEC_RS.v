`timescale 1ns / 1ps
/*
===========================================================================
Company      : WiComAI Lab, Kookmin University
Engineers    : Williamsyah Baginda Miraj & Giovanni Dwi
Description  : Comprehensive Verification Testbench for FEC Subsystem.
               Includes RS Encoders and the FEC_MUX integration, upgraded to 
               a full End-to-End Pipeline Verification from CDC 1 to CDC 4.

               Verification Objectives:
               1. Prove RS Parity Generation: Observe the 16 additional
                  parity bytes/words naturally appended to the data.
               2. Prove Mathematical Gap: Demonstrate how the 16-cycle gap 
                  between Header and Payload allows for parity computation.
               3. Prove FEC_MUX Splicing: Validate that the output of FEC_MUX
                  is exactly 259 continuous cycles (Zero-Gap) combining 
                  both Header (32B -> 4 Words) and Payload (255 Words).
               4. Prove End-to-End CDC 1 -> GTH -> CDC 4 Pipeline & RS Limit:
                  Trace the 4 standard SDA OISL frames (DAT1, DAT2, IDLE, MGMT)
                  followed by continuous filler IDLE frames ("FILL") across:
                  CDC 1 -> RS Encoder -> FEC_MUX -> Scrambler -> LPC(24,16) ->
                  Preamble + MUX Gearbox 128 -> CDC 2 -> Error Inject ->
                  GTH 64b/66b -> CDC 3 -> Demux 128 -> LPC Decoder ->
                  Descrambler -> FEC_Demux -> RS Decoder -> CDC 4.

Physical Data Geometry Validated:
               - CDC 1 In (312.5 MHz)  : Header 16B (16 clk), Payload 1912B (478 clk)
               - Input Header (RS In)  : 16 Cycles  x 1 Byte = 16 Bytes or 2 Words
               - Input Payload (RS In) : 239 Cycles x 8 Byte = 1912 Bytes or 239 Words 
               - RS Head Out           : 32 Cycles  x 1 Byte = 32 Bytes or 4 Words
               - RS Load Out           : 255 Cycles x 8 Byte = 2040 Bytes or 255 Words
               - MUX / Scrambler Out   : 259 Cycles x 8 Byte = 2072 Bytes (Continuous Out)
               - LPC(24,16) Out        : 259 Cycles x 12 Byte = 3108 Bytes
               - Gearbox 128 / CDC 2/3 : 9B Preamble + 3108B LPC = 3117 Bytes / Frame
               - RX RS Decoder Out     : Header 16B (2 Words), Payload 1912B (239 Words)
               - CDC 4 Out (312.5 MHz) : Header 16B (16 clk), Payload 1912B (478 clk)

Revision History:
  - Rev 1.0 (Initial) : 259-cycle FEC_MUX + RS(32,16) + 8xRS(255,239) geometry testbench.
  - Rev 2.0 (2026-10-27 15:04 KST) : [ETRI Audit Item 2 & Item 3 - SDA OISL Page 37, Sec. 2.6.3.6.3]
    1. Aligned Header byte injection order with SDA OISL Table 2-10 (Page 25):
       d0 (cycle 1) = TXFN[7:0] (LSB), d1 (cycle 2) = TXFN[15:8] (MSB), and 
       d4 (cycle 5) = {4'b1111, ACK, ACK_valid, FRAME_TYPE[1:0]}.
    2. Added an independent Golden-Vector Syndrome Verifier (u_hdr_synd_chk & 
       u_pld_synd_chk_lane7) that evaluates every encoded 32-Byte Header and 
       255-Byte Payload codeword at all 16 roots alpha^(11*j) (j = 120..135) over 
       GF(2^8) primitive polynomial F(x) = x^8 + x^7 + x^2 + x + 1 (0x187) and 
       verifies that all 16 syndromes equal 128'd0!
  - Rev 3.0 (2026-11-04 00:25 KST) : [Master End-to-End CDC 1 to CDC 4 Pipeline & 3-Mode Error Injection]
    1. Integrated the complete TX-to-RX pipeline from Header/Payload Generator 
       and CDC 1 (312.5 MHz -> 200 MHz) through RS Encoder, FEC_MUX, Scrambler, 
       LPC(24,16), Preamble + MUX Gearbox 128, CDC 2 (200 MHz -> 312.5 MHz), 
       Error Injector, GTH 64b/66b MSB-First Loopback, CDC 3 (312.5 MHz -> 200 MHz), 
       Demux Preamble 128, LPC(24,16) Decoder, Descrambler, FEC_Demux, RS Decoder, 
       and CDC 4 (rx_logic_gth, 200 MHz -> 312.5 MHz).
    2. Added selectable parameter 'ERR_INJECT_MODE' (0 = Raw Bypass, 1 = Within RS 
       Capability <= 8 symbols/lane, 2 = Full 48-word error.mem > 8 symbols on Lane 2).
  - Rev 3.1 (2026-11-04 00:45 KST) : [Eliminated Non-Portable Hierarchical Probes for Original RTL]
    1. Removed hierarchical references to 'u_error_inject.applied_zone', 
       'u_error_inject.applied_mask', and 'u_cdc4.*' so the testbench elaborates 
       cleanly against the original WiComAI Lab RTL in 'gt_ex_code'.
    2. Computed 'err_inj_xor_mask' (via pre-injector vs. post-injector FIFO comparison) 
       and 'err_inj_zone_id' (Zone 1: Bytes 1..60, Zone 2: Active XOR region, 
       Zone 3: Pass-through) directly at the testbench port boundary.
===========================================================================
*/

module tb_FEC_RS #(
    // =====================================================================
    // SELECT ERROR INJECTION MODE HERE (0, 1, or 2):
    //   0 = RAW / BYPASS MODE        (0 errors injected -> 0 mismatches)
    //   1 = FEC RECOVERY MODE (<=8)  (16 words / 64B error.mem, <=5 sym/lane <= 8 -> 100% healed by RS!)
    //   2 = EXCEEDS RS LIMIT (>8)    (48 words / 192B error.mem, Lane 2 = 9 sym > 8 -> handoff to ARQ!)
    // =====================================================================
    parameter integer ERR_INJECT_MODE = 1
)();

    // Automatically translates ERR_INJECT_MODE (0, 1, 2) into error_inject parameters:
    //   - Mode 0: INJ_SIM_MODE = 0 (Bypass)
    //   - Mode 1: INJ_SIM_MODE = 1, INJ_MAX_ERROR = 15 (16 rows = 64 Bytes in Zone 2, all lanes <= 8 symbols)
    //   - Mode 2: INJ_SIM_MODE = 1, INJ_MAX_ERROR = 47 (48 rows = 192 Bytes in Zone 2, Lane 2 = 9 > 8 symbols)
    localparam integer INJ_SIM_MODE   = (ERR_INJECT_MODE == 0) ? 0 : 1;
    localparam integer INJ_MAX_ERROR  = (ERR_INJECT_MODE == 1) ? 15 : 47;
    localparam [11:0]  ZONE2_END_BYTE = 12'd60 + ((INJ_MAX_ERROR + 1) * 4);

    // =======================================================
    // 1. SYSTEM CLOCKS AND RESET
    // =======================================================
    reg clk;      // 200.0 MHz Baseband Logic Clock (Period: 5.0 ns)
    reg clk_gth;  // 312.5 MHz GTH / Framer Clock   (Period: 3.2 ns)
    reg rst_n;

    wire clk_logic = clk;

    initial begin
        clk = 1'b0;
        forever #2.5 clk = ~clk;
    end

    initial begin
        clk_gth = 1'b0;
        forever #1.6 clk_gth = ~clk_gth;
    end

    // Readable ASCII Mode Banner for Waveform Display
    wire [127:0] err_inj_mode_str = (ERR_INJECT_MODE == 0) ? "MODE0_RAW_BYPASS" :
                                    (ERR_INJECT_MODE == 1) ? "MODE1_RS_FIX_OK " :
                                                             "MODE2_ARQ_LIMIT ";

    // =======================================================
    // 2. STAGE 1: HEADER & PAYLOAD GENERATOR -> CDC 1 (312.5 MHz)
    // =======================================================
    // Table 2-14 LSB-Packed Telemetry Vector (5,000,000.0 m = 64'h4153_12D0_0000_0000)
    wire [255:0] mgmt_vec = {
        27'd0, 1'b1, 40'd0, 32'd1476000000,
        64'h4153_12D0_0000_0000, 40'd0, 6'd15,
        40'd16678204759, 6'd15
    };

    reg         cdc1_hdr_in_valid = 1'b0;
    reg  [7:0]  cdc1_hdr_in_data  = 8'd0;
    reg         cdc1_pld_in_valid = 1'b0;
    reg  [31:0] cdc1_pld_in_data  = 32'd0;
    reg  [3:0]  cdc1_in_frame_id  = 4'd0; // 1=DAT1, 2=DAT2, 3=IDLE, 4=MGMT, 0=FILL
    reg  [31:0] cdc1_in_frame_str = "WAIT";

    reg  [4:0]  r_cdc1_hdr_in_clk = 5'd0;
    reg  [8:0]  r_cdc1_pld_in_clk = 9'd0;
    always @(posedge clk_gth or negedge rst_n) begin
        if (!rst_n) begin
            r_cdc1_hdr_in_clk <= 5'd0;
            r_cdc1_pld_in_clk <= 9'd0;
        end else begin
            r_cdc1_hdr_in_clk <= cdc1_hdr_in_valid ? (r_cdc1_hdr_in_clk + 5'd1) : 5'd0;
            r_cdc1_pld_in_clk <= cdc1_pld_in_valid ? (r_cdc1_pld_in_clk + 9'd1) : 9'd0;
        end
    end
    wire [4:0]  cdc1_hdr_in_clk_cnt  = cdc1_hdr_in_valid ? (r_cdc1_hdr_in_clk + 5'd1) : 5'd0;              // 1..16 Clocks
    wire [4:0]  cdc1_hdr_in_byte_cnt = cdc1_hdr_in_clk_cnt;                                                // 1..16 Bytes
    wire [8:0]  cdc1_pld_in_clk_cnt  = cdc1_pld_in_valid ? (r_cdc1_pld_in_clk + 9'd1) : 9'd0;              // 1..478 Clocks
    wire [11:0] cdc1_pld_in_byte_cnt = cdc1_pld_in_valid ? ({3'd0, cdc1_pld_in_clk_cnt} * 12'd4) : 12'd0;  // 4..1912 Bytes

    // Helper functions for deterministic Table 2-10 Header & Table 2-18/2-14 Payload
    function [7:0] get_oisl_header_byte(input integer f_idx, input integer b_idx);
        reg [7:0] txfn_lsb;
        begin
            txfn_lsb = f_idx[7:0];
            case (b_idx)
                1:  get_oisl_header_byte = txfn_lsb; // d0: TXFN[7:0] (LSB)
                2:  get_oisl_header_byte = 8'h00;    // d1: TXFN[15:8] (MSB)
                3:  get_oisl_header_byte = 8'hCD;    // d2: RXFN[7:0] (0xABCD)
                4:  get_oisl_header_byte = 8'hAB;    // d3: RXFN[15:8]
                5:  get_oisl_header_byte = (f_idx == 1 || f_idx == 2) ? 8'hFD :
                                           (f_idx == 4)               ? 8'hF2 : 8'hF0; // d4: Frame Type
                6:  get_oisl_header_byte = 8'h55;    // d5: TX_TS[7:0]
                7:  get_oisl_header_byte = 8'h44;    // d6: TX_TS[15:8]
                8:  get_oisl_header_byte = 8'h33;    // d7: TX_TS[23:16]
                9:  get_oisl_header_byte = 8'h22;    // d8: TX_TS[31:24]
                10: get_oisl_header_byte = 8'h11;    // d9: TX_TS[39:32]
                11: get_oisl_header_byte = 8'hF2;    // d10: Reserved=11, TOD_SECONDS=50
                12: get_oisl_header_byte = 8'h8A;    // d11: Reserved=1, TS_applies=0, FCCH=0xA
                13: get_oisl_header_byte = 8'h88;    // d12: FCCH_PL[7:0]
                14: get_oisl_header_byte = 8'h99;    // d13: FCCH_PL[15:8]
                15: get_oisl_header_byte = 8'h0F;    // d14: CRC-16[15:8] (MSB)
                16: get_oisl_header_byte = 8'h28;    // d15: CRC-16[7:0]  (LSB)
                default: get_oisl_header_byte = 8'h55;
            endcase
        end
    endfunction

    function [63:0] get_oisl_payload_word64(input integer f_idx, input integer w_idx);
        begin
            if (f_idx == 1) begin
                // Frame 1 (DAT1): First 1,900B of 2,000B Jumbo Packet + "Kookmin FSO "
                if      (w_idx == 1)   get_oisl_payload_word64 = 64'hAB00_0000_CDEF_07D0;
                else if (w_idx == 2)   get_oisl_payload_word64 = 64'hAABB_CCDD_EEFF_1122;
                else if (w_idx == 7)   get_oisl_payload_word64 = 64'h4B6F_6F6B_6D69_6E20; // "Kookmin "
                else if (w_idx == 8)   get_oisl_payload_word64 = 64'h4653_4F20_AAAA_000E; // "FSO "
                else if (w_idx == 239) get_oisl_payload_word64 = 64'hAAAA_01DC_C320_0001; // CRC-32 Tail
                else                   get_oisl_payload_word64 = {32'hAAAA_0000 + w_idx[31:0], 32'hBBBB_0000 + w_idx[31:0]};
            end else if (f_idx == 2) begin
                // Frame 2 (DAT2): Table 2-18 Continuation (0xAB004064) + 100B Data (FCS 0xDEADBEEF) + 1,804B Zero Pad
                if      (w_idx == 1)   get_oisl_payload_word64 = 64'hAB00_4064_AAAA_0001;
                else if (w_idx == 13)  get_oisl_payload_word64 = 64'hAAAA_0018_DEAD_BEEF; // 100th Byte Eth FCS at 32b Word 26
                else if (w_idx == 239) get_oisl_payload_word64 = 64'h0000_0000_C320_0002; // CRC-32 Tail
                else if (w_idx > 13)   get_oisl_payload_word64 = 64'd0;                   // 1,804B Zero Padding
                else                   get_oisl_payload_word64 = {32'hAAAA_0100 + w_idx[31:0], 32'hBBBB_0100 + w_idx[31:0]};
            end else if (f_idx == 4) begin
                // Frame 4 (MGMT): Table 2-14 Satellite Range 5,000 km (0x415312D000000000)
                if      (w_idx == 1)   get_oisl_payload_word64 = {mgmt_vec[31:0],    mgmt_vec[63:32]};
                else if (w_idx == 2)   get_oisl_payload_word64 = {mgmt_vec[95:64],   mgmt_vec[127:96]};
                else if (w_idx == 3)   get_oisl_payload_word64 = {mgmt_vec[159:128], mgmt_vec[191:160]};
                else if (w_idx == 4)   get_oisl_payload_word64 = {mgmt_vec[223:192], mgmt_vec[255:224]};
                else if (w_idx == 239) get_oisl_payload_word64 = 64'h0000_0000_C320_0004;
                else                   get_oisl_payload_word64 = 64'd0;
            end else begin
                // Frame 3 (IDLE) & Post-Frame-4 Continuous Filler IDLEs ("FILL")
                if      (w_idx == 239) get_oisl_payload_word64 = 64'h1D1E_1D1E_C320_0000 + f_idx[7:0];
                else                   get_oisl_payload_word64 = 64'h1D1E_1D1E_1D1E_1D1E ^ {48'd0, w_idx[15:0]};
            end
        end
    endfunction

    // 312.5 MHz Upstream Generator feeding CDC 1 (4 Target Frames + 2 Filler IDLE Frames)
    integer gth_f, gth_w;
    reg [63:0] cur_pld64;
    initial begin
        wait(rst_n == 1'b1);
        repeat (5) @(posedge clk_gth);
        for (gth_f = 1; gth_f <= 6; gth_f = gth_f + 1) begin
            for (gth_w = 1; gth_w <= 478; gth_w = gth_w + 1) begin
                @(posedge clk_gth);
                cdc1_in_frame_id  <= (gth_f <= 4) ? gth_f[3:0] : 4'd0;
                cdc1_in_frame_str <= (gth_f == 1) ? "DAT1" :
                                     (gth_f == 2) ? "DAT2" :
                                     (gth_f == 3) ? "IDLE" :
                                     (gth_f == 4) ? "MGMT" : "FILL";
                if (gth_w <= 16) begin
                    cdc1_hdr_in_valid <= 1'b1;
                    cdc1_hdr_in_data  <= get_oisl_header_byte(gth_f, gth_w);
                end else begin
                    cdc1_hdr_in_valid <= 1'b0;
                    cdc1_hdr_in_data  <= 8'd0;
                end

                cdc1_pld_in_valid <= 1'b1;
                cur_pld64         = get_oisl_payload_word64(gth_f, (gth_w + 1) / 2);
                cdc1_pld_in_data  <= (gth_w[0] == 1'b1) ? cur_pld64[63:32] : cur_pld64[31:0];
            end
            @(posedge clk_gth);
            cdc1_hdr_in_valid <= 1'b0;
            cdc1_hdr_in_data  <= 8'd0;
            cdc1_pld_in_valid <= 1'b0;
            cdc1_pld_in_data  <= 32'd0;
            cdc1_in_frame_str <= "WAIT";
            repeat (300) @(posedge clk_gth);
        end
    end

    // =======================================================
    // 3. DEVICE UNDER TEST (DUT) SIGNALS (TX -> GTH -> RX -> CDC 4)
    // =======================================================
    reg         en_head;
    reg  [7:0]  header_in;
    reg         en_load;
    reg  [63:0] payload_in;

    wire        rs_head_dv;
    wire [7:0]  rs_head_out;
    wire        rs_load_dv;
    wire [63:0] rs_load_out;

    wire        mux_dv;
    wire [63:0] mux_data_out;

    // Stage 4..6 TX Scrambler, LPC(24,16), Preamble & Gearbox 128 Signals
    wire        scr_dv;
    wire [63:0] scr_data_out;
    wire        lpc_dv;
    wire [95:0] lpc_data_out;
    wire [71:0] preamble_72b;
    wire        gbx_dv;
    wire [127:0] gbx_data_out;
    wire [15:0]  gbx_keep_out;

    // Stage 7..10 CDC 2, Error Injector, GTH 64b/66b & CDC 3 Signals
    reg          cdc2_out_valid = 1'b0;
    reg  [31:0]  cdc2_out_data  = 32'd0;
    wire         err_inj_out_valid;
    wire [31:0]  err_inj_out_data;

    // Bit-Reversal Function for Optical MSB-First GTH Serialization (Slides 78 & 80)
    function [31:0] bit_reverse_32(input [31:0] d_in);
        integer bi;
        begin
            for (bi = 0; bi < 32; bi = bi + 1)
                bit_reverse_32[bi] = d_in[31 - bi];
        end
    endfunction

    reg          gth_tx_valid       = 1'b0;
    reg  [31:0]  gth_tx_line_data   = 32'd0; // Bit-reversed optical stream (0x77AD5B58 -> 0x1ADAB5EE)
    reg          gth_rx_valid       = 1'b0;
    reg  [31:0]  gth_rx_data        = 32'd0; // Restored MSB-first 32-bit stream (0x77AD5B58)

    reg          cdc3_out_valid     = 1'b0;
    reg  [127:0] cdc3_out_data      = 128'd0;

    // Stage 11..15 RX Core (Demux 128 -> LPC Dec -> Descrambler -> FEC Demux -> RS Decoders)
    reg          rx_demux_lpc_valid    = 1'b0;
    reg  [95:0]  rx_demux_lpc_data     = 96'd0;
    reg  [71:0]  rx_preamble_extracted = 72'd0;
    wire         rx_lpc_dec_out_valid;
    wire [63:0]  rx_lpc_dec_out_data;
    wire         rx_desc_out_valid;
    wire [63:0]  rx_desc_out_data;

    wire         rx_rs_hdr_out_valid;
    wire [7:0]   rx_rs_hdr_out_data;
    wire         rx_rs_pld_out_valid;
    wire [63:0]  rx_rs_pld_out_data;
    wire         rx_preamble_locked;

    // Internal FEC_Demux -> RS Decoder inputs inside u_core_rx
    wire         rx_rs_hdr_in_valid = u_core_rx.rs_head_dv;
    wire [7:0]   rx_rs_hdr_in_data  = u_core_rx.rs_head;
    wire         rx_rs_pld_in_valid = u_core_rx.rs_load_dv;
    wire [63:0]  rx_rs_pld_in_data  = u_core_rx.rs_load;

    // Stage 16 CDC 4 (rx_logic_gth: 200.0 MHz -> 312.5 MHz) Signals
    wire         cdc4_hdr_out_valid;
    wire [7:0]   cdc4_hdr_out_data;
    wire         cdc4_pld_out_valid;
    wire [31:0]  cdc4_pld_out_data;

    // =======================================================
    // 4. DUT INSTANTIATIONS (ALL VERIFIED PRODUCTION MODULES)
    // =======================================================

    // 4.1 TX RS(32,16) Header Encoder & RS(255,239) Payload Encoder + FEC_MUX
    rs_encoder #(31) u_rs_head (
        .clk        (clk), 
        .rst_n      (rst_n), 
        .en         (en_head), 
        .data_in    (header_in),
        .flag       (rs_head_dv), 
        .data_out   (rs_head_out)
    );

    rs_encoder_64 #(254) u_rs_payload (
        .clk        (clk), 
        .rst_n      (rst_n), 
        .en         (en_load), 
        .data_in    (payload_in),
        .flag       (rs_load_dv), 
        .data_out   (rs_load_out)
    );

    FEC_MUX u_fec_mux (
        .clk        (clk), 
        .rst_n      (rst_n), 
        .rs_head_dv (rs_head_dv), 
        .rs_head    (rs_head_out),
        .rs_load_dv (rs_load_dv), 
        .rs_load    (rs_load_out),
        .flag       (mux_dv), 
        .data_out   (mux_data_out)
    );

    // [Rev 2.0] Independent Golden-Vector Syndrome Checkers over GF(0x187), roots j=120..135
    wire         hdr_synd_done;
    wire [127:0] hdr_syndrome_vec;
    wire         pld_synd_done;
    wire [127:0] pld_syndrome_vec;

    syndrome_unit #(.max(31)) u_hdr_synd_chk (
        .clk      (clk),
        .rst_n    (rst_n),
        .en       (rs_head_dv),
        .data_in  (rs_head_out),
        .flag     (hdr_synd_done),
        .syndrome (hdr_syndrome_vec)
    );

    syndrome_unit #(.max(254)) u_pld_synd_chk_lane7 (
        .clk      (clk),
        .rst_n    (rst_n),
        .en       (rs_load_dv),
        .data_in  (rs_load_out[63:56]),
        .flag     (pld_synd_done),
        .syndrome (pld_syndrome_vec)
    );

    // 4.2 TX 25-bit PRBS Scrambler (Seed 25'h0000007) & LPC(24,16) Encoder Top
    scrambler u_scrambler (
        .clk      (clk),
        .rst_n    (rst_n),
        .en       (mux_dv),
        .data_in  (mux_data_out),
        .flag     (scr_dv),
        .data_out (scr_data_out)
    );

    lpc_top u_lpc_top (
        .clk      (clk),
        .rst_n    (rst_n),
        .en       (scr_dv),
        .data_in  (scr_data_out),
        .flag     (lpc_dv),
        .data_out (lpc_data_out)
    );

    // 4.3 TX 72-bit Preamble Generator (72'h77AD5B5843641E2E26) & 128-bit MUX Gearbox (3,117B)
    preamble_gen u_preamble_gen (
        .preamble_out (preamble_72b)
    );

    mux_gearbox_128 u_mux_gearbox (
        .clk           (clk),
        .rst_n         (rst_n),
        .preamble_data (preamble_72b),
        .lpc_data      (lpc_data_out),
        .lpc_valid     (lpc_dv),
        .cdc_data      (gbx_data_out),
        .cdc_valid     (gbx_dv),
        .cdc_keep      (gbx_keep_out)
    );

    // 4.4 Channel Error Injector (Selectable Mode 0, 1, or 2)
    error_inject #(
        .SIM_MODE   (INJ_SIM_MODE),
        .safe_words (15),
        .max_error  (INJ_MAX_ERROR)
    ) u_error_inject (
        clk_gth,
        rst_n,
        cdc2_out_valid,
        cdc2_out_data,
        err_inj_out_valid,
        err_inj_out_data
    );

    // 4.5 RX LPC(24,16) Decoder & 25-bit Descrambler Stage Monitors (200 MHz)
    lpc_dec_top u_rx_lpc_dec_mon (
        .clk      (clk),
        .rst_n    (rst_n),
        .en       (rx_demux_lpc_valid),
        .data_in  (rx_demux_lpc_data),
        .flag     (rx_lpc_dec_out_valid),
        .data_out (rx_lpc_dec_out_data)
    );

    descrambler u_rx_descrambler_mon (
        .clk      (clk),
        .rst_n    (rst_n),
        .en       (rx_lpc_dec_out_valid),
        .data_in  (rx_lpc_dec_out_data),
        .flag     (rx_desc_out_valid),
        .data_out (rx_desc_out_data)
    );

    // 4.6 Full Receive Baseband FEC Core (Demux 128 + LPC Dec + Descrambler + FEC_Demux + RS Decoders)
    core_rx u_core_rx (
        clk,
        rst_n,
        cdc3_out_valid,
        cdc3_out_data,
        rx_rs_hdr_out_valid,
        rx_rs_hdr_out_data,
        rx_rs_pld_out_valid,
        rx_rs_pld_out_data,
        rx_preamble_locked
    );

    // 4.7 Clock Domain Crossing 4 (rx_logic_gth: 200.0 MHz -> 312.5 MHz)
    rx_logic_gth u_cdc4 (
        .clk_gth    (clk_gth),
        .clk_logic  (clk_logic),
        .rst_n      (rst_n),
        .en_head    (rx_rs_hdr_out_valid),
        .en_load    (rx_rs_pld_out_valid),
        .header_in  (rx_rs_hdr_out_data),
        .payload_in (rx_rs_pld_out_data),
        .header_dv  (cdc4_hdr_out_valid),
        .header     (cdc4_hdr_out_data),
        .payload_dv (cdc4_pld_out_valid),
        .payload    (cdc4_pld_out_data)
    );

    // =======================================================
    // 5. CDC 1 OUTPUT SCHEDULER (4 TARGET FRAMES + 2 FILLER IDLE FRAMES)
    // =======================================================
    localparam ST_WAIT_CDC4 = 3'd0;
    localparam ST_HEAD      = 3'd1;
    localparam ST_MATH_GAP  = 3'd2;
    localparam ST_LOAD      = 3'd3;
    localparam ST_FRAME_GAP = 3'd4;
    localparam ST_DONE      = 3'd5;

    reg [2:0]  tb_state;
    reg [3:0]  frame_id;       // 1..4 for Target Frames (DAT1, DAT2, IDLE, MGMT), 0 for Filler IDLE
    reg [3:0]  raw_frame_seq;  // 1..6 (Frames 5 & 6 are continuous Filler IDLEs per Sec. 2.6.3.5.1)
    reg [15:0] cycle_cnt;

    initial begin
        rst_n         = 1'b0;
        tb_state      = ST_WAIT_CDC4;
        frame_id      = 4'd0;
        raw_frame_seq = 4'd1;
        cycle_cnt     = 16'd1;
        #100;
        rst_n         = 1'b1;
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            tb_state      <= ST_WAIT_CDC4;
            frame_id      <= 4'd0;
            raw_frame_seq <= 4'd1;
            cycle_cnt     <= 16'd1;
        end else begin
            case (tb_state)
                ST_WAIT_CDC4: begin
                    // Wait 40 cycles after reset so CDC 4 async FIFOs are ready
                    if (cycle_cnt < 16'd40)
                        cycle_cnt <= cycle_cnt + 16'd1;
                    else begin
                        tb_state      <= ST_HEAD;
                        raw_frame_seq <= 4'd1;
                        frame_id      <= 4'd1;
                        cycle_cnt     <= 16'd1;
                    end
                end
                ST_HEAD: begin
                    if (cycle_cnt < 16'd16)
                        cycle_cnt <= cycle_cnt + 16'd1;
                    else begin
                        tb_state  <= ST_MATH_GAP;
                        cycle_cnt <= 16'd1;
                    end
                end
                ST_MATH_GAP: begin
                    // 16 Cycles latency gap for RS(32,16) Header Parity
                    if (cycle_cnt < 16'd16)
                        cycle_cnt <= cycle_cnt + 16'd1;
                    else begin
                        tb_state  <= ST_LOAD;
                        cycle_cnt <= 16'd1;
                    end
                end
                ST_LOAD: begin
                    if (cycle_cnt < 16'd239)
                        cycle_cnt <= cycle_cnt + 16'd1;
                    else begin
                        tb_state  <= ST_FRAME_GAP;
                        cycle_cnt <= 16'd1;
                    end
                end
                ST_FRAME_GAP: begin
                    // Rate-matching interval between 200 MHz frames
                    if (cycle_cnt < 16'd340)
                        cycle_cnt <= cycle_cnt + 16'd1;
                    else begin
                        if (raw_frame_seq < 4'd6) begin
                            raw_frame_seq <= raw_frame_seq + 4'd1;
                            frame_id      <= (raw_frame_seq + 4'd1 <= 4'd4) ? (raw_frame_seq + 4'd1) : 4'd0;
                            tb_state      <= ST_HEAD;
                            cycle_cnt     <= 16'd1;
                        end else begin
                            tb_state  <= ST_DONE;
                            frame_id  <= 4'd0;
                            cycle_cnt <= 16'd0;
                        end
                    end
                end
                default: tb_state <= ST_DONE;
            endcase
        end
    end

    // CDC 1 Output Stimulus (16B Header + 239W Payload per Frame)
    always @(*) begin
        en_head    = 1'b0;
        header_in  = 8'd0;
        en_load    = 1'b0;
        payload_in = 64'd0;

        if (rst_n && (tb_state == ST_HEAD)) begin
            en_head   = 1'b1;
            header_in = get_oisl_header_byte(raw_frame_seq, cycle_cnt);
        end else if (rst_n && (tb_state == ST_LOAD)) begin
            en_load    = 1'b1;
            payload_in = get_oisl_payload_word64(raw_frame_seq, cycle_cnt);
        end
    end

    // =======================================================
    // 6. CDC 2, ERROR INJECT, GTH 64B/66B & CDC 3 TRANSPORT
    // =======================================================
    reg [7:0]  cdc2_byte_fifo [0:32767];
    integer    cdc2_wr_ptr = 0;
    integer    cdc2_rd_ptr = 0;

    reg [7:0]  cdc3_byte_fifo [0:32767];
    integer    cdc3_wr_ptr = 0;
    integer    cdc3_rd_ptr = 0;

    reg [7:0]  demux_mon_fifo [0:32767];
    integer    demux_mon_wr_ptr   = 0;
    integer    demux_mon_rd_ptr   = 0;
    integer    demux_mon_word_idx = 0;

    // Self-contained pre-injector clean word FIFO to compute err_inj_xor_mask without hierarchical probes
    reg [31:0] inj_clean_word_fifo [0:8191];
    integer    inj_clean_wr_ptr = 0;
    integer    inj_clean_rd_ptr = 0;

    // 6.1 Unpack 128-bit MUX Gearbox Output (16B on 0xFFFF, 13B on 0x1FFF) into CDC 2 Async Buffer
    integer b_gbx;
    always @(posedge clk) begin
        if (rst_n && gbx_dv) begin
            for (b_gbx = 0; b_gbx < 16; b_gbx = b_gbx + 1) begin
                if (b_gbx < ((gbx_keep_out == 16'h1FFF) ? 13 : 16)) begin
                    cdc2_byte_fifo[cdc2_wr_ptr] = gbx_data_out[127 - 8*b_gbx -: 8];
                    cdc2_wr_ptr = cdc2_wr_ptr + 1;
                end
            end
        end
    end

    // 6.2 CDC 2 Read Side (312.5 MHz, 32-bit Continuous Optical Stream -> Error Injector -> GTH TX/RX)
    reg     cdc2_stream_started = 1'b0;
    integer b_cdc2;
    always @(posedge clk_gth or negedge rst_n) begin
        if (!rst_n) begin
            cdc2_stream_started <= 1'b0;
            cdc2_out_valid      <= 1'b0;
            cdc2_out_data       <= 32'd0;
            gth_tx_valid        <= 1'b0;
            gth_tx_line_data    <= 32'd0;
            gth_rx_valid        <= 1'b0;
            gth_rx_data         <= 32'd0;
            inj_clean_wr_ptr    <= 0;
            inj_clean_rd_ptr    <= 0;
        end else begin
            // Wait until Frame 1 (3,117B) is buffered in CDC 2
            if (!cdc2_stream_started && (cdc2_wr_ptr - cdc2_rd_ptr >= 3117))
                cdc2_stream_started <= 1'b1;

            if (cdc2_stream_started && (cdc2_wr_ptr - cdc2_rd_ptr >= 4)) begin
                cdc2_out_valid <= 1'b1;
                for (b_cdc2 = 0; b_cdc2 < 4; b_cdc2 = b_cdc2 + 1)
                    cdc2_out_data[31 - 8*b_cdc2 -: 8] <= cdc2_byte_fifo[cdc2_rd_ptr + b_cdc2];
                cdc2_rd_ptr = cdc2_rd_ptr + 4;
            end else begin
                cdc2_out_valid <= 1'b0;
                cdc2_out_data  <= 32'd0;
            end

            // Record every clean 32-bit word entering u_error_inject
            if (cdc2_out_valid) begin
                inj_clean_word_fifo[inj_clean_wr_ptr] <= cdc2_out_data;
                inj_clean_wr_ptr <= inj_clean_wr_ptr + 1;
            end
            if (err_inj_out_valid) begin
                inj_clean_rd_ptr <= inj_clean_rd_ptr + 1;
            end

            // GTH TX (Bit-Reversal so MSB is transmitted first optically, Slide 78)
            gth_tx_valid     <= err_inj_out_valid;
            gth_tx_line_data <= err_inj_out_valid ? bit_reverse_32(err_inj_out_data) : 32'd0;

            // GTH RX (Optical Loopback & Bit-Reversal Restoration, Slide 80)
            gth_rx_valid     <= gth_tx_valid;
            gth_rx_data      <= gth_tx_valid ? bit_reverse_32(gth_tx_line_data) : 32'd0;

            // Push restored GTH RX bytes into CDC 3 Async Buffer
            if (gth_rx_valid) begin
                for (b_cdc2 = 0; b_cdc2 < 4; b_cdc2 = b_cdc2 + 1) begin
                    cdc3_byte_fifo[cdc3_wr_ptr] = gth_rx_data[31 - 8*b_cdc2 -: 8];
                    cdc3_wr_ptr = cdc3_wr_ptr + 1;
                    demux_mon_fifo[demux_mon_wr_ptr] = gth_rx_data[31 - 8*b_cdc2 -: 8];
                    demux_mon_wr_ptr = demux_mon_wr_ptr + 1;
                end
            end
        end
    end

    // 6.3 CDC 3 Read Side (200.0 MHz, 128-bit Deserialized Stream into core_rx)
    integer b_cdc3;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            cdc3_out_valid        <= 1'b0;
            cdc3_out_data         <= 128'd0;
            rx_demux_lpc_valid    <= 1'b0;
            rx_demux_lpc_data     <= 96'd0;
            rx_preamble_extracted <= 72'd0;
        end else begin
            if (cdc3_wr_ptr - cdc3_rd_ptr >= 16) begin
                cdc3_out_valid <= 1'b1;
                for (b_cdc3 = 0; b_cdc3 < 16; b_cdc3 = b_cdc3 + 1)
                    cdc3_out_data[127 - 8*b_cdc3 -: 8] <= cdc3_byte_fifo[cdc3_rd_ptr + b_cdc3];
                cdc3_rd_ptr = cdc3_rd_ptr + 16;
            end else begin
                cdc3_out_valid <= 1'b0;
                cdc3_out_data  <= 128'd0;
            end

            // Stage-Aligned Demux Monitor (Extracts 9B Preamble + 259 x 12B LPC Words once 3,117B buffered)
            if (demux_mon_word_idx == 0) begin
                if (demux_mon_wr_ptr - demux_mon_rd_ptr >= 3117) begin
                    for (b_cdc3 = 0; b_cdc3 < 9; b_cdc3 = b_cdc3 + 1)
                        rx_preamble_extracted[71 - 8*b_cdc3 -: 8] <= demux_mon_fifo[demux_mon_rd_ptr + b_cdc3];
                    demux_mon_rd_ptr = demux_mon_rd_ptr + 9;

                    rx_demux_lpc_valid <= 1'b1;
                    for (b_cdc3 = 0; b_cdc3 < 12; b_cdc3 = b_cdc3 + 1)
                        rx_demux_lpc_data[95 - 8*b_cdc3 -: 8] <= demux_mon_fifo[demux_mon_rd_ptr + b_cdc3];
                    demux_mon_rd_ptr   = demux_mon_rd_ptr + 12;
                    demux_mon_word_idx = 1;
                end else begin
                    rx_demux_lpc_valid <= 1'b0;
                    rx_demux_lpc_data  <= 96'd0;
                end
            end else if (demux_mon_word_idx < 259) begin
                rx_demux_lpc_valid <= 1'b1;
                for (b_cdc3 = 0; b_cdc3 < 12; b_cdc3 = b_cdc3 + 1)
                    rx_demux_lpc_data[95 - 8*b_cdc3 -: 8] <= demux_mon_fifo[demux_mon_rd_ptr + b_cdc3];
                demux_mon_rd_ptr   = demux_mon_rd_ptr + 12;
                demux_mon_word_idx = demux_mon_word_idx + 1;
            end else begin
                rx_demux_lpc_valid <= 1'b0;
                rx_demux_lpc_data  <= 96'd0;
                demux_mon_word_idx = 0;
            end
        end
    end

    // =======================================================
    // 7. COMPLETE ZERO-LAG WAVEFORM COUNTERS (CLOCK, WORD, & BYTE)
    // =======================================================

    // Frame Type String Indicator (DAT1, DAT2, IDLE, MGMT, FILL, DONE)
    reg [31:0] mux_frame_type_str;
    always @(*) begin
        if      (frame_id == 4'd1)      mux_frame_type_str = "DAT1";
        else if (frame_id == 4'd2)      mux_frame_type_str = "DAT2";
        else if (frame_id == 4'd3)      mux_frame_type_str = "IDLE";
        else if (frame_id == 4'd4)      mux_frame_type_str = "MGMT";
        else if (raw_frame_seq >= 4'd5) mux_frame_type_str = "FILL";
        else                            mux_frame_type_str = "DONE";
    end

    // --- 7.1 TX RS ENCODER INPUT TRACKERS (CLOCK, WORD, & BYTE) ---
    wire [4:0]  tx_rs_hdr_in_clk_cnt  = en_head ? cycle_cnt[4:0] : 5'd0;                        // 1..16 Clocks
    wire [2:0]  tx_rs_hdr_in_word_cnt = en_head ? (((cycle_cnt[4:0] - 5'd1) >> 3) + 3'd1) : 3'd0;// 1..2 Words (RS Word)
    wire [4:0]  tx_rs_hdr_in_byte_cnt = tx_rs_hdr_in_clk_cnt;                                   // 1..16 Bytes
    wire [4:0]  in_header_byte_idx    = tx_rs_hdr_in_byte_cnt;
    wire [2:0]  in_header_word_idx    = tx_rs_hdr_in_word_cnt;

    wire [8:0]  tx_rs_pld_in_clk_cnt  = en_load ? cycle_cnt[8:0] : 9'd0;                        // 1..239 Clocks
    wire [8:0]  tx_rs_pld_in_word_cnt = tx_rs_pld_in_clk_cnt;                                   // 1..239 Words (RS Word)
    wire [11:0] tx_rs_pld_in_byte_cnt = en_load ? (cycle_cnt[11:0] * 12'd8) : 12'd0;            // 8..1912 Bytes
    wire [8:0]  in_payload_word_idx   = tx_rs_pld_in_word_cnt;
    wire [11:0] in_payload_byte_idx   = tx_rs_pld_in_byte_cnt;

    // --- 7.2 TX RS ENCODER OUTPUT TRACKERS (CLOCK, WORD, & BYTE) ---
    reg [5:0] r_rs_head_cnt = 0;
    reg [8:0] r_rs_load_cnt = 0;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            r_rs_head_cnt <= 6'd0;
            r_rs_load_cnt <= 9'd0;
        end else begin
            r_rs_head_cnt <= rs_head_dv ? (r_rs_head_cnt + 6'd1) : 6'd0;
            r_rs_load_cnt <= rs_load_dv ? (r_rs_load_cnt + 9'd1) : 9'd0;
        end
    end
    wire [5:0]  tx_rs_hdr_out_clk_cnt  = rs_head_dv ? (r_rs_head_cnt + 6'd1) : 6'd0;             // 1..32 Clocks
    wire [2:0]  tx_rs_hdr_out_word_cnt = rs_head_dv ? ((r_rs_head_cnt >> 3) + 3'd1) : 3'd0;      // 1..4 Words (RS Word)
    wire [5:0]  tx_rs_hdr_out_byte_cnt = tx_rs_hdr_out_clk_cnt;                                  // 1..32 Bytes
    wire [5:0]  rs_head_out_byte_idx   = tx_rs_hdr_out_byte_cnt;
    wire [2:0]  rs_head_out_word_idx   = tx_rs_hdr_out_word_cnt;

    wire [8:0]  tx_rs_pld_out_clk_cnt  = rs_load_dv ? (r_rs_load_cnt + 9'd1) : 9'd0;             // 1..255 Clocks
    wire [8:0]  tx_rs_pld_out_word_cnt = tx_rs_pld_out_clk_cnt;                                  // 1..255 Words (RS Word)
    wire [11:0] tx_rs_pld_out_byte_cnt = rs_load_dv ? ({3'd0, tx_rs_pld_out_clk_cnt} * 12'd8) : 12'd0; // 8..2040 Bytes
    wire [8:0]  rs_load_out_word_idx   = tx_rs_pld_out_word_cnt;
    wire [11:0] rs_load_out_byte_idx   = tx_rs_pld_out_byte_cnt;

    // --- 7.3 FEC MUX, SCRAMBLER, LPC ENCODER, & GEARBOX 128 COUNTERS (CLOCK & BYTE) ---
    reg [8:0]  r_mux_cnt = 0;
    reg [8:0]  r_scr_cnt = 0;
    reg [8:0]  r_lpc_cnt = 0;
    reg [7:0]  r_gbx_cnt = 0;
    reg [11:0] r_gbx_bytes = 0;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            r_mux_cnt   <= 9'd0;
            r_scr_cnt   <= 9'd0;
            r_lpc_cnt   <= 9'd0;
            r_gbx_cnt   <= 8'd0;
            r_gbx_bytes <= 12'd0;
        end else begin
            r_mux_cnt <= mux_dv ? (r_mux_cnt + 9'd1) : 9'd0;
            r_scr_cnt <= scr_dv ? (r_scr_cnt + 9'd1) : 9'd0;
            r_lpc_cnt <= lpc_dv ? (r_lpc_cnt + 9'd1) : 9'd0;
            if (gbx_dv) begin
                if (gbx_keep_out == 16'h1FFF) begin
                    r_gbx_cnt   <= 8'd0;
                    r_gbx_bytes <= 12'd0;
                end else begin
                    r_gbx_cnt   <= r_gbx_cnt + 8'd1;
                    r_gbx_bytes <= r_gbx_bytes + 12'd16;
                end
            end else begin
                r_gbx_cnt   <= 8'd0;
                r_gbx_bytes <= 12'd0;
            end
        end
    end

    wire [8:0]  fec_mux_out_clk_cnt    = mux_dv ? (r_mux_cnt + 9'd1) : 9'd0;                      // 1..259 Clocks
    wire [11:0] fec_mux_out_byte_cnt   = mux_dv ? ({3'd0, fec_mux_out_clk_cnt} * 12'd8) : 12'd0;  // 8..2072 Bytes
    wire [8:0]  mux_out_word_idx       = fec_mux_out_clk_cnt;
    wire [11:0] mux_out_byte_idx       = fec_mux_out_byte_cnt;

    wire [8:0]  scrambler_out_clk_cnt  = scr_dv ? (r_scr_cnt + 9'd1) : 9'd0;                      // 1..259 Clocks
    wire [11:0] scrambler_out_byte_cnt = scr_dv ? ({3'd0, scrambler_out_clk_cnt} * 12'd8) : 12'd0;// 8..2072 Bytes

    wire [8:0]  lpc_enc_out_clk_cnt    = lpc_dv ? (r_lpc_cnt + 9'd1) : 9'd0;                      // 1..259 Clocks
    wire [11:0] lpc_enc_out_byte_cnt   = lpc_dv ? ({3'd0, lpc_enc_out_clk_cnt} * 12'd12) : 12'd0; // 12..3108 Bytes

    wire [7:0]  gearbox_out_clk_cnt    = gbx_dv ? (r_gbx_cnt + 8'd1) : 8'd0;                      // 1..195 Clocks
    wire [11:0] gearbox_out_byte_cnt   = gbx_dv ? (r_gbx_bytes + ((gbx_keep_out == 16'h1FFF) ? 12'd13 : 12'd16)) : 12'd0; // 16..3117 Bytes

    // --- 7.4 CDC 2, ERROR INJECTOR, GTH TX/RX & TABLE 2-4 METRICS (312.5 MHz) ---
    reg  [15:0] r_cdc2_byte_acc = 16'd0;
    reg  [15:0] r_inj_byte_acc  = 16'd0;
    reg  [15:0] r_gth_byte_acc  = 16'd0;
    always @(posedge clk_gth or negedge rst_n) begin
        if (!rst_n) begin
            r_cdc2_byte_acc <= 16'd0;
            r_inj_byte_acc  <= 16'd0;
            r_gth_byte_acc  <= 16'd0;
        end else begin
            if (cdc2_out_valid)    r_cdc2_byte_acc <= (r_cdc2_byte_acc + 16'd4 >= 16'd3117) ? 16'd0 : (r_cdc2_byte_acc + 16'd4);
            if (err_inj_out_valid) r_inj_byte_acc  <= (r_inj_byte_acc  + 16'd4 >= 16'd3117) ? 16'd0 : (r_inj_byte_acc  + 16'd4);
            if (gth_rx_valid)      r_gth_byte_acc  <= (r_gth_byte_acc  + 16'd4 >= 16'd3117) ? 16'd0 : (r_gth_byte_acc  + 16'd4);
        end
    end

    wire [11:0] cdc2_out_byte_cnt    = cdc2_out_valid    ? ((r_cdc2_byte_acc + 16'd4 >= 16'd3117) ? 12'd3117 : (r_cdc2_byte_acc[11:0] + 12'd4)) : 12'd0;
    wire [9:0]  cdc2_out_clk_cnt     = cdc2_out_valid    ? ((r_cdc2_byte_acc >> 2) + 10'd1) : 10'd0;
    wire [11:0] err_inj_out_byte_cnt = err_inj_out_valid ? ((r_inj_byte_acc  + 16'd4 >= 16'd3117) ? 12'd3117 : (r_inj_byte_acc[11:0]  + 12'd4)) : 12'd0;
    wire [9:0]  err_inj_out_clk_cnt  = err_inj_out_valid ? ((r_inj_byte_acc  >> 2) + 10'd1) : 10'd0;
    wire [11:0] gth_rx_out_byte_cnt  = gth_rx_valid      ? ((r_gth_byte_acc  + 16'd4 >= 16'd3117) ? 12'd3117 : (r_gth_byte_acc[11:0]  + 12'd4)) : 12'd0;
    wire [9:0]  gth_rx_out_clk_cnt   = gth_rx_valid      ? ((r_gth_byte_acc  >> 2) + 10'd1) : 10'd0;

    // [Rev 3.1] Self-Contained Error Injector Mask & Zone Probes (No Hierarchical References)
    wire [31:0] err_inj_xor_mask = err_inj_out_valid ? (err_inj_out_data ^ inj_clean_word_fifo[inj_clean_rd_ptr]) : 32'd0;
    wire [1:0]  err_inj_zone_id  = !err_inj_out_valid                  ? 2'd0 :
                                   (err_inj_out_byte_cnt <= 12'd60)    ? 2'd1 :
                                   ((INJ_SIM_MODE == 1) && (err_inj_out_byte_cnt <= ZONE2_END_BYTE)) ? 2'd2 : 2'd3;
    wire [63:0] err_inj_zone_str = (err_inj_zone_id == 2'd1) ? "ZONE1_OK" :
                                   (err_inj_zone_id == 2'd2) ? "ZONE2_XO" :
                                   (err_inj_zone_id == 2'd3) ? "ZONE3_OK" : "IDLE    ";

    // SDA OISL Table 2-4 Real-Time Line Rate Metrics (Matches Slides 10 & 73)
    real OISL_Frame_Duration_us       = 2.4936000000004;
    real OISL_Effective_Data_Rate_Mbps = 6121.27045235795;
    real OISL_Frame_Rate_kHz          = 401.026628168105;
    real OISL_FCCH_Mbps               = 6.41642605068968;

    // --- 7.5 RX DEMUX 128, LPC DECODER, & DESCRAMBLER COUNTERS (CLOCK & BYTE) ---
    reg [8:0] r_rx_demux_cnt   = 9'd0;
    reg [8:0] r_rx_lpc_dec_cnt = 9'd0;
    reg [8:0] r_rx_desc_cnt    = 9'd0;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            r_rx_demux_cnt   <= 9'd0;
            r_rx_lpc_dec_cnt <= 9'd0;
            r_rx_desc_cnt    <= 9'd0;
        end else begin
            r_rx_demux_cnt   <= rx_demux_lpc_valid   ? (r_rx_demux_cnt   + 9'd1) : 9'd0;
            r_rx_lpc_dec_cnt <= rx_lpc_dec_out_valid ? (r_rx_lpc_dec_cnt + 9'd1) : 9'd0;
            r_rx_desc_cnt    <= rx_desc_out_valid    ? (r_rx_desc_cnt    + 9'd1) : 9'd0;
        end
    end

    wire [8:0]  rx_lpc_dec_in_clk_cnt   = rx_demux_lpc_valid   ? (r_rx_demux_cnt + 9'd1) : 9'd0;                   // 1..259 Clocks
    wire [11:0] rx_lpc_dec_in_byte_cnt  = rx_demux_lpc_valid   ? ({3'd0, rx_lpc_dec_in_clk_cnt} * 12'd12) : 12'd0;  // 12..3108 Bytes

    wire [8:0]  rx_lpc_dec_out_clk_cnt  = rx_lpc_dec_out_valid ? (r_rx_lpc_dec_cnt + 9'd1) : 9'd0;                  // 1..259 Clocks
    wire [11:0] rx_lpc_dec_out_byte_cnt = rx_lpc_dec_out_valid ? ({3'd0, rx_lpc_dec_out_clk_cnt} * 12'd8) : 12'd0;  // 8..2072 Bytes

    wire [8:0]  rx_desc_out_clk_cnt     = rx_desc_out_valid    ? (r_rx_desc_cnt + 9'd1) : 9'd0;                     // 1..259 Clocks
    wire [11:0] rx_desc_out_byte_cnt    = rx_desc_out_valid    ? ({3'd0, rx_desc_out_clk_cnt} * 12'd8) : 12'd0;     // 8..2072 Bytes

    // --- 7.6 RX RS DECODER INPUT & OUTPUT COUNTERS (CLOCK, WORD, & BYTE) ---
    reg [5:0] r_rx_rs_hdr_in_cnt  = 6'd0;
    reg [5:0] r_rx_rs_hdr_out_cnt = 6'd0;
    reg [8:0] r_rx_rs_pld_in_cnt  = 9'd0;
    reg [8:0] r_rx_rs_pld_out_cnt = 9'd0;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            r_rx_rs_hdr_in_cnt  <= 6'd0;
            r_rx_rs_hdr_out_cnt <= 6'd0;
            r_rx_rs_pld_in_cnt  <= 9'd0;
            r_rx_rs_pld_out_cnt <= 9'd0;
        end else begin
            r_rx_rs_hdr_in_cnt  <= rx_rs_hdr_in_valid  ? (r_rx_rs_hdr_in_cnt  + 6'd1) : 6'd0;
            r_rx_rs_hdr_out_cnt <= rx_rs_hdr_out_valid ? (r_rx_rs_hdr_out_cnt + 6'd1) : 6'd0;
            r_rx_rs_pld_in_cnt  <= rx_rs_pld_in_valid  ? (r_rx_rs_pld_in_cnt  + 9'd1) : 9'd0;
            r_rx_rs_pld_out_cnt <= rx_rs_pld_out_valid ? (r_rx_rs_pld_out_cnt + 9'd1) : 9'd0;
        end
    end

    // RX RS(32,16) Header Decoder In (32B / 4W) & Out (16B / 2W)
    wire [5:0]  rx_rs_hdr_in_clk_cnt   = rx_rs_hdr_in_valid  ? (r_rx_rs_hdr_in_cnt + 6'd1)        : 6'd0; // 1..32 Clocks
    wire [2:0]  rx_rs_hdr_in_word_cnt  = rx_rs_hdr_in_valid  ? ((r_rx_rs_hdr_in_cnt >> 3) + 3'd1) : 3'd0; // 1..4 Words (RS Word)
    wire [5:0]  rx_rs_hdr_in_byte_cnt  = rx_rs_hdr_in_clk_cnt;                                            // 1..32 Bytes

    wire [5:0]  rx_rs_hdr_out_clk_cnt  = rx_rs_hdr_out_valid ? (r_rx_rs_hdr_out_cnt + 6'd1)        : 6'd0;// 1..16 Clocks
    wire [2:0]  rx_rs_hdr_out_word_cnt = rx_rs_hdr_out_valid ? ((r_rx_rs_hdr_out_cnt >> 3) + 3'd1) : 3'd0;// 1..2 Words (RS Word)
    wire [5:0]  rx_rs_hdr_out_byte_cnt = rx_rs_hdr_out_clk_cnt;                                           // 1..16 Bytes

    // RX RS(255,239) Payload Decoder In (2040B / 255W) & Out (1912B / 239W)
    wire [8:0]  rx_rs_pld_in_clk_cnt   = rx_rs_pld_in_valid  ? (r_rx_rs_pld_in_cnt + 9'd1) : 9'd0;        // 1..255 Clocks
    wire [8:0]  rx_rs_pld_in_word_cnt  = rx_rs_pld_in_clk_cnt;                                            // 1..255 Words (RS Word)
    wire [11:0] rx_rs_pld_in_byte_cnt  = rx_rs_pld_in_valid  ? ({3'd0, rx_rs_pld_in_clk_cnt} * 12'd8) : 12'd0; // 8..2040 Bytes

    wire [8:0]  rx_rs_pld_out_clk_cnt  = rx_rs_pld_out_valid ? (r_rx_rs_pld_out_cnt + 9'd1) : 9'd0;       // 1..239 Clocks
    wire [8:0]  rx_rs_pld_out_word_cnt = rx_rs_pld_out_clk_cnt;                                           // 1..239 Words (RS Word)
    wire [11:0] rx_rs_pld_out_byte_cnt = rx_rs_pld_out_valid ? ({3'd0, rx_rs_pld_out_clk_cnt} * 12'd8) : 12'd0;// 8..1912 Bytes

    // --- 7.7 CDC 4 OUTPUT COUNTERS & FIELD EXTRACTORS (312.5 MHz, SELF-CONTAINED) ---
    reg [4:0]  r_cdc4_hdr_out_cnt = 5'd0;
    reg [8:0]  r_cdc4_pld_out_cnt = 9'd0;
    reg [3:0]  cdc4_out_frame_seq = 4'd0;
    reg        cdc4_pld_dv_d1     = 1'b0;

    always @(posedge clk_gth or negedge rst_n) begin
        if (!rst_n) begin
            r_cdc4_hdr_out_cnt <= 5'd0;
            r_cdc4_pld_out_cnt <= 9'd0;
            cdc4_out_frame_seq <= 4'd0;
            cdc4_pld_dv_d1     <= 1'b0;
        end else begin
            r_cdc4_hdr_out_cnt <= cdc4_hdr_out_valid ? (r_cdc4_hdr_out_cnt + 5'd1) : 5'd0;
            r_cdc4_pld_out_cnt <= cdc4_pld_out_valid ? (r_cdc4_pld_out_cnt + 9'd1) : 9'd0;
            cdc4_pld_dv_d1     <= cdc4_pld_out_valid;
            if (cdc4_pld_out_valid && !cdc4_pld_dv_d1)
                cdc4_out_frame_seq <= cdc4_out_frame_seq + 4'd1;
        end
    end

    wire [4:0]  cdc4_hdr_out_clk_cnt  = cdc4_hdr_out_valid ? (r_cdc4_hdr_out_cnt + 5'd1) : 5'd0;                  // 1..16 Clocks
    wire [4:0]  cdc4_hdr_out_byte_cnt = cdc4_hdr_out_clk_cnt;                                                     // 1..16 Bytes
    wire [8:0]  cdc4_pld_out_clk_cnt  = cdc4_pld_out_valid ? (r_cdc4_pld_out_cnt + 9'd1) : 9'd0;                  // 1..478 Clocks
    wire [11:0] cdc4_pld_out_byte_cnt = cdc4_pld_out_valid ? ({1'd0, cdc4_pld_out_clk_cnt, 2'b00}) : 12'd0;       // 4..1912 Bytes

    wire [3:0]  cur_cdc4_seq       = (cdc4_pld_out_valid && !cdc4_pld_dv_d1) ? (cdc4_out_frame_seq + 4'd1) : cdc4_out_frame_seq;
    wire [3:0]  cdc4_out_frame_id  = (cdc4_hdr_out_valid || cdc4_pld_out_valid) ? ((cur_cdc4_seq <= 4'd4) ? cur_cdc4_seq : 4'd0) : 4'd0;
    wire [31:0] cdc4_out_frame_str = !(cdc4_hdr_out_valid || cdc4_pld_out_valid) ? "WAIT" :
                                     (cur_cdc4_seq == 4'd1) ? "DAT1" :
                                     (cur_cdc4_seq == 4'd2) ? "DAT2" :
                                     (cur_cdc4_seq == 4'd3) ? "IDLE" :
                                     (cur_cdc4_seq == 4'd4) ? "MGMT" : "FILL";

    // Port-Aligned SDA OISL Field Extractors at CDC 4 Output
    reg  [7:0]  cdc4_hdr_buf [0:15];
    reg  [15:0] cdc4_TXFN        = 16'd0;
    reg  [1:0]  cdc4_FRAME_TYPE  = 2'd0;
    reg  [15:0] cdc4_HDR_CRC16   = 16'd0;
    reg  [95:0] cdc4_ASCII_TAG   = 96'd0;
    reg  [31:0] cdc4_ETH_FCS     = 32'd0;
    reg  [63:0] cdc4_MGMT_RANGE  = 64'd0;
    reg  [3:0]  mgmt_lo4_lat     = 4'd0;
    reg  [31:0] mgmt_mid32_lat   = 32'd0;

    always @(posedge clk_gth) if (rst_n) begin
        if (cdc4_hdr_out_valid) begin
            cdc4_hdr_buf[cdc4_hdr_out_byte_cnt - 5'd1] <= cdc4_hdr_out_data;
            if (cdc4_hdr_out_byte_cnt == 5'd2)  cdc4_TXFN       <= {cdc4_hdr_out_data, cdc4_hdr_buf[0]};
            if (cdc4_hdr_out_byte_cnt == 5'd5)  cdc4_FRAME_TYPE <= cdc4_hdr_out_data[1:0];
            if (cdc4_hdr_out_byte_cnt == 5'd16) cdc4_HDR_CRC16  <= {cdc4_hdr_buf[14], cdc4_hdr_out_data};
        end
        if (cdc4_pld_out_valid) begin
            if (cdc4_pld_out_clk_cnt == 9'd13 && cur_cdc4_seq == 4'd1) cdc4_ASCII_TAG[95:64] <= cdc4_pld_out_data;
            if (cdc4_pld_out_clk_cnt == 9'd14 && cur_cdc4_seq == 4'd1) cdc4_ASCII_TAG[63:32] <= cdc4_pld_out_data;
            if (cdc4_pld_out_clk_cnt == 9'd15 && cur_cdc4_seq == 4'd1) cdc4_ASCII_TAG[31:0]  <= cdc4_pld_out_data;
            if (cdc4_pld_out_clk_cnt == 9'd26 && cur_cdc4_seq == 4'd2) cdc4_ETH_FCS          <= cdc4_pld_out_data;
            if (cdc4_pld_out_clk_cnt == 9'd3)                          mgmt_lo4_lat          <= cdc4_pld_out_data[31:28];
            if (cdc4_pld_out_clk_cnt == 9'd4)                          mgmt_mid32_lat        <= cdc4_pld_out_data;
            if (cdc4_pld_out_clk_cnt == 9'd5  && cur_cdc4_seq == 4'd4) cdc4_MGMT_RANGE       <= {cdc4_pld_out_data[27:0], mgmt_mid32_lat, mgmt_lo4_lat};
        end
    end

    // =======================================================
    // 8. PER-LANE RS(255,239) SYMBOL ERROR TRACKER & SCOREBOARD
    // =======================================================
    wire [3:0]  rs_max_correctable_symbols = 4'd8; // Mathematical limit t = (255-239)/2 = 8 symbols/lane

    reg  [7:0]  tx_hdr_cw_queue   [0:511];
    reg  [63:0] tx_pld_cw_queue   [0:2047];
    integer     tx_hdr_cw_wr = 0, rx_hdr_cw_rd = 0;
    integer     tx_pld_cw_wr = 0, rx_pld_cw_rd = 0;

    reg  [7:0]  tx_orig_hdr_queue [0:255];
    reg  [63:0] tx_orig_pld_queue [0:2047];
    integer     tx_orig_hdr_wr = 0, rx_orig_hdr_rd = 0;
    integer     tx_orig_pld_wr = 0, rx_orig_pld_rd = 0;

    reg  [4:0]  rs_hdr_symbol_err_cnt   = 5'd0;
    reg  [4:0]  rs_lane0_symbol_err_cnt = 5'd0;
    reg  [4:0]  rs_lane1_symbol_err_cnt = 5'd0;
    reg  [4:0]  rs_lane2_symbol_err_cnt = 5'd0;
    reg  [4:0]  rs_lane3_symbol_err_cnt = 5'd0;
    reg  [4:0]  rs_lane4_symbol_err_cnt = 5'd0;
    reg  [4:0]  rs_lane5_symbol_err_cnt = 5'd0;
    reg  [4:0]  rs_lane6_symbol_err_cnt = 5'd0;
    reg  [4:0]  rs_lane7_symbol_err_cnt = 5'd0;

    wire        rs_all_lanes_within_t8_limit = (rs_lane0_symbol_err_cnt <= 5'd8) &&
                                               (rs_lane1_symbol_err_cnt <= 5'd8) &&
                                               (rs_lane2_symbol_err_cnt <= 5'd8) &&
                                               (rs_lane3_symbol_err_cnt <= 5'd8) &&
                                               (rs_lane4_symbol_err_cnt <= 5'd8) &&
                                               (rs_lane5_symbol_err_cnt <= 5'd8) &&
                                               (rs_lane6_symbol_err_cnt <= 5'd8) &&
                                               (rs_lane7_symbol_err_cnt <= 5'd8);

    wire [63:0] rs_lane_status_str = rs_all_lanes_within_t8_limit ? "ALL_<=8 " : "LN2_>8! ";

    integer     rs_corrected_symbol_cnt = 0;
    integer     rs_uncorrected_word_cnt = 0;
    integer     decoded_hdr_ok_cnt      = 0;
    integer     decoded_pld_ok_cnt      = 0;

    always @(posedge clk) if (rst_n) begin
        // Record original TX Header/Payload & RS Codewords
        if (en_head)    begin tx_orig_hdr_queue[tx_orig_hdr_wr] = header_in;   tx_orig_hdr_wr = tx_orig_hdr_wr + 1; end
        if (en_load)    begin tx_orig_pld_queue[tx_orig_pld_wr] = payload_in;  tx_orig_pld_wr = tx_orig_pld_wr + 1; end
        if (rs_head_dv) begin tx_hdr_cw_queue[tx_hdr_cw_wr]     = rs_head_out; tx_hdr_cw_wr   = tx_hdr_cw_wr   + 1; end
        if (rs_load_dv) begin tx_pld_cw_queue[tx_pld_cw_wr]     = rs_load_out; tx_pld_cw_wr   = tx_pld_cw_wr   + 1; end

        // Count symbol errors entering RX RS(32,16) Header Decoder
        if (rx_rs_hdr_in_valid) begin
            if (rx_rs_hdr_in_clk_cnt == 6'd1)
                rs_hdr_symbol_err_cnt = (rx_rs_hdr_in_data !== tx_hdr_cw_queue[rx_hdr_cw_rd]) ? 5'd1 : 5'd0;
            else if (rx_rs_hdr_in_data !== tx_hdr_cw_queue[rx_hdr_cw_rd])
                rs_hdr_symbol_err_cnt = rs_hdr_symbol_err_cnt + 5'd1;
            rx_hdr_cw_rd = rx_hdr_cw_rd + 1;
        end

        // Count symbol errors per lane (Lanes 0..7) entering RX RS(255,239) Payload Decoder
        if (rx_rs_pld_in_valid) begin
            if (rx_rs_pld_in_clk_cnt == 9'd1) begin
                rs_lane0_symbol_err_cnt = (rx_rs_pld_in_data[7:0]   !== tx_pld_cw_queue[rx_pld_cw_rd][7:0])   ? 5'd1 : 5'd0;
                rs_lane1_symbol_err_cnt = (rx_rs_pld_in_data[15:8]  !== tx_pld_cw_queue[rx_pld_cw_rd][15:8])  ? 5'd1 : 5'd0;
                rs_lane2_symbol_err_cnt = (rx_rs_pld_in_data[23:16] !== tx_pld_cw_queue[rx_pld_cw_rd][23:16]) ? 5'd1 : 5'd0;
                rs_lane3_symbol_err_cnt = (rx_rs_pld_in_data[31:24] !== tx_pld_cw_queue[rx_pld_cw_rd][31:24]) ? 5'd1 : 5'd0;
                rs_lane4_symbol_err_cnt = (rx_rs_pld_in_data[39:32] !== tx_pld_cw_queue[rx_pld_cw_rd][39:32]) ? 5'd1 : 5'd0;
                rs_lane5_symbol_err_cnt = (rx_rs_pld_in_data[47:40] !== tx_pld_cw_queue[rx_pld_cw_rd][47:40]) ? 5'd1 : 5'd0;
                rs_lane6_symbol_err_cnt = (rx_rs_pld_in_data[55:48] !== tx_pld_cw_queue[rx_pld_cw_rd][55:48]) ? 5'd1 : 5'd0;
                rs_lane7_symbol_err_cnt = (rx_rs_pld_in_data[63:56] !== tx_pld_cw_queue[rx_pld_cw_rd][63:56]) ? 5'd1 : 5'd0;
            end else begin
                if (rx_rs_pld_in_data[7:0]   !== tx_pld_cw_queue[rx_pld_cw_rd][7:0])   rs_lane0_symbol_err_cnt = rs_lane0_symbol_err_cnt + 5'd1;
                if (rx_rs_pld_in_data[15:8]  !== tx_pld_cw_queue[rx_pld_cw_rd][15:8])  rs_lane1_symbol_err_cnt = rs_lane1_symbol_err_cnt + 5'd1;
                if (rx_rs_pld_in_data[23:16] !== tx_pld_cw_queue[rx_pld_cw_rd][23:16]) rs_lane2_symbol_err_cnt = rs_lane2_symbol_err_cnt + 5'd1;
                if (rx_rs_pld_in_data[31:24] !== tx_pld_cw_queue[rx_pld_cw_rd][31:24]) rs_lane3_symbol_err_cnt = rs_lane3_symbol_err_cnt + 5'd1;
                if (rx_rs_pld_in_data[39:32] !== tx_pld_cw_queue[rx_pld_cw_rd][39:32]) rs_lane4_symbol_err_cnt = rs_lane4_symbol_err_cnt + 5'd1;
                if (rx_rs_pld_in_data[47:40] !== tx_pld_cw_queue[rx_pld_cw_rd][47:40]) rs_lane5_symbol_err_cnt = rs_lane5_symbol_err_cnt + 5'd1;
                if (rx_rs_pld_in_data[55:48] !== tx_pld_cw_queue[rx_pld_cw_rd][55:48]) rs_lane6_symbol_err_cnt = rs_lane6_symbol_err_cnt + 5'd1;
                if (rx_rs_pld_in_data[63:56] !== tx_pld_cw_queue[rx_pld_cw_rd][63:56]) rs_lane7_symbol_err_cnt = rs_lane7_symbol_err_cnt + 5'd1;
            end
            rx_pld_cw_rd = rx_pld_cw_rd + 1;
        end

        // Verify Decoded RX Header & Payload across the 4 Target Frames (64B Header, 956W Payload)
        if (rx_rs_hdr_out_valid && rx_orig_hdr_rd < 64) begin
            if (rx_rs_hdr_out_data === tx_orig_hdr_queue[rx_orig_hdr_rd])
                decoded_hdr_ok_cnt = decoded_hdr_ok_cnt + 1;
            rx_orig_hdr_rd = rx_orig_hdr_rd + 1;
        end

        if (rx_rs_pld_out_valid && rx_orig_pld_rd < 956) begin
            if (rx_rs_pld_out_data === tx_orig_pld_queue[rx_orig_pld_rd])
                decoded_pld_ok_cnt = decoded_pld_ok_cnt + 1;
            else
                rs_uncorrected_word_cnt = rs_uncorrected_word_cnt + 1;
            rx_orig_pld_rd = rx_orig_pld_rd + 1;

            if (rx_orig_pld_rd % 239 == 0) begin
                rs_corrected_symbol_cnt = rs_corrected_symbol_cnt +
                    ((rs_lane0_symbol_err_cnt <= 8) ? rs_lane0_symbol_err_cnt : 0) +
                    ((rs_lane1_symbol_err_cnt <= 8) ? rs_lane1_symbol_err_cnt : 0) +
                    ((rs_lane2_symbol_err_cnt <= 8) ? rs_lane2_symbol_err_cnt : 0) +
                    ((rs_lane3_symbol_err_cnt <= 8) ? rs_lane3_symbol_err_cnt : 0) +
                    ((rs_lane4_symbol_err_cnt <= 8) ? rs_lane4_symbol_err_cnt : 0) +
                    ((rs_lane5_symbol_err_cnt <= 8) ? rs_lane5_symbol_err_cnt : 0) +
                    ((rs_lane6_symbol_err_cnt <= 8) ? rs_lane6_symbol_err_cnt : 0) +
                    ((rs_lane7_symbol_err_cnt <= 8) ? rs_lane7_symbol_err_cnt : 0);
            end
        end
    end

    // [Rev 2.0] Syndrome Verification Counters (Proves GF(0x187) & roots j=120..135)
    integer hdr_synd_pass_cnt = 0;
    integer pld_synd_pass_cnt = 0;
    always @(posedge clk) begin
        if (hdr_synd_done && hdr_synd_pass_cnt < 4) begin
            if (hdr_syndrome_vec == 128'd0) hdr_synd_pass_cnt = hdr_synd_pass_cnt + 1;
        end
        if (pld_synd_done && pld_synd_pass_cnt < 4) begin
            if (pld_syndrome_vec == 128'd0) pld_synd_pass_cnt = pld_synd_pass_cnt + 1;
        end
    end

    // =======================================================
    // 9. SIMULATION TERMINATION & ETRI SUMMARY REPORT
    // =======================================================
    initial begin
        wait(cdc4_out_frame_seq >= 4'd4);
        wait(cdc4_pld_out_valid == 1'b0);
        #500;
        $display("\n======================================================================");
        $display(" END-TO-END CDC 1 -> GTH -> CDC 4 & FEC RS VERIFICATION REPORT");
        $display("======================================================================");
        $display(" Selected Error Inject Mode           : %0d (%s)", ERR_INJECT_MODE, err_inj_mode_str);
        $display(" TX RS(32,16)  Zero-Syndrome Passes   : %0d / 4 Frames", hdr_synd_pass_cnt);
        $display(" TX RS(255,239) Zero-Syndrome Passes  : %0d / 4 Frames", pld_synd_pass_cnt);
        $display(" RX Preamble 72-bit Lock Status       : %0d (72'h%018X)", rx_preamble_locked, rx_preamble_extracted);
        $display(" Post-LPC Symbol Errors [Lane 0..7]   : [%0d, %0d, %0d, %0d, %0d, %0d, %0d, %0d] (Limit t = %0d)",
                 rs_lane0_symbol_err_cnt, rs_lane1_symbol_err_cnt, rs_lane2_symbol_err_cnt, rs_lane3_symbol_err_cnt,
                 rs_lane4_symbol_err_cnt, rs_lane5_symbol_err_cnt, rs_lane6_symbol_err_cnt, rs_lane7_symbol_err_cnt,
                 rs_max_correctable_symbols);
        $display(" Total Corrupted Symbols Healed by RS : %0d Symbols", rs_corrected_symbol_cnt);
        $display(" Decoded Header Bytes Intact (4x16B)  : %0d / 64 Bytes", decoded_hdr_ok_cnt);
        $display(" Decoded Payload Words Intact (4x239W): %0d / 956 Words (Uncorrected for ARQ: %0d)",
                 decoded_pld_ok_cnt, rs_uncorrected_word_cnt);
        $display(" CDC 4 Extracted ASCII Tag (DAT1)     : \"%s\"", cdc4_ASCII_TAG);
        $display(" CDC 4 Extracted Ethernet FCS (DAT2)  : 0x%08X", cdc4_ETH_FCS);
        $display(" CDC 4 Extracted Range (MGMT 5000 km) : 0x%016X", cdc4_MGMT_RANGE);
        $display("======================================================================\n");
        $finish;
    end

endmodule