`timescale 1ns / 1ps
/*
===========================================================================
Company      : WiComAI Lab, Kookmin University
Engineers    : Williamsyah Baginda Miraj & Giovanni Dwi
Module Name  : eth_tx_back_end_top
Description  : Top-Level 10G Ethernet Transmit Back-End (Egress to PC 2).
               Integrates the Ethernet MAC TX Packing Buffer, 32-bit XGMII 
               TX Formatter (/S/ 0xFB & /T/ 0xFD), 10G Ethernet PCS/PMA TX 
               IP Core, and ChipScope ILA 3 (u_ila_2) telemetry counters.

               Revision Notes:
               1. Preserved all original architecture descriptions.
               2. Wrapped eth_10g_pcs_pma_tx_0 inside a generate block 
                  controlled by RUN_MODE (1 = Simulation / XGMII Direct Output, 
                  0 = Hardware SFP+ Mode).
               3. Placed ILA 3 (u_ila_2) telemetry registers inside this 
                  sub-module so SDAOISL10Gto10G_top remains 100% structural.
               4. Connected DRP loopback and configuration_vector on 
                  physical_mac_tx_inst so the 10G PCS/PMA core completes 
                  hardware reset properly.
               5. [Rev 2026-10-22 07:09 KST]: Updated timescale precision to 
                  1ns/1ps for project-wide simulation consistency.
               6. [Rev 2.4 - 2026-10-29 13:07 KST - Deep Audit Section 6 Fix]:
                  Updated 'xgmii_is_active' detection from '(xgmii_txd != 32'h0707_0707)'
                  to '(xgmii_txc_wire != 4'b1111)' so legal Ethernet payload words 
                  matching 0x07070707 (with TXC == 4'b0000) are counted accurately.
               7. [Rev 2.5 - 2026-10-29 15:19 KST - Audit Fix R01 & R14]:
                  Restored exact child port connections on u_packing and u_formatter.
               8. [Rev 2.6 - 2026-10-30 00:55 KST - Audit Fix N09]:
                  Moved 'dbg_rx_eth_pkt_cnt' increment outside the 'if (xgmii_is_active)'
                  block and triggered it on the XGMII Terminate delimiter (/T/ = 0xFD,
                  where xgmii_txc_wire == 4'b1111 and xgmii_txd_wire[7:0] == 8'hFD, or any
                  control lane containing 8'hFD), ensuring backend_counter.sv counts every
                  transmitted Ethernet packet accurately.
===========================================================================
*/

module eth_tx_back_end_top #(
    parameter RUN_MODE = 1 // 1 = Simulation Mode, 0 = Hardware SFP+ Mode
)(
    input  wire        clk,       // 312.5 MHz Clock
    input  wire        rst_n,     // Active-low reset
    
    // Input 1922 Byte / 2008 Byte Reassembled Ethernet Frame from ethernet_frame_reassembly
    input  wire [31:0] data_in,
    input  wire        en,
    
    // Output menuju Simulasi Testbench (XGMII Probing Output)
    output wire [31:0] xgmii_txd,
    output wire [3:0]  xgmii_txc,

    // Port SFP+ & Clocking Fisik untuk IP Core
    input  wire        refclk_p,
    input  wire        refclk_n,
    input  wire        reset,
    input  wire        dclk,
    output wire        txp,
    output wire        txn
);

    wire [31:0] pack_data;
    wire        pack_valid;
    wire [15:0] tx_word_cnt;
    wire [15:0] tx_byte_cnt;

    wire [31:0] xgmii_txd_wire;
    wire [3:0]  xgmii_txc_wire;

    // 1. Dynamic MAC Stream Packer (Packing and Segmentation)
    eth_mac_packing_tx u_packing (
        .clk         (clk),
        .rst_n       (rst_n),
        .mux_data    (data_in),
        .mux_valid   (en),
        .pack_data   (pack_data),
        .pack_valid  (pack_valid),
        .tx_word_cnt (tx_word_cnt),
        .tx_byte_cnt (tx_byte_cnt)
    );

    // 2. IEEE 802.3ae 32-bit XGMII Transmit Formatter
    xgmii_tx_formatter u_formatter (
        .clk       (clk),
        .rst_n     (rst_n),
        .mac_data  (pack_data),
        .mac_valid (pack_valid),
        .xgmii_txd (xgmii_txd_wire),
        .xgmii_txc (xgmii_txc_wire)
    );

    // CABANG 1: Teruskan ke pin output untuk Testbench Simulasi
    assign xgmii_txd = xgmii_txd_wire;
    assign xgmii_txc = xgmii_txc_wire;

    // =========================================================================
    // CABANG 2: IP Core 10G Ethernet PCS/PMA (Pemancar Optik SFP+ ke PC 2)
    //           Synthesized in Hardware Mode (RUN_MODE == 0)
    // =========================================================================
    generate
        if (RUN_MODE == 0) begin : gen_hw_eth_phy_tx
            wire        drp_gnt_w;
            wire        drp_den_w;
            wire        drp_dwe_w;
            wire [15:0] drp_daddr_w;
            wire [15:0] drp_di_w;
            wire        drp_drdy_w;
            wire [15:0] drp_drpdo_w;

            eth_10g_pcs_pma_tx_0 physical_mac_tx_inst (
                .dclk                   (dclk),
                .rxrecclk_out           (),
                .refclk_p               (refclk_p),
                .refclk_n               (refclk_n),
                .sim_speedup_control    (1'b0),
                .coreclk_out            (),
                .qplloutclk_out         (),
                .qplloutrefclk_out      (),
                .qplllock_out           (),
                .txusrclk_out           (),
                .txusrclk2_out          (),
                .areset_datapathclk_out (),
                .gttxreset_out          (),
                .gtrxreset_out          (),
                .txuserrdy_out          (),
                .reset_counter_done_out (),
                .reset                  (reset),
                .xgmii_txd              (xgmii_txd_wire),
                .xgmii_txc              (xgmii_txc_wire),
                .xgmii_rxd              (),
                .xgmii_rxc              (),
                .txp                    (txp),
                .txn                    (txn),
                .rxp                    (1'b0),
                .rxn                    (1'b1),
                .configuration_vector   (536'd0),
                .status_vector          (),
                .core_status            (),
                .resetdone_out          (),
                .signal_detect          (1'b1),
                .tx_fault               (1'b0),
                .drp_req                (drp_gnt_w),
                .drp_gnt                (drp_gnt_w),
                .drp_den_o              (drp_den_w),
                .drp_dwe_o              (drp_dwe_w),
                .drp_daddr_o            (drp_daddr_w),
                .drp_di_o               (drp_di_w),
                .drp_drdy_o             (drp_drdy_w),
                .drp_drpdo_o            (drp_drpdo_w),
                .drp_den_i              (drp_den_w),
                .drp_dwe_i              (drp_dwe_w),
                .drp_daddr_i            (drp_daddr_w),
                .drp_di_i               (drp_di_w),
                .drp_drdy_i             (drp_drdy_w),
                .drp_drpdo_i            (drp_drpdo_w),
                .pma_pmd_type           (3'b101),
                .tx_disable             ()
            );
        end else begin : gen_sim_eth_phy_tx_bypass
            assign txp = 1'b0;
            assign txn = 1'b1;
        end
    endgenerate

    // =========================================================================
    // 3. INTERNAL ILA 3 (u_ila_2) RX & PC 2 EGRESS TELEMETRY COUNTERS
    //    Housed inside eth_tx_back_end_top so Top Schematic stays clean!
    // =========================================================================
    (* mark_debug = "true", dont_touch = "true" *) reg [31:0] dbg_pc2_xgmii_txd;
    (* mark_debug = "true", dont_touch = "true" *) reg [3:0]  dbg_pc2_xgmii_txc;
    (* mark_debug = "true", dont_touch = "true" *) reg [15:0] dbg_rx_eth_byte_cnt;
    (* mark_debug = "true", dont_touch = "true" *) reg [15:0] dbg_rx_eth_pkt_cnt;
    reg [15:0] dbg_rx_eth_data_byte_cnt;

    wire       xgmii_is_active  = (xgmii_txc_wire != 4'b1111);
    wire [2:0] valid_data_lanes = (!xgmii_txc_wire[3]) + (!xgmii_txc_wire[2]) +
                                  (!xgmii_txc_wire[1]) + (!xgmii_txc_wire[0]);

    // [Rev 2.6 - Fix N09] Detect XGMII Terminate (/T/ = 0xFD) on any control lane
    wire xgmii_has_term = (xgmii_txc_wire[0] && (xgmii_txd_wire[7:0]   == 8'hFD)) ||
                          (xgmii_txc_wire[1] && (xgmii_txd_wire[15:8]  == 8'hFD)) ||
                          (xgmii_txc_wire[2] && (xgmii_txd_wire[23:16] == 8'hFD)) ||
                          (xgmii_txc_wire[3] && (xgmii_txd_wire[31:24] == 8'hFD));

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            dbg_pc2_xgmii_txd        <= 32'h0707_0707;
            dbg_pc2_xgmii_txc        <= 4'b1111;
            dbg_rx_eth_byte_cnt      <= 16'd0;
            dbg_rx_eth_pkt_cnt       <= 16'd0;
            dbg_rx_eth_data_byte_cnt <= 16'd0;
        end else begin
            dbg_pc2_xgmii_txd <= xgmii_txd_wire;
            dbg_pc2_xgmii_txc <= xgmii_txc_wire;

            if (xgmii_has_term) begin
                dbg_rx_eth_pkt_cnt  <= dbg_rx_eth_pkt_cnt + 16'd1;
                dbg_rx_eth_byte_cnt <= dbg_rx_eth_byte_cnt + 16'd4;
            end else if (xgmii_is_active) begin
                dbg_rx_eth_byte_cnt      <= dbg_rx_eth_byte_cnt + 16'd4;
                dbg_rx_eth_data_byte_cnt <= dbg_rx_eth_data_byte_cnt + {13'd0, valid_data_lanes};
            end else begin
                dbg_rx_eth_byte_cnt      <= 16'd0;
                dbg_rx_eth_data_byte_cnt <= 16'd0;
            end
        end
    end

endmodule