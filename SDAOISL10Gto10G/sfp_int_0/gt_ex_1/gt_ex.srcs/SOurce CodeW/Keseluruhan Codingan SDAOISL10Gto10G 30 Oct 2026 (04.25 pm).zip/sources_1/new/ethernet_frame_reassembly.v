`timescale 1ns / 1ps
/*
===========================================================================
Company      : WiComAI Lab, Kookmin University
Engineers    : Williamsyah Baginda Miraj & Giovanni Dwi
Module Name  : ethernet_frame_reassembly
Description  : SDA OISL Section 2.6.3.7.7 Ethernet Frame Reassembly, 
               Zero-Padding Stripper, and Preamble Injection Top Module.

               KEY OPERATIONS:
               1. Receives in-order 1908-Byte (477-word) verified FSO DATA 
                  frames from fso_ethernet_deframer.v at 312.5 MHz.
               2. Validates and strips the 4-Byte FSO Payload Header (0xAB) 
                  and 4-Byte FSO Packet Header (0xCDEF) per Table 2-18.
               3. Reconstructs segmented Ethernet packets across multiple FSO 
                  frames (e.g., 1900 Bytes from Frame 1 + 100 Bytes from 
                  Frame 2 = 2000 Bytes) while stripping all trailing FSO 
                  zero-padding (e.g., 1800 or 1804 Bytes).
               4. Commits the reassembled packet to the egress drain FSM only 
                  when all bytes of the Ethernet packet have arrived, ensuring 
                  a 100% contiguous burst with ZERO intra-packet gaps.
               5. Instantiates eth_preamble_gen.v and mux_eth_32.v to prepend 
                  the 8-Byte Ethernet Preamble + SFD (64'h55555555_555555D5), 
                  outputting 2008 Bytes (502 words) to eth_tx_back_end_top.v.

Revision History:
  - Rev 1.0 (Initial) : Multi-frame Ethernet de-segmenter & Preamble MUX wrapper.
  - Rev 2.0 (2026-10-27 04:34 KST) : [Target B6.3 - SDA OISL Page 43-46, Sec. 2.6.3.7.4 - 2.6.3.7.7,
    Figure 2-17 & Table 2-18; ETRI Review Item 4.2(2) & Item 5.1]
    Added support for strict Table 2-18 Continuation Frames and Multi-Packet Packing.
  - Rev 2.1 (2026-10-28 13:56 KST) : [Internal Audit Fix #4 - Strict State-Based Header Detection]
    Removed '(fso_word_idx == 9'd1) ||' from 'is_pkt_hdr_word' so that an FSO Packet 
    Header (0xCDEF) is recognized ONLY when no prior packet is mid-continuation 
    (rem_pkt_bytes == 16'd0). This guarantees that payload data words beginning with 
    16'hCDEF inside a continuation segment or active packet body are treated strictly 
    as Ethernet data and never misinterpreted as a packet header.
- Rev 2.8 (2026-10-30 11:30 KST) : [Audit Fix A02 & A03 - 16KB Reassembly Buffer & Multi-Segment Continuation]
    1. [Fix A03]: Expanded 'pkt_buf' from 1024 words (4 KB) to 4096 words (16 KB) 
       with 'buf_used < 13'd4000' flow-control margin so multi-segment packets up 
       to 16,000 Bytes (including 3,804B, 4,096B, and 7,200B) commit and drain 
       completely without buffer-full deadlock.
    2. [Fix A02]: Aligned Continuation Frame extraction with SDA OISL Section 
       2.6.3.7.5 (where Continuation Payload Header Length[13:0] reports total 
       remaining packet bytes) while supporting both 475-word segmented continuations 
       (from fso_payload.v with a 476th S_CONT_PAD zero word) and 476-word full 
       1904-Byte continuations (from reassembly_capacity.sv).
===========================================================================
*/

module ethernet_frame_reassembly (
    input  wire        clk,                    // 312.5 MHz Clock
    input  wire        rst_n,                  // Active-low reset

    // In-Order 1908-Byte (477-word) FSO DATA Stream from fso_ethernet_deframer
    input  wire [31:0] s_axis_fso_tdata,
    input  wire        s_axis_fso_tvalid,
    input  wire        s_axis_fso_tlast,
    output wire        s_axis_fso_tready,

    // Reassembled Ethernet Frame Output (Includes 8B Preamble = 2008 Bytes for 2000B Jumbo)
    output wire [31:0] m_axis_eth_tdata,
    output wire        m_axis_eth_tvalid,
    output wire        m_axis_eth_tlast,
    input  wire        m_axis_eth_tready,

    // Diagnostic & Telemetry Outputs
    output reg  [15:0] reassembled_pkt_bytes,
    output reg  [15:0] reassembled_pkt_cnt
);

    // =======================================================
    // 1. CONTIGUOUS PACKET REASSEMBLY BUFFER (4096 Words = 16 KB)
    // =======================================================
    (* ram_style = "block" *) reg [32:0] pkt_buf [0:4095]; // Bit 32 = pkt_tlast, [31:0] = data
    reg [11:0] wr_ptr;
    reg [11:0] rd_ptr;
    reg [12:0] buf_used;
    reg [5:0]  commit_pkt_cnt; // Number of complete Ethernet packets ready to drain

    assign s_axis_fso_tready = (buf_used < 13'd4000);

    reg [8:0]  fso_word_idx;
    reg        pkt_active;
    reg        in_cont_frame;
    reg [15:0] rem_pkt_bytes;
    reg [15:0] target_pkt_bytes;

    wire        fso_accept   = s_axis_fso_tvalid && s_axis_fso_tready;
    wire        is_pld_hdr   = (fso_word_idx == 9'd0) && (s_axis_fso_tdata[31:24] == 8'hAB);
    wire [13:0] pld_hdr_len  = s_axis_fso_tdata[13:0];
    wire        is_pkt_hdr   = (fso_word_idx == 9'd1) && (s_axis_fso_tdata[31:16] == 16'hCDEF);
    wire [13:0] pkt_hdr_len  = s_axis_fso_tdata[13:0];

    // Determine whether the current FSO word carries valid Ethernet payload bytes:
    // - On initial frame (!in_cont_frame): Words 2..476 carry up to 475 data words (1900B).
    // - On continuation frame (in_cont_frame): Words 1..475 carry 475 data words (1900B);
    //   Word 476 carries a 476th data word (1904B mode, as in reassembly_capacity.sv) ONLY
    //   when s_axis_fso_tdata != 32'd0, whereas S_CONT_PAD (32'd0 from fso_payload.v) is skipped.
    wire is_cont_pad_word = in_cont_frame && (fso_word_idx == 9'd476) && (s_axis_fso_tdata == 32'd0);
    wire is_eth_data_word = fso_accept && (
                            (!in_cont_frame && (fso_word_idx >= 9'd2) && pkt_active && (rem_pkt_bytes > 16'd0)) ||
                            ( in_cont_frame && (fso_word_idx >= 9'd1) && pkt_active && (rem_pkt_bytes > 16'd0) && !is_cont_pad_word)
                            );

    wire is_final_eth_word = is_eth_data_word && (rem_pkt_bytes <= 16'd4);

    wire drain_word_en;

    // Purely Synchronous RAM Write
    always @(posedge clk) begin
        if (is_eth_data_word) begin
            pkt_buf[wr_ptr] <= {is_final_eth_word, s_axis_fso_tdata};
        end
    end

    // De-Segmentation & Table 2-18 Parser FSM
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            fso_word_idx          <= 9'd0;
            pkt_active            <= 1'b0;
            in_cont_frame         <= 1'b0;
            rem_pkt_bytes         <= 16'd0;
            target_pkt_bytes      <= 16'd0;
            wr_ptr                <= 12'd0;
            reassembled_pkt_bytes <= 16'd0;
            reassembled_pkt_cnt   <= 16'd0;
        end else if (fso_accept) begin
            if (s_axis_fso_tlast || (fso_word_idx == 9'd476))
                fso_word_idx <= 9'd0;
            else
                fso_word_idx <= fso_word_idx + 9'd1;

            if (fso_word_idx == 9'd0) begin
                // Word 0: FSO Payload Header (0xAB)
                if (is_pld_hdr) begin
                    if (pkt_active && (pld_hdr_len != 14'd0)) begin
                        // Table 2-18 Continuation Frame: NO duplicate 0xCDEF header at Word 1!
                        in_cont_frame <= 1'b1;
                        rem_pkt_bytes <= {2'b00, pld_hdr_len};
                    end else begin
                        in_cont_frame <= 1'b0;
                    end
                end
            end else if ((fso_word_idx == 9'd1) && !in_cont_frame) begin
                // Word 1 of Start Frame: FSO Packet Header (0xCDEF)
                if (is_pkt_hdr) begin
                    pkt_active       <= 1'b1;
                    rem_pkt_bytes    <= (pkt_hdr_len != 14'd0) ? {2'b00, pkt_hdr_len} : 16'd2000;
                    target_pkt_bytes <= (pkt_hdr_len != 14'd0) ? {2'b00, pkt_hdr_len} : 16'd2000;
                end
            end

            if (is_eth_data_word) begin
                wr_ptr <= wr_ptr + 12'd1;
                if (is_final_eth_word) begin
                    rem_pkt_bytes         <= 16'd0;
                    pkt_active            <= 1'b0;
                    in_cont_frame         <= 1'b0;
                    reassembled_pkt_bytes <= target_pkt_bytes;
                    reassembled_pkt_cnt   <= reassembled_pkt_cnt + 16'd1;
                end else begin
                    rem_pkt_bytes <= rem_pkt_bytes - 16'd4;
                end
            end
        end
    end

    // Track Buffer Occupancy and Committed Packet Count
    wire pkt_commit_pulse = is_final_eth_word;
    wire pkt_drain_done;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            buf_used       <= 13'd0;
            commit_pkt_cnt <= 6'd0;
        end else begin
            if (is_eth_data_word && !drain_word_en)
                buf_used <= buf_used + 13'd1;
            else if (!is_eth_data_word && drain_word_en)
                buf_used <= buf_used - 13'd1;

            if (pkt_commit_pulse && !pkt_drain_done)
                commit_pkt_cnt <= commit_pkt_cnt + 6'd1;
            else if (!pkt_commit_pulse && pkt_drain_done)
                commit_pkt_cnt <= commit_pkt_cnt - 6'd1;
        end
    end

    // =======================================================
    // 2. ETHERNET PREAMBLE INJECTION (eth_preamble_gen + mux_eth_32)
    // =======================================================
    localparam DR_IDLE = 2'd0,
               DR_PRE  = 2'd1,
               DR_DATA = 2'd2;

    reg  [1:0]  dr_state;
    reg         pre_trig;
    wire [31:0] pre_tdata;
    wire        pre_tvalid;
    wire        pre_tlast;
    wire        pre_tready;

    wire [32:0] head_buf_word = pkt_buf[rd_ptr];
    reg  [31:0] pay_tdata;
    reg         pay_tvalid;
    reg         pay_tlast;
    wire        pay_tready;

    assign drain_word_en  = (dr_state == DR_DATA) && pay_tvalid && pay_tready;
    assign pkt_drain_done = drain_word_en && pay_tlast;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            dr_state <= DR_IDLE;
            rd_ptr   <= 12'd0;
            pre_trig <= 1'b0;
        end else begin
            pre_trig <= 1'b0;
            case (dr_state)
                DR_IDLE: begin
                    if ((commit_pkt_cnt > 6'd0) && m_axis_eth_tready) begin
                        pre_trig <= 1'b1;
                        dr_state <= DR_PRE;
                    end
                end
                DR_PRE: begin
                    if (pre_tvalid && pre_tready && pre_tlast) begin
                        dr_state <= DR_DATA;
                    end
                end
                DR_DATA: begin
                    if (pay_tvalid && pay_tready) begin
                        rd_ptr <= rd_ptr + 12'd1;
                        if (pay_tlast) begin
                            dr_state <= DR_IDLE;
                        end
                    end
                end
                default: dr_state <= DR_IDLE;
            endcase
        end
    end

    always @(*) begin
        if (dr_state == DR_DATA) begin
            pay_tvalid = 1'b1;
            pay_tdata  = head_buf_word[31:0];
            pay_tlast  = head_buf_word[32];
        end else begin
            pay_tvalid = 1'b0;
            pay_tdata  = 32'd0;
            pay_tlast  = 1'b0;
        end
    end

    eth_preamble_gen u_eth_preamble_gen (
        .clk           (clk),
        .rst_n         (rst_n),
        .trigger       (pre_trig),
        .m_axis_tdata  (pre_tdata),
        .m_axis_tvalid (pre_tvalid),
        .m_axis_tlast  (pre_tlast),
        .m_axis_tready (pre_tready)
    );

    mux_eth_32 u_mux_eth_32 (
        .clk              (clk),
        .rst_n            (rst_n),
        .s_axis_pre_tdata (pre_tdata),
        .s_axis_pre_tvalid(pre_tvalid),
        .s_axis_pre_tlast (pre_tlast),
        .s_axis_pre_tready(pre_tready),
        .s_axis_pay_tdata (pay_tdata),
        .s_axis_pay_tvalid(pay_tvalid),
        .s_axis_pay_tlast (pay_tlast),
        .s_axis_pay_tready(pay_tready),
        .m_axis_eth_tdata (m_axis_eth_tdata),
        .m_axis_eth_tvalid(m_axis_eth_tvalid),
        .m_axis_eth_tlast (m_axis_eth_tlast),
        .m_axis_eth_tready(m_axis_eth_tready)
    );

endmodule