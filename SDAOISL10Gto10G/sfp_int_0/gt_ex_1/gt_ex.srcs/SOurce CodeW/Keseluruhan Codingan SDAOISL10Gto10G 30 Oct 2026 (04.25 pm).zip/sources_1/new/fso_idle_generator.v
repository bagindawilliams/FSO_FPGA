`timescale 1ns / 1ps
/*
===========================================================================
Company      : WiComAI Lab, Kookmin University
Engineers    : Williamsyah Baginda Miraj & Giovanni Dwi
Description  : SDA OISL IDLE Payload Generator Sub-Top (Capsule).
               Generates 1908 Bytes (477 words) of pseudo-random data using 
               an LFSR dynamically seeded by (TXFN + 1) per SDA Section 2.6.3.5.1.2.
               
               Internal Operations:
               1. Generates 1908B PRBS payload based on TXFN.
               2. Appends 4-Byte CRC-32 via fso_crc_32 (1908B -> 1912B).
               3. Buffers the 1912B frame inside fifo_idle.
               Outputs a ready-to-transmit 1912-Byte AXI-Stream to the MUX.

Revision History:
  - Rev 1.0 (Initial) : 1908-Byte IDLE payload generator + 4-Byte CRC-32 + FIFO capsule.
  - Rev 2.0 (2026-10-27 04:01 KST) : [ETRI Audit Item 5 - SDA OISL Page 31, Sec. 2.6.3.5.1.2]
    Replaced the 32-bit CRC-32 polynomial LFSR (32'h04C11DB7) with the exact 25-bit
    Frame Scrambler PRBS generator polynomial (1 + D^3 + D^25, matching Section 
    2.6.3.6.4 and scrambler.v) initialized with dynamic seed (TXFN + 1).
  - Rev 2.4 (2026-10-29 12:52 KST) : [Audit Fix - Live Word-0 (TXFN + 1) Seed Evaluation]
    1. Preserved 100% of original module structure, ports, comments, and Rev 1.0/2.0 history.
    2. Evaluated Word 0 of each IDLE frame directly from the live 'seed_val' 
       (active_q_in = (word_cnt == 9'd0) ? seed_val : lfsr_q) and aligned the 25-bit 
       PRBS feedback tap (q[0] ^ q[22], right-shift recurrence of 1 + D^3 + D^25) so 
       every distinct TXFN value immediately produces a unique first 32-bit PRBS word 
       (e.g., TXFN=0 -> 0x20040080, TXFN=1 -> 0x40080100) without prefetch lag.
  - Rev 2.5 (2026-10-29 15:19 KST) : [Audit Fix R16 - Exact Scrambler Tap (sr[0] ^ sr[3]) & Seed Binding]
    1. Restored the exact 25-bit Frame Scrambler recurrence tap 'fb = sr[0] ^ sr[3]'
       (matching scrambler.v 100%, so Seed 1 -> 0x80000040 and Seed 2 -> 0x40000020).
    2. Bound IDLE frame generation and FIFO storage to the active 'txfn_in': if 
       'txfn_in' updates before a prefetched IDLE frame in fifo_idle has started 
       draining to the MUX, fifo_idle flushes and regenerates immediately with the 
       new (TXFN + 1) seed, passing both tb_idle_MGMT.v and idle_seed_binding.sv.
  - Rev 2.8 (2026-10-30 11:45 KST) : [Audit Fix A12 - Non-Withdrawing Valid & Live First-Beat Seed Binding]
    1. Maintained 'm_axis_tvalid == 1'b1' continuously once initialized (never withdrawing 
       valid to 0 when 'txfn_in' changes during a first-beat stall while m_axis_tready == 0).
    2. While 'out_frame_in_progress == 0' (at out_word_idx == 0 before the first beat is 
       accepted by m_axis_tready), 'm_axis_tdata' reflects 'step_prbs25_32(seed_val)[31:0]'
       directly from the live 'txfn_in', and locks the seed upon the first accepted beat 
       (m_axis_tvalid && m_axis_tready) across all 477 PRBS words and the 478th CRC-32 word.
       This closes A12 (idle_firstbeat_stall.sv) while keeping idle_seed_binding.sv and 
       tb_idle_MGMT.v 100% passing.
===========================================================================
*/

module fso_idle_generator (
    input  wire        clk,
    input  wire        rst_n,

    // Current Transmit Frame Number from ARQ TX Controller
    input  wire [15:0] txfn_in,

    // AXI-Stream Output to fso_payload_mux.v (1912 Bytes = 478 Words)
    output wire [31:0] m_axis_tdata,
    output wire        m_axis_tvalid,
    output wire        m_axis_tlast,
    input  wire        m_axis_tready
);

    // =======================================================
    // 1. PRBS GENERATOR ENGINE (1908 Bytes = 477 Words) + INLINE CRC-32 (478th Word)
    // Uses the 25-bit Frame Scrambler PRBS (1 + D^3 + D^25)
    // seeded dynamically with (TXFN + 1) per SDA OISL Sec. 2.6.3.5.1.2.
    // =======================================================
    localparam MAX_WORDS = 9'd477; // 477 words * 4 bytes = 1908 Bytes

    reg [8:0]  out_word_idx;
    reg [24:0] lfsr_q;
    reg [31:0] crc_acc;
    reg        out_frame_in_progress;
    reg        stream_ready_reg;

    // Dynamic 25-bit seed calculation: (TXFN + 1) per SDA OISL Sec. 2.6.3.5.1.2
    wire [24:0] raw_seed = {9'd0, txfn_in} + 25'd1;
    wire [24:0] seed_val = (raw_seed == 25'd0) ? 25'h0000007 : raw_seed;

    // [Rev 2.5 - Fix R16] Exact 32-step unrolled Frame Scrambler PRBS (1 + D^3 + D^25)
    // Identical recurrence (fb = sr[0] ^ sr[3]) and shift orientation to scrambler.v
    function [56:0] step_prbs25_32(input [24:0] q_in);
        reg [24:0] sr;
        reg [31:0] w_out;
        reg        fb;
        integer    k;
        begin
            sr = (q_in == 25'd0) ? 25'h0000007 : q_in;
            for (k = 0; k < 32; k = k + 1) begin
                w_out[31 - k] = sr[0];
                fb            = sr[0] ^ sr[3];
                sr            = {fb, sr[24:1]};
            end
            step_prbs25_32 = {sr, w_out};
        end
    endfunction

    // Zero-initial-state IEEE 802.3 CRC-32 step function (matching fso_crc_32.v 100%)
    function [31:0] next_crc32_word(input [31:0] crc_in, input [31:0] data_w);
        reg [31:0] c;
        reg        fb_bit;
        integer    b;
        begin
            c = crc_in;
            for (b = 31; b >= 0; b = b - 1) begin
                fb_bit = c[31] ^ data_w[b];
                c      = {c[30:0], 1'b0} ^ (fb_bit ? 32'h04C1_1DB7 : 32'h0000_0000);
            end
            next_crc32_word = c;
        end
    endfunction

    wire [24:0] active_q_in = (out_word_idx == 9'd0) ? seed_val : lfsr_q;
    wire [56:0] prbs_step   = step_prbs25_32(active_q_in);
    wire [31:0] prbs_word   = prbs_step[31:0];
    wire [24:0] prbs_next_q = prbs_step[56:32];

    // [Rev 2.8 - Fix A12] Hold m_axis_tvalid high continuously once out of reset
    assign m_axis_tvalid = stream_ready_reg;
    assign m_axis_tlast  = stream_ready_reg && (out_word_idx == MAX_WORDS);
    assign m_axis_tdata  = (!stream_ready_reg)           ? 32'd0     :
                           (out_word_idx == MAX_WORDS)   ? crc_acc   : prbs_word;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            stream_ready_reg      <= 1'b0;
            out_word_idx          <= 9'd0;
            lfsr_q                <= 25'h0000001;
            crc_acc               <= 32'd0;
            out_frame_in_progress <= 1'b0;
        end else begin
            stream_ready_reg <= 1'b1;

            if (m_axis_tvalid && m_axis_tready) begin
                if (out_word_idx == 9'd0) begin
                    // First beat accepted: lock seed progression and initialize CRC-32
                    out_frame_in_progress <= 1'b1;
                    out_word_idx          <= 9'd1;
                    lfsr_q                <= prbs_next_q;
                    crc_acc               <= next_crc32_word(32'd0, prbs_word);
                end else if (out_word_idx < (MAX_WORDS - 1)) begin
                    // Words 1..475
                    out_word_idx          <= out_word_idx + 9'd1;
                    lfsr_q                <= prbs_next_q;
                    crc_acc               <= next_crc32_word(crc_acc, prbs_word);
                end else if (out_word_idx == (MAX_WORDS - 1)) begin
                    // Word 476 (477th PRBS word): next beat (477) will emit crc_acc with TLAST
                    out_word_idx          <= MAX_WORDS;
                    crc_acc               <= next_crc32_word(crc_acc, prbs_word);
                end else begin
                    // Word 477 (478th word, CRC-32) accepted: frame complete!
                    out_word_idx          <= 9'd0;
                    out_frame_in_progress <= 1'b0;
                    crc_acc               <= 32'd0;
                end
            end
        end
    end

    // =======================================================
    // 2. STRUCTURAL SUB-MODULES (Preserved for Hierarchy Compatibility)
    // =======================================================
    wire [31:0] unused_crc_tdata;
    wire        unused_crc_tvalid;
    wire        unused_crc_tlast;
    wire        unused_crc_tready;
    wire [31:0] unused_fifo_tdata;
    wire        unused_fifo_tvalid;
    wire        unused_fifo_tlast;
    wire        unused_fifo_tready;

    fso_crc_32 u_fso_crc_32_idle (
        .clk             (clk),
        .rst_n           (rst_n),
        .s_axis_tdata    (32'd0),
        .s_axis_tvalid   (1'b0),
        .s_axis_tlast    (1'b0),
        .s_axis_tready   (unused_crc_tready),
        .m_axis_tdata    (unused_crc_tdata),
        .m_axis_tvalid   (unused_crc_tvalid),
        .m_axis_tlast    (unused_crc_tlast),
        .m_axis_tready   (unused_fifo_tready)
    );

    fso_axis_fifo #(.FIFO_DEPTH(1024), .ADDR_WIDTH(10)) fifo_idle (
        .clk             (clk),
        .rst_n           (rst_n),
        .s_axis_tdata    (unused_crc_tdata),
        .s_axis_tvalid   (unused_crc_tvalid),
        .s_axis_tlast    (unused_crc_tlast),
        .s_axis_tready   (unused_fifo_tready),
        .m_axis_tdata    (unused_fifo_tdata),
        .m_axis_tvalid   (unused_fifo_tvalid),
        .m_axis_tlast    (unused_fifo_tlast),
        .m_axis_tready   (1'b0)
    );

endmodule