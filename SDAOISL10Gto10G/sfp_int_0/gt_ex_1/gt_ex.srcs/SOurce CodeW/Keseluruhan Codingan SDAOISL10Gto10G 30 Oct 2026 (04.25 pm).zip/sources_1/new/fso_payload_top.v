`timescale 1ns / 1ps
/*
===========================================================================
Company      : WiComAI Lab, Kookmin University
Engineers    : Williamsyah Baginda Miraj & Giovanni Dwi
Description  : Grand Top-Level FSO Payload Subsystem (1912-Byte Assembler).
               Integrates the 3 autonomous FSO Payload Capsules and the 
               4-to-1 Frame Multiplexer:
               1. fso_payload              : Ethernet DATA Capsule (Path 01) 
                                             & ARQ Retransmit RAM (Path 11).
               2. fso_idle_generator       : Dynamic (TXFN+1) 25-bit PRBS 
                                             IDLE Capsule (Path 00).
               3. mgmt_telemetry_generator : 1Hz Satellite Ranging/Timestamp 
                                             MGMT Capsule (Path 10).
               4. fso_payload_mux          : Lock-On-Frame 4-to-1 AXI-Stream 
                                             Multiplexer to CDC 1.

Revision History:
  - Rev 1.0 (Initial) : 1912-Byte Payload Top subsystem integration.
  - Rev 2.1 (2026-10-28 13:56 KST) : [Internal Audit Fix #5]
    Forwarded 'seg_valid_bytes' from upstream segmenter to u_fso_payload
    for dynamic Ethernet packet length encapsulation.
  - Rev 2.6 (2026-10-30 00:31 KST) : [Audit Fix N07 - 14-Bit Length Metadata]
    Widened 'seg_valid_bytes' port from [10:0] to [13:0] to support full 14-bit
    Table 2-18 packet lengths up to 16,383 Bytes.
- Rev 2.8 (2026-10-30 11:30 KST) : [Audit Fix A18 - Consistent 14-Bit Length Port]
    Standardized 'seg_valid_bytes' port width to 14 bits ([13:0]) to match 
    fso_payload.v and ethernet_fso_framer.v without width-mismatch warnings.
===========================================================================
*/

module fso_payload_top (
    input  wire        clk,
    input  wire        rst_n,

    // -------------------------------------------------------
    // 1. Ethernet Segment Stream Input (From Front-End Segmenter)
    // -------------------------------------------------------
    input  wire [31:0] s_axis_eth_tdata,
    input  wire        s_axis_eth_tvalid,
    input  wire        s_axis_eth_tlast,
    output wire        s_axis_eth_tready,
    input  wire [13:0] seg_valid_bytes,   // [Rev 2.8 - Fix A18] Full 14-bit packet/segment byte count

    // -------------------------------------------------------
    // 2. ARQ TX Controller & Scheduler Commands
    // -------------------------------------------------------
    input  wire [1:0]  payload_mux_sel,   // 00=IDLE, 01=DATA, 10=MGMT, 11=RETX
    input  wire [15:0] txfn_in,           // Current TXFN for IDLE PRBS seeding
    input  wire        ddr4_write_req,
    input  wire        ddr4_read_req,
    input  wire        ddr4_delete_req,
    input  wire [15:0] ddr4_addr,

    // -------------------------------------------------------
    // 3. 1Hz MGMT Telemetry & Ranging Inputs
    // -------------------------------------------------------
    input  wire        mgmt_trigger_1hz,
    input  wire [5:0]  rx_phy_ts_sec,
    input  wire [39:0] rx_phy_ts_picosec,
    input  wire [5:0]  tx_phy_ts_sec,
    input  wire [39:0] tx_phy_ts_picosec,
    input  wire [63:0] range_meters,
    input  wire [31:0] range_ts_sec,
    input  wire [39:0] range_ts_picosec,
    input  wire        ts_valid,

    // -------------------------------------------------------
    // 4. Multiplexed 1912-Byte FSO Payload Stream Output (To CDC 1)
    // -------------------------------------------------------
    output wire [31:0] m_axis_fso_tdata,
    output wire        m_axis_fso_tvalid,
    output wire        m_axis_fso_tlast,
    input  wire        m_axis_fso_tready
);

    // Internal AXI-Stream Buses from the 4 Payload Sources
    wire [31:0] idle_tdata;
    wire        idle_tvalid;
    wire        idle_tlast;
    wire        idle_tready;

    wire [31:0] data_tdata;
    wire        data_tvalid;
    wire        data_tlast;
    wire        data_tready;

    wire [31:0] mgmt_tdata;
    wire        mgmt_tvalid;
    wire        mgmt_tlast;
    wire        mgmt_tready;

    wire [31:0] retx_tdata;
    wire        retx_tvalid;
    wire        retx_tlast;
    wire        retx_tready;

    // 1. DATA & RETRANSMIT CAPSULE (Path 01 & Path 11)
    fso_payload u_fso_payload (
        .clk                (clk),
        .rst_n              (rst_n),
        .s_axis_eth_tdata   (s_axis_eth_tdata),
        .s_axis_eth_tvalid  (s_axis_eth_tvalid),
        .s_axis_eth_tlast   (s_axis_eth_tlast),
        .s_axis_eth_tready  (s_axis_eth_tready),
        .seg_valid_bytes    (seg_valid_bytes),
        .ddr4_write_req     (ddr4_write_req),
        .ddr4_read_req      (ddr4_read_req),
        .ddr4_delete_req    (ddr4_delete_req),
        .ddr4_addr          (ddr4_addr),
        .m_axis_data_tdata  (data_tdata),
        .m_axis_data_tvalid (data_tvalid),
        .m_axis_data_tlast  (data_tlast),
        .m_axis_data_tready (data_tready),
        .m_axis_retx_tdata  (retx_tdata),
        .m_axis_retx_tvalid (retx_tvalid),
        .m_axis_retx_tlast  (retx_tlast),
        .m_axis_retx_tready (retx_tready)
    );

    // 2. IDLE PRBS CAPSULE (Path 00 - Seeded by TXFN + 1)
    fso_idle_generator u_fso_idle_generator (
        .clk           (clk),
        .rst_n         (rst_n),
        .txfn_in       (txfn_in),
        .m_axis_tdata  (idle_tdata),
        .m_axis_tvalid (idle_tvalid),
        .m_axis_tlast  (idle_tlast),
        .m_axis_tready (idle_tready)
    );

    // 3. 1HZ MANAGEMENT TELEMETRY CAPSULE (Path 10)
    mgmt_telemetry_generator u_mgmt_telemetry_generator (
        .clk               (clk),
        .rst_n             (rst_n),
        .mgmt_trigger_1hz  (mgmt_trigger_1hz),
        .rx_phy_ts_sec     (rx_phy_ts_sec),
        .rx_phy_ts_picosec (rx_phy_ts_picosec),
        .tx_phy_ts_sec     (tx_phy_ts_sec),
        .tx_phy_ts_picosec (tx_phy_ts_picosec),
        .range_meters      (range_meters),
        .range_ts_sec      (range_ts_sec),
        .range_ts_picosec  (range_ts_picosec),
        .ts_valid          (ts_valid),
        .m_axis_tdata      (mgmt_tdata),
        .m_axis_tvalid     (mgmt_tvalid),
        .m_axis_tlast      (mgmt_tlast),
        .m_axis_tready     (mgmt_tready)
    );

    // 4. LOCK-ON-FRAME 4-TO-1 PAYLOAD MULTIPLEXER
    fso_payload_mux u_fso_payload_mux (
        .clk                (clk),
        .rst_n              (rst_n),
        .payload_mux_sel    (payload_mux_sel),
        .s_axis_idle_tdata  (idle_tdata),
        .s_axis_idle_tvalid (idle_tvalid),
        .s_axis_idle_tlast  (idle_tlast),
        .s_axis_idle_tready (idle_tready),
        .s_axis_data_tdata  (data_tdata),
        .s_axis_data_tvalid (data_tvalid),
        .s_axis_data_tlast  (data_tlast),
        .s_axis_data_tready (data_tready),
        .s_axis_mgmt_tdata  (mgmt_tdata),
        .s_axis_mgmt_tvalid (mgmt_tvalid),
        .s_axis_mgmt_tlast  (mgmt_tlast),
        .s_axis_mgmt_tready (mgmt_tready),
        .s_axis_retx_tdata  (retx_tdata),
        .s_axis_retx_tvalid (retx_tvalid),
        .s_axis_retx_tlast  (retx_tlast),
        .s_axis_retx_tready (retx_tready),
        .m_axis_fso_tdata   (m_axis_fso_tdata),
        .m_axis_fso_tvalid  (m_axis_fso_tvalid),
        .m_axis_fso_tlast   (m_axis_fso_tlast),
        .m_axis_fso_tready  (m_axis_fso_tready)
    );

endmodule