`timescale 1ns / 1ps
/*
===========================================================================
Company      : WiComAI Lab, Kookmin University
Engineers    : Williamsyah Baginda Miraj & Giovanni Dwi
Module Name  : ethernet_frame_reassembly
Description  : SDA OISL Section 2.6.3.7.7 Ethernet Frame Reassembly, 
               Zero-Padding Stripper, and Preamble Injection Top Module.

               KEY OPERATIONS:
               1. Receives in-order 1908-Byte (477-word) verified FSO DATA 
                  frames from fso_ethernet_deframer.v at 312.5 MHz.
               2. Validates and strips the 4-Byte FSO Payload Header (0xAB) 
                  and 4-Byte FSO Packet Header (0xCDEF) per Table 2-18.
               3. Reconstructs segmented Ethernet packets across multiple FSO 
                  frames (e.g., 1900 Bytes from Frame 1 + 100 Bytes from 
                  Frame 2 = 2000 Bytes) while stripping all trailing FSO 
                  zero-padding (e.g., 1800 or 1804 Bytes).
               4. Commits the reassembled packet to the egress drain FSM only 
                  when all bytes of the Ethernet packet have arrived, ensuring 
                  a 100% contiguous burst with ZERO intra-packet gaps.
               5. Instantiates eth_preamble_gen.v and mux_eth_32.v to prepend 
                  the 8-Byte Ethernet Preamble + SFD (64'h55555555_555555D5), 
                  outputting 2008 Bytes (502 words) to eth_tx_back_end_top.v.

Revision History:
  - Rev 1.0 (Initial) : Multi-frame Ethernet de-segmenter & Preamble MUX wrapper.
  - Rev 2.0 (2026-10-27 04:34 KST) : [Target B6.3 - SDA OISL Page 43-46, Sec. 2.6.3.7.4 - 2.6.3.7.7,
    Figure 2-17 & Table 2-18; ETRI Review Item 4.2(2) & Item 5.1]
    Added support for strict Table 2-18 Continuation Frames and Multi-Packet Packing.
  - Rev 2.1 (2026-10-28 13:56 KST) : [Internal Audit Fix #4 - Strict State-Based Header Detection]
    Removed '(fso_word_idx == 9'd1) ||' from 'is_pkt_hdr_word' so that an FSO Packet 
    Header (0xCDEF) is recognized ONLY when no prior packet is mid-continuation 
    (rem_pkt_bytes == 16'd0). This guarantees that payload data words beginning with 
    16'hCDEF inside a continuation segment or active packet body are treated strictly 
    as Ethernet data and never misinterpreted as a packet header.
  - Rev 2.9 (2026-10-30 18:05 KST) : [Audit Fix B02, B04, B05, B06, B07 & B08]
    1. [Fix B02]: Restored exact port bindings on u_eth_preamble_gen (.preamble_sfd)
       and u_mux_eth_32 (.clk, .rst_n, .preamble_sfd, .asm_data_in, .asm_valid_in,
       .asm_last_in, .m_axis_tdata, .m_axis_tvalid, .m_axis_tlast, .m_axis_tready)
       and synchronized the drain state machine with mux_eth_32's 2-word preamble
       shift pipeline, resolving all 19 RX elaboration errors.
    2. [Fix B04]: Removed zero-data heuristic ('is_cont_pad_word') so legal 
       Ethernet payload words equal to 32'h0000_0000 on word 476 of a 1904-Byte 
       continuation frame are preserved intact (parser_zero_continuation.sv).
    3. [Fix B05 & B06]: Restored 'fso_frame_valid_magic' gating (discarding any 
       frame whose Word 0 lacks the 8'hAB magic byte per SDA OISL Sec. 2.6.3.7.7)
       and restored 10-bit sequence tracking ('expected_fso_seq', 'seq_initialized')
       with write-pointer rollback ('committed_wr_ptr', 'committed_buf_used') so 
       partial packets are discarded upon a sequence gap (parser_sequence_gap.sv).
    4. [Fix B07 & B08]: Allowed new Packet Headers (0xCDEF) at any word boundary 
       when '!pkt_active' to support multiple packed Ethernet frames per FSO frame 
       (parser_packed_two_fullframe.sv), and widened 'commit_pkt_cnt' to 11 bits 
       ([10:0]) so 64+ queued small packets never wrap to 0 (parser_commit_wrap64).
===========================================================================
*/

module ethernet_frame_reassembly (
    input  wire        clk,                    // 312.5 MHz Clock
    input  wire        rst_n,                  // Active-low reset

    // In-Order 1908-Byte (477-word) FSO DATA Stream from fso_ethernet_deframer
    input  wire [31:0] s_axis_fso_tdata,
    input  wire        s_axis_fso_tvalid,
    input  wire        s_axis_fso_tlast,
    output wire        s_axis_fso_tready,

    // Reassembled Ethernet Frame Output (Includes 8B Preamble = 2008 Bytes for 2000B Jumbo)
    output wire [31:0] m_axis_eth_tdata,
    output wire        m_axis_eth_tvalid,
    output wire        m_axis_eth_tlast,
    input  wire        m_axis_eth_tready,

    // Diagnostic & Telemetry Outputs
    output reg  [15:0] reassembled_pkt_bytes,
    output reg  [15:0] reassembled_pkt_cnt
);

    // =======================================================
    // 1. CONTIGUOUS PACKET REASSEMBLY BUFFER (4096 Words = 16 KB)
    // =======================================================
    (* ram_style = "block" *) reg [32:0] pkt_buf [0:4095]; // Bit 32 = pkt_tlast, [31:0] = data
    reg [11:0] wr_ptr;
    reg [11:0] committed_wr_ptr;
    reg [11:0] rd_ptr;
    reg [12:0] buf_used;
    reg [12:0] uncommit_words;
    reg [10:0] commit_pkt_cnt; // [Rev 2.9 - Fix B08] 11-bit counter (up to 2047 packets)

    assign s_axis_fso_tready = (buf_used < 13'd4000);

    reg [8:0]  fso_word_idx;
    reg        fso_frame_valid_magic;
    reg [9:0]  expected_fso_seq;
    reg        seq_initialized;
    reg        pkt_active;
    reg        in_cont_frame;
    reg [15:0] rem_pkt_bytes;
    reg [15:0] target_pkt_bytes;

    wire        fso_accept   = s_axis_fso_tvalid && s_axis_fso_tready;
    wire        is_word0     = (fso_word_idx == 9'd0);
    wire        is_pld_hdr   = is_word0 && (s_axis_fso_tdata[31:24] == 8'hAB);
    wire [9:0]  rx_fso_seq   = s_axis_fso_tdata[23:14];
    wire [13:0] pld_hdr_len  = s_axis_fso_tdata[13:0];

    // [Rev 2.9 - Fix B06] Detect sequence gap on Word 0 when a valid 0xAB header arrives
    wire        seq_gap_err  = is_pld_hdr && seq_initialized && (rx_fso_seq != expected_fso_seq);

    // [Rev 2.9 - Fix B07] Recognize 0xCDEF Packet Header at any word index >= 1 when no packet is active
    wire        is_pkt_hdr   = (!is_word0) && fso_frame_valid_magic && (!pkt_active) &&
                               (s_axis_fso_tdata[31:16] == 16'hCDEF) && (s_axis_fso_tdata[13:0] != 14'd0);
    wire [13:0] pkt_hdr_len  = s_axis_fso_tdata[13:0];

    // [Rev 2.9 - Fix B04 & B05] Accept Ethernet payload words strictly when frame magic is valid,
    // a packet is currently active, and rem_pkt_bytes > 0 (never dropping zero-valued data words!)
    wire is_eth_data_word  = fso_accept && (!is_word0) && fso_frame_valid_magic &&
                             pkt_active && (rem_pkt_bytes > 16'd0);
    wire is_final_eth_word = is_eth_data_word && (rem_pkt_bytes <= 16'd4);

    wire drain_word_en;
    wire pkt_drain_done;

    // Purely Synchronous RAM Write
    always @(posedge clk) begin
        if (is_eth_data_word) begin
            pkt_buf[wr_ptr] <= {is_final_eth_word, s_axis_fso_tdata};
        end
    end

    // De-Segmentation, Magic Validation, Sequence-Gap Rollback & Table 2-18 Parser FSM
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            fso_word_idx          <= 9'd0;
            fso_frame_valid_magic <= 1'b0;
            expected_fso_seq      <= 10'd0;
            seq_initialized       <= 1'b0;
            pkt_active            <= 1'b0;
            in_cont_frame         <= 1'b0;
            rem_pkt_bytes         <= 16'd0;
            target_pkt_bytes      <= 16'd0;
            wr_ptr                <= 12'd0;
            committed_wr_ptr      <= 12'd0;
            uncommit_words        <= 13'd0;
            reassembled_pkt_bytes <= 16'd0;
            reassembled_pkt_cnt   <= 16'd0;
        end else if (fso_accept) begin
            if (s_axis_fso_tlast || (fso_word_idx == 9'd476))
                fso_word_idx <= 9'd0;
            else
                fso_word_idx <= fso_word_idx + 9'd1;

            if (is_word0) begin
                // Word 0: Validate FSO Payload Header Magic (8'hAB) per SDA OISL Sec. 2.6.3.7.7
                if (is_pld_hdr) begin
                    fso_frame_valid_magic <= 1'b1;
                    seq_initialized       <= 1'b1;
                    expected_fso_seq      <= rx_fso_seq + 10'd1;

                    if (seq_gap_err) begin
                        // [Rev 2.9 - Fix B06] Sequence gap detected: rollback partial packet!
                        pkt_active     <= 1'b0;
                        in_cont_frame  <= 1'b0;
                        rem_pkt_bytes  <= 16'd0;
                        wr_ptr         <= committed_wr_ptr;
                        uncommit_words <= 13'd0;
                    end else if (pkt_active && (pld_hdr_len != 14'd0)) begin
                        // Valid Table 2-18 Continuation Frame
                        in_cont_frame  <= 1'b1;
                        rem_pkt_bytes  <= {2'b00, pld_hdr_len};
                    end else begin
                        // New initial frame boundary (if previous packet was incomplete, roll it back)
                        if (pkt_active) begin
                            pkt_active     <= 1'b0;
                            rem_pkt_bytes  <= 16'd0;
                            wr_ptr         <= committed_wr_ptr;
                            uncommit_words <= 13'd0;
                        end
                        in_cont_frame <= 1'b0;
                    end
                end else begin
                    // [Rev 2.9 - Fix B05] Invalid Payload Header magic: discard entire FSO frame!
                    fso_frame_valid_magic <= 1'b0;
                    in_cont_frame         <= 1'b0;
                end
            end else if (is_pkt_hdr) begin
                // [Rev 2.9 - Fix B07] Start of new Ethernet packet (0xCDEF header)
                pkt_active       <= 1'b1;
                rem_pkt_bytes    <= {2'b00, pkt_hdr_len};
                target_pkt_bytes <= {2'b00, pkt_hdr_len};
                uncommit_words   <= 13'd0;
            end else if (is_eth_data_word) begin
                wr_ptr <= wr_ptr + 12'd1;
                if (is_final_eth_word) begin
                    rem_pkt_bytes         <= 16'd0;
                    pkt_active            <= 1'b0;
                    in_cont_frame         <= 1'b0;
                    committed_wr_ptr      <= wr_ptr + 12'd1;
                    uncommit_words        <= 13'd0;
                    reassembled_pkt_bytes <= target_pkt_bytes;
                    reassembled_pkt_cnt   <= reassembled_pkt_cnt + 16'd1;
                end else begin
                    rem_pkt_bytes  <= rem_pkt_bytes - 16'd4;
                    uncommit_words <= uncommit_words + 13'd1;
                end
            end
        end
    end

    // Track Buffer Occupancy (with Sequence-Gap Rollback Support) and 11-Bit Committed Packet Count
    wire pkt_commit_pulse = is_final_eth_word;
    wire rollback_now     = fso_accept && is_word0 && (
                            (is_pld_hdr && seq_gap_err && pkt_active) ||
                            (is_pld_hdr && !seq_gap_err && pkt_active && (pld_hdr_len == 14'd0))
                            );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            buf_used       <= 13'd0;
            commit_pkt_cnt <= 11'd0;
        end else begin
            if (rollback_now) begin
                buf_used <= buf_used - uncommit_words - (drain_word_en ? 13'd1 : 13'd0);
            end else if (is_eth_data_word && !drain_word_en) begin
                buf_used <= buf_used + 13'd1;
            end else if (!is_eth_data_word && drain_word_en) begin
                buf_used <= buf_used - 13'd1;
            end

            if (pkt_commit_pulse && !pkt_drain_done)
                commit_pkt_cnt <= commit_pkt_cnt + 11'd1;
            else if (!pkt_commit_pulse && pkt_drain_done)
                commit_pkt_cnt <= commit_pkt_cnt - 11'd1;
        end
    end

    // =======================================================
    // 2. ETHERNET PREAMBLE INJECTION (eth_preamble_gen + mux_eth_32)
    //    [Rev 2.9 - Fix B02]: Exact port mapping and 2-word tail flush
    // =======================================================
    localparam DR_IDLE       = 2'd0,
               DR_STREAM     = 2'd1,
               DR_FLUSH_TAIL = 2'd2;

    reg  [1:0]  dr_state;
    wire [63:0] preamble_sfd_wire;
    wire [32:0] head_buf_word = pkt_buf[rd_ptr];

    reg  [31:0] asm_data_in;
    reg         asm_valid_in;
    reg         asm_last_in;

    assign drain_word_en  = (dr_state == DR_STREAM) && asm_valid_in && m_axis_eth_tready;
    assign pkt_drain_done = drain_word_en && asm_last_in;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            dr_state <= DR_IDLE;
            rd_ptr   <= 12'd0;
        end else begin
            case (dr_state)
                DR_IDLE: begin
                    if ((commit_pkt_cnt > 11'd0) && m_axis_eth_tready) begin
                        dr_state <= DR_STREAM;
                    end
                end
                DR_STREAM: begin
                    if (m_axis_eth_tready) begin
                        rd_ptr <= rd_ptr + 12'd1;
                        if (head_buf_word[32]) begin
                            // Last word of Ethernet payload fed into mux_eth_32; wait for
                            // mux_eth_32 to flush its 2 delayed words and assert m_axis_eth_tlast
                            dr_state <= DR_FLUSH_TAIL;
                        end
                    end
                end
                DR_FLUSH_TAIL: begin
                    if (m_axis_eth_tvalid && m_axis_eth_tready && m_axis_eth_tlast) begin
                        dr_state <= DR_IDLE;
                    end
                end
                default: dr_state <= DR_IDLE;
            endcase
        end
    end

    always @(*) begin
        if (dr_state == DR_STREAM && m_axis_eth_tready) begin
            asm_valid_in = 1'b1;
            asm_data_in  = head_buf_word[31:0];
            asm_last_in  = head_buf_word[32];
        end else begin
            asm_valid_in = 1'b0;
            asm_data_in  = 32'd0;
            asm_last_in  = 1'b0;
        end
    end

    eth_preamble_gen u_eth_preamble_gen (
        .preamble_sfd (preamble_sfd_wire)
    );

    mux_eth_32 u_mux_eth_32 (
        .clk          (clk),
        .rst_n        (rst_n),
        .preamble_sfd (preamble_sfd_wire),
        .asm_data_in  (asm_data_in),
        .asm_valid_in (asm_valid_in),
        .asm_last_in  (asm_last_in),
        .m_axis_tdata (m_axis_eth_tdata),
        .m_axis_tvalid(m_axis_eth_tvalid),
        .m_axis_tlast (m_axis_eth_tlast),
        .m_axis_tready(m_axis_eth_tready)
    );

endmodule