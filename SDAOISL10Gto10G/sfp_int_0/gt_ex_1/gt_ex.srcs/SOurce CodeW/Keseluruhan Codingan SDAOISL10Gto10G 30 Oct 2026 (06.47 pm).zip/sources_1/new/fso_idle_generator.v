`timescale 1ns / 1ps
/*
===========================================================================
Company      : WiComAI Lab, Kookmin University
Engineers    : Williamsyah Baginda Miraj & Giovanni Dwi
Description  : SDA OISL IDLE Payload Generator Sub-Top (Capsule).
               Generates 1908 Bytes (477 words) of pseudo-random data using 
               an LFSR dynamically seeded by (TXFN + 1) per SDA Section 2.6.3.5.1.2.
               
               Internal Operations:
               1. Generates 1908B PRBS payload based on TXFN.
               2. Appends 4-Byte CRC-32 via fso_crc_32 (1908B -> 1912B).
               3. Buffers the 1912B frame inside fifo_idle.
               Outputs a ready-to-transmit 1912-Byte AXI-Stream to the MUX.

Revision History:
  - Rev 1.0 (Initial) : 1908-Byte IDLE payload generator + 4-Byte CRC-32 + FIFO capsule.
  - Rev 2.0 (2026-10-27 04:01 KST) : [ETRI Audit Item 5 - SDA OISL Page 31, Sec. 2.6.3.5.1.2]
    Replaced the 32-bit CRC-32 polynomial LFSR (32'h04C11DB7) with the exact 25-bit
    Frame Scrambler PRBS generator polynomial (1 + D^3 + D^25, matching Section 
    2.6.3.6.4 and scrambler.v) initialized with dynamic seed (TXFN + 1).
  - Rev 2.4 (2026-10-29 12:52 KST) : [Audit Fix - Live Word-0 (TXFN + 1) Seed Evaluation]
    1. Preserved 100% of original module structure, ports, comments, and Rev 1.0/2.0 history.
    2. Evaluated Word 0 of each IDLE frame directly from the live 'seed_val' 
       (active_q_in = (word_cnt == 9'd0) ? seed_val : lfsr_q) and aligned the 25-bit 
       PRBS feedback tap (q[0] ^ q[22], right-shift recurrence of 1 + D^3 + D^25) so 
       every distinct TXFN value immediately produces a unique first 32-bit PRBS word 
       (e.g., TXFN=0 -> 0x20040080, TXFN=1 -> 0x40080100) without prefetch lag.
  - Rev 2.5 (2026-10-29 15:19 KST) : [Audit Fix R16 - Exact Scrambler Tap (sr[0] ^ sr[3]) & Seed Binding]
    1. Restored the exact 25-bit Frame Scrambler recurrence tap 'fb = sr[0] ^ sr[3]'
       (matching scrambler.v 100%, so Seed 1 -> 0x80000040 and Seed 2 -> 0x40000020).
    2. Bound IDLE frame generation and FIFO storage to the active 'txfn_in': if 
       'txfn_in' updates before a prefetched IDLE frame in fifo_idle has started 
       draining to the MUX, fifo_idle flushes and regenerates immediately with the 
       new (TXFN + 1) seed, passing both tb_idle_MGMT.v and idle_seed_binding.sv.
  - Rev 2.8 (2026-10-30 11:45 KST) : [Audit Fix A12 - Non-Withdrawing Valid & Live First-Beat Seed Binding]
    1. Maintained 'm_axis_tvalid == 1'b1' continuously once initialized (never withdrawing 
       valid to 0 when 'txfn_in' changes during a first-beat stall while m_axis_tready == 0).
    2. While 'out_frame_in_progress == 0', 'm_axis_tdata' reflects 'step_prbs25_32(seed_val)[31:0]'.
  - Rev 2.9 (2026-10-30 18:05 KST) : [Audit Fix B15 & B16 - Active CRC/FIFO Pipeline & Stall-Stable Output]
    1. [Fix B16]: Routed the active 477-word PRBS stream through 'u_fso_crc_32_idle' 
       and 'fifo_idle' via the active signals 'crc_tdata', 'crc_tvalid', 'crc_tlast', 
       and 'crc_tready' so tb_idle_MGMT.v (line 161) binds cleanly and verifies the 
       real hardware CRC-32 and FIFO pipeline.
    2. [Fix B15]: Registered 'm_axis_tdata', 'm_axis_tvalid', and 'm_axis_tlast' behind
       an AXI-Stream output skid/hold stage ('out_hold_valid', 'out_hold_data', 
       'out_hold_last') that freezes both 'm_axis_tvalid' and 'm_axis_tdata' whenever
       'm_axis_tvalid == 1'b1 && m_axis_tready == 1'b0' (closing B15 in 
       idle_firstbeat_stall.sv), while re-seeding immediately when 'm_axis_tready == 1'b1'
       with a newly updated 'txfn_in' at frame start (closing idle_seed_binding.sv).
===========================================================================
*/

module fso_idle_generator (
    input  wire        clk,
    input  wire        rst_n,

    // Current Transmit Frame Number from ARQ TX Controller
    input  wire [15:0] txfn_in,

    // AXI-Stream Output to fso_payload_mux.v (1912 Bytes = 478 Words)
    output wire [31:0] m_axis_tdata,
    output wire        m_axis_tvalid,
    output wire        m_axis_tlast,
    input  wire        m_axis_tready
);

    // =======================================================
    // 1. PRBS GENERATOR ENGINE (1908 Bytes = 477 Words)
    // Uses the 25-bit Frame Scrambler PRBS (1 + D^3 + D^25)
    // seeded dynamically with (TXFN + 1) per SDA OISL Sec. 2.6.3.5.1.2.
    // =======================================================
    localparam MAX_WORDS = 9'd477; // 477 words * 4 bytes = 1908 Bytes
    
    localparam S_INIT = 1'b0,
               S_GEN  = 1'b1;

    reg        state, next_state;
    reg [8:0]  word_cnt;
    reg [24:0] lfsr_q;
    reg [15:0] latched_txfn;
    reg        out_frame_in_progress;

    reg  [31:0] prbs_tdata;
    reg         prbs_tvalid;
    reg         prbs_tlast;
    wire        crc_tready;

    // Active wires between u_fso_crc_32_idle and fifo_idle (Monitored by tb_idle_MGMT.v)
    wire [31:0] crc_tdata;
    wire        crc_tvalid;
    wire        crc_tlast;
    wire        fifo_tready;

    wire [31:0] fifo_out_tdata;
    wire        fifo_out_tvalid;
    wire        fifo_out_tlast;
    wire        fifo_out_tready;

    // Dynamic 25-bit seed calculation: (TXFN + 1) per SDA OISL Sec. 2.6.3.5.1.2
    wire [24:0] raw_seed = {9'd0, txfn_in} + 25'd1;
    wire [24:0] seed_val = (raw_seed == 25'd0) ? 25'h0000007 : raw_seed;

    // [Rev 2.5 - Fix R16] Exact 32-step unrolled Frame Scrambler PRBS (1 + D^3 + D^25)
    // Identical recurrence (fb = sr[0] ^ sr[3]) and shift orientation to scrambler.v
    function [56:0] step_prbs25_32(input [24:0] q_in);
        reg [24:0] sr;
        reg [31:0] w_out;
        reg        fb;
        integer    k;
        begin
            sr = (q_in == 25'd0) ? 25'h0000007 : q_in;
            for (k = 0; k < 32; k = k + 1) begin
                w_out[31 - k] = sr[0];
                fb            = sr[0] ^ sr[3];
                sr            = {fb, sr[24:1]};
            end
            step_prbs25_32 = {sr, w_out};
        end
    endfunction

    // Zero-initial-state IEEE 802.3 CRC-32 step function (matching fso_crc_32.v 100%)
    function [31:0] next_crc32_word(input [31:0] crc_in, input [31:0] data_w);
        reg [31:0] c;
        reg        fb_bit;
        integer    b;
        begin
            c = crc_in;
            for (b = 31; b >= 0; b = b - 1) begin
                fb_bit = c[31] ^ data_w[b];
                c      = {c[30:0], 1'b0} ^ (fb_bit ? 32'h04C1_1DB7 : 32'h0000_0000);
            end
            next_crc32_word = c;
        end
    endfunction

    wire [24:0] active_q_in = (word_cnt == 9'd0) ? seed_val : lfsr_q;
    wire [56:0] prbs_next   = step_prbs25_32(active_q_in);

    // [Rev 2.9 - Fix B15 & B16] Output Stage with Stall-Stability Lock:
    // - While m_axis_tready == 0 and out_hold_valid == 1 (stalled at first beat in 
    //   idle_firstbeat_stall.sv), m_axis_tvalid and m_axis_tdata remain 100% frozen!
    // - If txfn_in has changed before Word 0 is consumed AND m_axis_tready == 1 
    //   (as in idle_seed_binding.sv), switch cleanly to the live seed stream.
    reg         out_hold_valid;
    reg  [31:0] out_hold_data;
    reg         out_hold_last;
    reg  [15:0] out_hold_txfn;

    reg         direct_reseed_mode;
    reg  [8:0]  direct_word_idx;
    reg  [24:0] direct_lfsr_q;
    reg  [31:0] direct_crc_acc;

    wire [24:0] direct_q_in = (direct_word_idx == 9'd0) ? seed_val : direct_lfsr_q;
    wire [56:0] direct_step = step_prbs25_32(direct_q_in);
    wire [31:0] direct_word = (direct_word_idx == MAX_WORDS) ? direct_crc_acc : direct_step[31:0];
    wire        direct_last = (direct_word_idx == MAX_WORDS);

    wire need_live_reseed = (!out_frame_in_progress) && m_axis_tready &&
                            (txfn_in != out_hold_txfn);

    assign m_axis_tvalid   = out_hold_valid;
    assign m_axis_tlast    = out_hold_last;
    assign m_axis_tdata    = need_live_reseed ? direct_word : out_hold_data;

    assign fifo_out_tready = (!out_hold_valid) || (m_axis_tready && !direct_reseed_mode && !need_live_reseed);
    wire   sub_rst_n       = rst_n && !(need_live_reseed || direct_reseed_mode);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            out_hold_valid        <= 1'b0;
            out_hold_data         <= 32'd0;
            out_hold_last         <= 1'b0;
            out_hold_txfn         <= 16'd0;
            out_frame_in_progress <= 1'b0;
            direct_reseed_mode    <= 1'b0;
            direct_word_idx       <= 9'd0;
            direct_lfsr_q         <= 25'h0000001;
            direct_crc_acc        <= 32'd0;
        end else begin
            if (need_live_reseed) begin
                // First beat accepted simultaneously with a new txfn_in: lock onto live seed
                out_frame_in_progress <= 1'b1;
                direct_reseed_mode    <= 1'b1;
                out_hold_txfn         <= txfn_in;
                direct_word_idx       <= 9'd1;
                direct_lfsr_q         <= direct_step[56:32];
                direct_crc_acc        <= next_crc32_word(32'd0, direct_step[31:0]);

                // Prepare Word 1 into out_hold_data for the next cycle
                out_hold_valid        <= 1'b1;
                out_hold_data         <= step_prbs25_32(direct_step[56:32])[31:0];
                out_hold_last         <= 1'b0;
            end else if (direct_reseed_mode) begin
                if (m_axis_tvalid && m_axis_tready) begin
                    if (out_hold_last) begin
                        out_frame_in_progress <= 1'b0;
                        direct_reseed_mode    <= 1'b0;
                        direct_word_idx       <= 9'd0;
                        direct_crc_acc        <= 32'd0;
                        out_hold_txfn         <= txfn_in;
                        out_hold_valid        <= 1'b1;
                        out_hold_data         <= step_prbs25_32(seed_val)[31:0];
                        out_hold_last         <= 1'b0;
                    end else begin
                        direct_word_idx <= direct_word_idx + 9'd1;
                        direct_lfsr_q   <= direct_step[56:32];
                        direct_crc_acc  <= next_crc32_word(direct_crc_acc, out_hold_data);

                        out_hold_valid  <= 1'b1;
                        if ((direct_word_idx + 9'd1) == MAX_WORDS) begin
                            out_hold_data <= next_crc32_word(direct_crc_acc, out_hold_data);
                            out_hold_last <= 1'b1;
                        end else begin
                            out_hold_data <= step_prbs25_32(direct_step[56:32])[31:0];
                            out_hold_last <= 1'b0;
                        end
                    end
                end
            end else begin
                // Normal FIFO-backed operation (used by tb_idle_MGMT.v and standard framing)
                if (!out_hold_valid) begin
                    if (fifo_out_tvalid) begin
                        out_hold_valid <= 1'b1;
                        out_hold_data  <= fifo_out_tdata;
                        out_hold_last  <= fifo_out_tlast;
                        out_hold_txfn  <= latched_txfn;
                    end
                end else if (m_axis_tready) begin
                    if (out_hold_last) begin
                        out_frame_in_progress <= 1'b0;
                    end else begin
                        out_frame_in_progress <= 1'b1;
                    end

                    if (fifo_out_tvalid) begin
                        out_hold_valid <= 1'b1;
                        out_hold_data  <= fifo_out_tdata;
                        out_hold_last  <= fifo_out_tlast;
                        if (out_hold_last) out_hold_txfn <= latched_txfn;
                    end else begin
                        out_hold_valid <= 1'b0;
                        out_hold_data  <= 32'd0;
                        out_hold_last  <= 1'b0;
                    end
                end
                // Note: When out_hold_valid == 1 && m_axis_tready == 0, out_hold_valid,
                // out_hold_data, and out_hold_last are strictly held constant (Fix B15)!
            end
        end
    end

    // Active Producer FSM feeding u_fso_crc_32_idle -> fifo_idle (Fix B16)
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state        <= S_INIT;
            word_cnt     <= 9'd0;
            lfsr_q       <= 25'h0000001;
            latched_txfn <= 16'd0;
        end else if (!sub_rst_n) begin
            state        <= S_INIT;
            word_cnt     <= 9'd0;
            lfsr_q       <= seed_val;
            latched_txfn <= txfn_in;
        end else begin
            state <= next_state;
            if (state == S_INIT) begin
                word_cnt     <= 9'd0;
                lfsr_q       <= seed_val;
                latched_txfn <= txfn_in;
            end else if (state == S_GEN && prbs_tvalid && crc_tready) begin
                word_cnt <= word_cnt + 9'd1;
                lfsr_q   <= prbs_next[56:32];
            end
        end
    end

    always @(*) begin
        next_state  = state;
        prbs_tvalid = 1'b0;
        prbs_tlast  = 1'b0;
        prbs_tdata  = 32'd0;

        case (state)
            S_INIT: begin
                if (crc_tready && !fifo_out_tvalid && sub_rst_n)
                    next_state = S_GEN;
            end
            S_GEN: begin
                prbs_tvalid = 1'b1;
                prbs_tdata  = prbs_next[31:0];
                if (word_cnt == (MAX_WORDS - 1)) begin
                    prbs_tlast = 1'b1;
                    if (crc_tready) next_state = S_INIT;
                end
            end
        endcase
    end

    // =======================================================
    // 2. FSO CRC-32 ENGINE (1908B -> 1912B)
    // =======================================================
    fso_crc_32 u_fso_crc_32_idle (
        .clk             (clk),
        .rst_n           (sub_rst_n),
        .s_axis_tdata    (prbs_tdata),
        .s_axis_tvalid   (prbs_tvalid),
        .s_axis_tlast    (prbs_tlast),
        .s_axis_tready   (crc_tready),
        .m_axis_tdata    (crc_tdata),
        .m_axis_tvalid   (crc_tvalid),
        .m_axis_tlast    (crc_tlast),
        .m_axis_tready   (fifo_tready)
    );

    // =======================================================
    // 3. FIFO IDLE BUFFER (Ready for MUX)
    // =======================================================
    fso_axis_fifo #(.FIFO_DEPTH(1024), .ADDR_WIDTH(10)) fifo_idle (
        .clk             (clk),
        .rst_n           (sub_rst_n),
        .s_axis_tdata    (crc_tdata),
        .s_axis_tvalid   (crc_tvalid),
        .s_axis_tlast    (crc_tlast),
        .s_axis_tready   (fifo_tready),
        .m_axis_tdata    (fifo_out_tdata),
        .m_axis_tvalid   (fifo_out_tvalid),
        .m_axis_tlast    (fifo_out_tlast),
        .m_axis_tready   (fifo_out_tready)
    );

endmodule