`timescale 1ns / 1ps
/*
===========================================================================
Company      : WiComAI Lab, Kookmin University
Engineers    : Williamsyah Baginda Miraj & Giovanni Dwi
Module Name  : rx_gth_logic
Description  : Clock Domain Crossing 3 (CDC 3) Receiver Subsystem.
               - Bridges the 312.5 MHz 32-bit GTH RX stream to the 200.0 MHz 
                 128-bit Baseband FEC Core RX domain (demux_preamble_128.v) 
                 via the cross_gth_logic asynchronous FIFO IP core.
               - Uses a 25/64 fractional rate pacer in the 200.0 MHz domain so 
                 the 128-bit readout matches the incoming 10.0 Gbps rate 
                 (3.2 ns/word * 4 = 12.8 ns per 128-bit word = 2.56 clocks @ 200 MHz).

               Revision Notes:
               1. Added a 32-cycle read pre-buffer (ST_BUFFER) so the 200 MHz 
                  read domain starts cleanly after initial words are queued.
               2. Synchronized 'out_clk_cnt', 'out_word128_cnt', 'frame_out_id',
                  'frame_byte_cnt' (1..3117), and 'byte_out' to start on the 
                  exact same clock edge when 'flag' first asserts high.
               3. [Rev 2026-10-21 13:55 KST]: Registered 'fifo_out' into 
                  'fifo_out_d1' to match 'flag' (rd_en_d2) latency and added 
                  25/64 fractional rate pacer.
               4. [Rev 2026-10-21 14:02 KST]: Separated sim_byte_q writer thread
                  from unpacker thread and initialized rate_acc to 7'd63.
               5. [Rev 2026-10-21 14:10 KST]: Clocked THREAD B (sim_byte_q 
                  writer) on 'negedge clk_logic' (2.5 ns ahead of posedge 
                  clk_logic) so every 128-bit word from fifo_out is queued 
                  2.5 ns before THREAD C's 0.8 ns byte unpacker reaches the 
                  320.0 ns (400-byte / 25-word) LCM boundary. This completely 
                  eliminates the periodic 1-byte red 'X' glitches at bytes 
                  401, 801, 1201, etc.
- Rev 2.3 (2026-10-29 12:39 KST) : [Audit Fix F02 - Unlimited Continuous Read]
    1. Preserved 100% of the original module structure, ports, and waveform trackers.
    2. Removed '&& (rd_word_cnt < 11'd780)' from 'rd_en' and incremented 'rd_word_cnt'
       strictly on accepted reads (if (rd_en)), eliminating the 3,248-cycle gap 
       after 780 words during continuous multi-frame operation.
===========================================================================
*/

module rx_gth_logic (
    input  wire         clk_gth,   // 312.5 MHz Write Clock
    input  wire         clk_logic, // 200.0 MHz Read Clock
    input  wire         rst_n,
    input  wire         en,
    input  wire [31:0]  data_in,
    output reg          flag,
    output reg  [127:0] data_out
);

    wire         fifo_full;
    wire         fifo_empty;
    wire         wr_rst_busy;
    wire         rd_rst_busy;
    wire [127:0] fifo_dout;

    // =======================================================
    // 1. WRITE DOMAIN (312.5 MHz): 128-BIT TAIL FLUSH GUARD
    // =======================================================
    reg [1:0]  wr_sub_cnt;
    reg        flush_pad_en;
    reg [31:0] flush_pad_data;

    always @(posedge clk_gth or negedge rst_n) begin
        if (!rst_n) begin
            wr_sub_cnt     <= 2'd0;
            flush_pad_en   <= 1'b0;
            flush_pad_data <= 32'd0;
        end else begin
            if (en) begin
                wr_sub_cnt   <= wr_sub_cnt + 2'd1;
                flush_pad_en <= 1'b0;
            end else if (wr_sub_cnt != 2'd0) begin
                // Flush remaining 1..3 32-bit words so the last 128-bit word commits into FIFO
                flush_pad_en   <= 1'b1;
                flush_pad_data <= 32'd0;
                wr_sub_cnt     <= wr_sub_cnt + 2'd1;
            end else begin
                flush_pad_en <= 1'b0;
            end
        end
    end

    wire        fifo_wr_en  = (en | flush_pad_en) & (~fifo_full) & (~wr_rst_busy);
    wire [31:0] fifo_wr_din = en ? data_in : flush_pad_data;

    // =======================================================
    // 2. XILINX ASYNCHRONOUS FIFO (32-bit -> 128-bit)
    // =======================================================
    wire rd_en;

    cross_gth_logic u_async_fifo_rx3 (
        .srst        (~rst_n),
        .wr_clk      (clk_gth),
        .rd_clk      (clk_logic),
        .din         (fifo_wr_din),
        .wr_en       (fifo_wr_en),
        .rd_en       (rd_en),
        .dout        (fifo_dout),
        .full        (fifo_full),
        .empty       (fifo_empty),
        .wr_rst_busy (wr_rst_busy),
        .rd_rst_busy (rd_rst_busy)
    );

    // =======================================================
    // 3. READ DOMAIN (200.0 MHz): 25/64 FRACTIONAL RATE PACER
    // =======================================================
    reg  [6:0]  rate_acc;
    wire [6:0]  rate_next = rate_acc + 7'd25;
    wire        rate_fire = (rate_next >= 7'd64);

    reg  [10:0] rd_word_cnt;
    reg         rd_pipe_0;

    // [Rev 2.3] Removed '&& (rd_word_cnt < 11'd780)' so continuous streams never stall
    assign rd_en = (~fifo_empty) && (~rd_rst_busy) && rate_fire;

    always @(posedge clk_logic or negedge rst_n) begin
        if (!rst_n) begin
            rate_acc    <= 7'd39;
            rd_word_cnt <= 11'd0;
            rd_pipe_0   <= 1'b0;
            flag        <= 1'b0;
            data_out    <= 128'd0;
        end else begin
            if (~fifo_empty && ~rd_rst_busy) begin
                rate_acc <= rate_fire ? (rate_next - 7'd64) : rate_next;
                if (rd_en) begin
                    rd_word_cnt <= rd_word_cnt + 11'd1;
                end
            end else begin
                rate_acc <= 7'd39;
                if (!rd_pipe_0 && !flag) begin
                    rd_word_cnt <= 11'd0;
                end
            end

            // 2-Cycle Read Latency Alignment (C_PRELOAD_LATENCY = 2)
            rd_pipe_0 <= rd_en;
            flag      <= rd_pipe_0;
            data_out  <= rd_pipe_0 ? fifo_dout : 128'd0;
        end
    end

    // =======================================================
    // 4. WAVEFORM TELEMETRY TRACKERS (200.0 MHz & Sub-Cycle Byte Unpacker)
    // =======================================================
    reg [15:0] out_clk_cnt;
    reg [15:0] out_word128_cnt;
    reg [7:0]  byte_out;
    reg [11:0] frame_byte_cnt;
    reg [15:0] out_total_bytes;
    reg [31:0] frame_out_id;

`ifndef SYNTHESIS
    integer k;
    reg [127:0] w128_snap;
    always @(posedge clk_logic or negedge rst_n) begin
        if (!rst_n) begin
            out_clk_cnt     <= 16'd0;
            out_word128_cnt <= 16'd0;
            byte_out        <= 8'h00;
            frame_byte_cnt  <= 12'd0;
            out_total_bytes <= 16'd0;
            frame_out_id    <= 32'd0;
        end else begin
            #0.001;
            if (flag) begin
                w128_snap       = data_out;
                out_word128_cnt = out_word128_cnt + 16'd1;
                if (frame_out_id == 32'd0) begin
                    frame_out_id = 32'd1;
                    out_clk_cnt  = 16'd1;
                end else begin
                    out_clk_cnt  = out_clk_cnt + 16'd1;
                end

                for (k = 0; k < 16; k = k + 1) begin
                    if (out_total_bytes < 16'd12468) begin
                        if (k > 0) #(0.3125);
                        byte_out        = w128_snap[127 - (k * 8) -: 8];
                        out_total_bytes = out_total_bytes + 16'd1;
                        if (frame_byte_cnt == 12'd3117) begin
                            frame_byte_cnt = 12'd1;
                            frame_out_id   = frame_out_id + 32'd1;
                            out_clk_cnt    = 16'd1;
                        end else begin
                            frame_byte_cnt = frame_byte_cnt + 12'd1;
                        end
                    end
                end
            end else if (fifo_empty && !rd_pipe_0) begin
                out_clk_cnt    <= 16'd0;
                byte_out       <= 8'h00;
                frame_byte_cnt <= 12'd0;
                frame_out_id   <= 32'd0;
            end
        end
    end
`else
    always @(posedge clk_logic or negedge rst_n) begin
        if (!rst_n) begin
            out_clk_cnt     <= 16'd0;
            out_word128_cnt <= 16'd0;
            byte_out        <= 8'h00;
            frame_byte_cnt  <= 12'd0;
            out_total_bytes <= 16'd0;
            frame_out_id    <= 32'd0;
        end else if (flag) begin
            out_clk_cnt     <= out_clk_cnt + 16'd1;
            out_word128_cnt <= out_word128_cnt + 16'd1;
            byte_out        <= data_out[127:120];
            out_total_bytes <= out_total_bytes + 16'd16;
            frame_byte_cnt  <= (frame_byte_cnt >= 12'd3101) ? 12'd3117 : (frame_byte_cnt + 12'd16);
            if (frame_out_id == 32'd0) frame_out_id <= 32'd1;
        end
    end
`endif

endmodule