`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: WiComAI Lab
// Description: Testbench Isolasi Demultiplexer 128-bit & Preamble Checker
//
// Revision History:
//   - Rev 1.0 (Initial) : 128-bit Demultiplexer & Preamble Checker isolation TB.
//   - Rev 2.0 (2026-10-27 15:20 KST) : [ETRI Audit Item 1 & Target B1.1 Fix]
//     1. Fixed checker module instantiation name from 'preamble_sda_dec' to 
//        'preamble_sda_decoder' to match preamble_sda_decoder.v.
//     2. Aligned 128-bit input word format to MSB-first per SDA OISL Table 2-8 
//        (Page 23) and mux_gearbox_128.v: {72'h77_AD_5B_58_43_64_1E_2E_26, 56'hAAAA_BBBB_CCCC_DD}.
//     3. Streamed a complete 195-word (3,117-Byte) frame with 25/64 CDC 3 pacing 
//        so demux_preamble_128 crosses its 1600-Byte pre-buffer threshold, 
//        extracts preamble_extracted = 72'h77AD5B5843641E2E26, asserts 
//        link_locked = 1'b1, and outputs all 259 contiguous 96-bit LPC words (3,108 Bytes).
//   - Rev 2.3 (2026-10-29 01:49 KST) : [Unified 4-Frame Scenario & Counter Alignment]
//     1. Preserved all original comments and Rev 1.0/2.0 history logs 100% intact.
//     2. Upgraded stimulus to stream all 4 sequential FSO frames (DAT1, DAT2, IDLE, 
//        MGMT = 4 x 3117 Bytes = 12,468 Bytes) with standardized counters: 
//        demux_frame_id (1..4), frame_type_str, in_clk_cnt, in_byte_cnt (1..3117), 
//        out_clk_cnt (1..259), and out_byte_cnt (12..3108).
//////////////////////////////////////////////////////////////////////////////////

module tb_demux_decoder();

    reg clk;
    reg rst_n;
    
    // Stimulus dari CDC
    reg [127:0] cdc_data_in;
    reg         cdc_valid_in;
    
    // Observasi Output
    wire [71:0] preamble_extracted;
    wire        preamble_valid;
    wire [95:0] lpc_data_out;
    wire        lpc_valid_out;
    wire        link_locked;

    // Standardized Waveform Counters & Frame Labels
    wire [8:0]  out_clk_cnt      = u_demux.out_lpc_word_cnt; // 1..259 Clocks
    wire [11:0] out_byte_cnt     = u_demux.out_lpc_byte_cnt; // 12..3108 Bytes
    wire [31:0] demux_frame_id   = u_demux.demux_frame_id;   // 1..4
    wire [15:0] locked_frame_cnt = u_checker.locked_frame_cnt;
    reg  [31:0] frame_type_str;
    reg  [15:0] in_clk_cnt;
    reg  [11:0] in_byte_cnt;

    always @(*) begin
        case (demux_frame_id)
            32'd1:   frame_type_str = "DAT1";
            32'd2:   frame_type_str = "DAT2";
            32'd3:   frame_type_str = "IDLE";
            32'd4:   frame_type_str = "MGMT";
            default: frame_type_str = "WAIT";
        endcase
    end

    // 1. Initiation Demux
    demux_preamble_128 u_demux (
        .clk(clk),
        .rst_n(rst_n),
        .cdc_data_in(cdc_data_in),
        .cdc_valid_in(cdc_valid_in),
        .preamble_extracted(preamble_extracted),
        .preamble_valid(preamble_valid),
        .lpc_data_out(lpc_data_out),
        .lpc_valid_out(lpc_valid_out)
    );

    // 2. Initiation Preamble Checker ([Rev 2.0] Fixed module name to preamble_sda_decoder)
    preamble_sda_decoder u_checker (
        .clk(clk),
        .rst_n(rst_n),
        .preamble_in(preamble_extracted),
        .preamble_valid_in(preamble_valid),
        .link_locked_out(link_locked)
    );

    // Clock 200 MHz
    always #2.5 clk = ~clk;

    function [7:0] get_frame_byte(input [31:0] f_idx, input [11:0] b_idx);
        begin
            case (b_idx)
                12'd1:   get_frame_byte = 8'h77;
                12'd2:   get_frame_byte = 8'hAD;
                12'd3:   get_frame_byte = 8'h5B;
                12'd4:   get_frame_byte = 8'h58;
                12'd5:   get_frame_byte = 8'h43;
                12'd6:   get_frame_byte = 8'h64;
                12'd7:   get_frame_byte = 8'h1E;
                12'd8:   get_frame_byte = 8'h2E;
                12'd9:   get_frame_byte = 8'h26;
                12'd10:  get_frame_byte = 8'hAB;
                12'd13:  get_frame_byte = f_idx[7:0];
                12'd3117:get_frame_byte = 8'h33;
                default: begin
                    if      (f_idx <= 32'd2) get_frame_byte = 8'hDA;
                    else if (f_idx == 32'd3) get_frame_byte = 8'h1D;
                    else                     get_frame_byte = 8'hA1;
                end
            endcase
        end
    endfunction

    integer i, k, abs_b;
    reg [127:0] word128_tmp;
    integer lpc_out_cnt = 0;

    always @(posedge clk) begin
        if (preamble_valid) begin
            $display(" [%0t] Preamble Extracted = 0x%018X (Expected: 0x77AD5B5843641E2E26)",
                     $time, preamble_extracted);
        end
        if (lpc_valid_out) begin
            lpc_out_cnt <= lpc_out_cnt + 1;
        end
    end

    initial begin
        // Initiation
        clk          = 0;
        rst_n        = 0;
        cdc_data_in  = 0;
        cdc_valid_in = 0;
        in_clk_cnt   = 0;
        in_byte_cnt  = 0;

        #20;
        rst_n = 1;
        #20;

        // ------ SCENARIO 1 & 2: FLOW FLOW 4 FRAMES (DAT1, DAT2, IDLE, MGMT = 780 Word 128-bit / 12,468 Byte) ---
        // The first word contains {72'h77_AD_5B_58_84_64_1_1_2E_2E_26, 56-bit LPC Initial data} in MSB [127:56]
        for (i = 0; i < 780; i = i + 1) begin
            for (k = 0; k < 16; k = k + 1) begin
                abs_b = i * 16 + k;
                if (abs_b < 12468)
                    word128_tmp[127 - (k * 8) -: 8] = get_frame_byte((abs_b / 3117) + 1, (abs_b % 3117) + 1);
                else
                    word128_tmp[127 - (k * 8) -: 8] = 8'd0;
            end
            @(posedge clk);
            cdc_valid_in <= 1'b1;
            cdc_data_in  <= word128_tmp;
            in_clk_cnt   <= (i % 195) + 1;
            in_byte_cnt  <= ((i * 16) % 3117) + 16;
        end

        // Finish transmission
        @(posedge clk);
        cdc_valid_in <= 1'b0;
        cdc_data_in  <= 128'd0;
        in_clk_cnt   <= 16'd0;
        in_byte_cnt  <= 12'd0;

       // Wait for all 1036 words LPC (4 x 259 words = 12,432 Bytes) finished issued continuously
        wait(lpc_out_cnt == 1036);
        #200;
        $display("\n=======================================================");
        $display(" DEMUX 128 & PREAMBLE DECODER 4-FRAME VERIFICATION REPORT");
        $display(" -> Extracted Preamble : 0x%018X", preamble_extracted);
        $display(" -> Link Locked Status : %0b (Locked Frames: %0d / 4)", link_locked, locked_frame_cnt);
        $display(" -> Contiguous LPC Out : %0d Words (%0d Bytes, Expected: 1036 Words / 12432B)",
                 lpc_out_cnt, lpc_out_cnt * 12);
        if ((preamble_extracted == 72'h77_AD_5B_58_43_64_1E_2E_26) &&
            (link_locked == 1'b1) && (lpc_out_cnt == 1036))
            $display(" -> RESULT: [PASS] 100%% COMPLIANT WITH SDA OISL TABLE 2-8!");
        $display("=======================================================\n");
        $finish;
    end

endmodule