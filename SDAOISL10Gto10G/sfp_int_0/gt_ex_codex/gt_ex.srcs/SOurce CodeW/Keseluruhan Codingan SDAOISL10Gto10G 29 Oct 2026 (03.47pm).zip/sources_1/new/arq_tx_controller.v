`timescale 1ns / 1ps
/*
===========================================================================
Company      : WiComAI Lab, Kookmin University
Engineers    : Williamsyah Baginda Miraj & Giovanni Dwi
Description  : Selective Repeat ARQ Transmit Controller & Frame Scheduler 
               with Autonomous Holdoff Tracking and SDA OISL Table 2-9 & 
               Table 2-11 Parameters:
               - Priority 1: Retransmission (Timer Expired OR NAK Received).
               - Priority 2: 1Hz Management (MGMT) Frame.
               - Priority 3: Normal Ethernet Data (DATA) Frame.
               - Priority 4: IDLE Frame (When no data is available).
               
               Features:
               - Multi-Slot Outstanding Frame Tracker (Supports In-Flight Packets).
               - Automatic RAM Write, Read (Retx), and Delete (ACK/Drop) signaling.
               - Configurable ARQ_MAX_RETX (Default = 5 per SDA OISL Table 2-11).
                
                SDA OISL TABLE 2-11 PARAMETERS:
               - ARQ_MAX_RETX           = 3'd5   (Max retries before drop: 0..5)
               - ARQ_HOLDOFF_CFG        = 8'd255 (8-bit register setting: 1..255)
               - ARQ_HOLDOFF_MULT       = 16     (Table 2-11 'times 16' step;
                                                  configurable to 32 or 64)
               - ARQ_HOLDOFF_MAX_FRAMES = 4080   (255 x 16 frames = 10.174 ms)
               - SIM_SCALE_ENABLE       = 1      (Uses HOLDOFF_TICKS for fast 
                                                  simulation; set 0 for full 
                                                  4080-frame hardware timer)
                
Revision History:
  - Rev 1.0 (Initial) : Priority-based Selective Repeat ARQ TX Controller & Frame Scheduler.
  - Rev 2.0 (2026-10-27 04:26 KST) : [Target B5.4 - SDA OISL Page 25-26, Sec. 2.6.3.3.3 & Table 2-11]
    1. Added official SDA OISL Table 2-11 parameters:
       - ARQ_HOLDOFF_CFG  (8-bit, range 1..255, default 255)
       - ARQ_HOLDOFF_MULT (16 frames per Table 2-11; configurable to 64 for 
         5000 km LEO S2S extension = 16,320 frames = 40.696 ms RTT window)
       - SIM_SCALE_ENABLE (1 = fast simulation tick per clock using HOLDOFF_TICKS;
         0 = hardware frame-granular decrement per tx_trigger_gen pulse).
    2. Aligned 'track_timer' decrement step with Table 2-11 frame units: when 
       SIM_SCALE_ENABLE == 0 (Hardware Mode), track_timer decrements once per 
       transmitted frame (on tx_trigger_gen) so that ARQ_HOLDOFF_CFG * ARQ_HOLDOFF_MULT 
       (e.g., 255 * 16 = 4080 frames or project-specific extension 255 * 64 = 16,320 frames) 
       measures exact FSO frames (2.4936 us/frame). When SIM_SCALE_ENABLE == 1, 
       retains cycle-tick scaling for fast testbench verification.
    3. Enabled ARQ disabling when ARQ_MAX_RETX == 3'd0 per Section 2.6.3.3.3.
  - Rev 2.3 (2026-10-29 12:39 KST) : [Audit Fix F01 - Tracker Slot Allocation, Retry & Drop]
    Removed '&& tx_trigger_gen' phase mismatch from tracker slot allocation and retry update.
  - Rev 2.5 (2026-10-29 15:19 KST) : [Audit Fix R06, R07 & R08]
    1. [Fix R07]: Parameterized index width 'IDX_BITS = (TRACKER_DEPTH > 1) ? $clog2(TRACKER_DEPTH) : 1'
       so overriding TRACKER_DEPTH (e.g., TRACKER_DEPTH = 8 in arq_depth8.sv) tracks all 
       slots without 2-bit aliasing onto Slot 0.
    2. [Fix R08]: Consolidated all 'ddr4_addr' assignments into a single clocked always 
       block to eliminate multiple procedural drivers.
    3. [Fix R06]: Prevented 'tx_stall_mac' from asserting mid-frame during an active 
       DATA transmission (payload_mux_sel == 2'b01 && header_gen_busy), preventing 
       deadlock when the last tracker slot is allocated under SIM_SCALE_ENABLE = 0.
===========================================================================
*/

module arq_tx_controller #(
    parameter [2:0]  ARQ_MAX_RETX      = 3'd5,     // SDA OISL Table 2-11: 0..5 (Default = 5; 0 = ARQ Disabled)
    parameter [7:0]  ARQ_HOLDOFF_CFG   = 8'd255,   // SDA OISL Table 2-11: 1..255 (8-bit configuration)
    parameter integer ARQ_HOLDOFF_MULT = 16,       // 16 = Strict Table 2-11 (x16 frames); 64 = 5000 km Extension
    parameter        SIM_SCALE_ENABLE  = 1,        // 1 = Use HOLDOFF_TICKS for fast simulation; 0 = Frame-granular
    parameter [15:0] HOLDOFF_TICKS     = 16'd500,  // Simulation scaled holdoff ticks when SIM_SCALE_ENABLE = 1
    parameter integer TRACKER_DEPTH    = 4         // Number of concurrent frames tracked in flight
)(
    input  wire        clk,
    input  wire        rst_n,

    // --- Traffic & Timing Monitors ---
    input  wire        fso_data_valid,   // Asserted when fifo_data has 1912B ready
    input  wire        mgmt_tick_1hz,    // 1Hz pulse to trigger MGMT frame
    input  wire        header_gen_busy,  // From fso_header_top (Wait for current frame to finish)

    // --- ARQ Feedback from RX Decoder (Remote Terminal) ---
    input  wire [15:0] rx_rxfn_in,       // RXFN received from remote terminal
    input  wire        rx_ack_in,        // 1 = ACK, 0 = NAK
    input  wire        rx_ack_valid_in,  // 1 = Valid ARQ feedback present

    // --- Outputs to Header Generator & Payload MUX ---
    output reg  [15:0] tx_txfn_out,      // Current TXFN to be transmitted
    output reg  [1:0]  tx_frame_type,    // 00=IDLE, 01=DATA, 10=MGMT
    output reg         tx_trigger_gen,   // Fires the Header Generator
    output reg  [1:0]  payload_mux_sel,  // 00=IDLE, 01=DATA, 10=MGMT, 11=RETX
    output wire        tx_stall_mac,     // Stalls normal Ethernet data during Retx/MGMT

    // --- Outputs to ARQ DDR4 Wrapper ---
    output reg         ddr4_write_req,   // Sniff and store current DATA frame
    output reg         ddr4_read_req,    // Fetch frame from RAM for Retransmission
    output reg         ddr4_delete_req,  // Free RAM slot upon ACK or Max Retries
    output reg  [15:0] ddr4_addr         // Target Frame Number (TXFN) in RAM
);

    localparam integer IDX_BITS = (TRACKER_DEPTH > 1) ? $clog2(TRACKER_DEPTH) : 1;

    // =======================================================
    // 1. OUTSTANDING FRAME TRACKER TABLE (CAM-like Structure)
    // =======================================================
    localparam [15:0] TABLE_2_11_HOLDOFF_FRAMES = ARQ_HOLDOFF_CFG * ARQ_HOLDOFF_MULT;
    wire       [15:0] active_holdoff_limit      = SIM_SCALE_ENABLE ? HOLDOFF_TICKS : TABLE_2_11_HOLDOFF_FRAMES;
    wire       [2:0]  eff_max_retx              = (ARQ_MAX_RETX > 3'd5) ? 3'd5 : ARQ_MAX_RETX;
    wire              arq_disabled              = (eff_max_retx == 3'd0) || (ARQ_HOLDOFF_CFG == 8'd0);

    reg        track_valid [0:TRACKER_DEPTH-1];
    reg [15:0] track_txfn  [0:TRACKER_DEPTH-1];
    reg [15:0] track_timer [0:TRACKER_DEPTH-1];
    reg [2:0]  track_retx  [0:TRACKER_DEPTH-1];

    reg [15:0] global_txfn;  // Master sequence counter for new frames
    reg        mgmt_pending; // Latch for 1Hz MGMT request

    integer i;

    // =======================================================
    // 2. COMBINATIONAL SEARCH ENGINE (Priority Resolver)
    // =======================================================
    reg                retx_needed;
    reg [IDX_BITS-1:0] retx_index;
    reg                drop_needed;
    reg [IDX_BITS-1:0] drop_index;
    reg                free_found;
    reg [IDX_BITS-1:0] free_index;

    always @(*) begin
        retx_needed = 1'b0;
        retx_index  = {IDX_BITS{1'b0}};
        drop_needed = 1'b0;
        drop_index  = {IDX_BITS{1'b0}};
        free_found  = 1'b0;
        free_index  = {IDX_BITS{1'b0}};

        for (i = 0; i < TRACKER_DEPTH; i = i + 1) begin
            // Find any slot whose timer has expired (== 0)
            if (track_valid[i] && (track_timer[i] == 16'd0)) begin
                if (track_retx[i] < eff_max_retx) begin
                    if (!retx_needed) begin
                        retx_needed = 1'b1;
                        retx_index  = i[IDX_BITS-1:0];
                    end
                end else begin
                    if (!drop_needed) begin
                        drop_needed = 1'b1;
                        drop_index  = i[IDX_BITS-1:0];
                    end
                end
            end
            // Find an empty slot for new incoming DATA frames
            if (!track_valid[i] && !free_found) begin
                free_found = 1'b1;
                free_index = i[IDX_BITS-1:0];
            end
        end
    end

    // =======================================================
    // 3. SELECTIVE REPEAT ARQ STATE MACHINE
    // =======================================================
    localparam S_IDLE        = 3'd0,
               S_ARBITRATE   = 3'd1,
               S_EXEC_RETX   = 3'd2,
               S_EXEC_MGMT   = 3'd3,
               S_EXEC_DATA   = 3'd4,
               S_EXEC_IDLE   = 3'd5,
               S_WAIT_FRAME  = 3'd6;

    reg [2:0]          state, next_state;
    reg [IDX_BITS-1:0] target_index; // Latched index for current operation

    // [Rev 2.5 - Fix R06] Never stall the currently executing DATA frame while it is streaming
    wire active_data_in_flight = (state == S_EXEC_DATA) ||
                                 ((state == S_WAIT_FRAME) && (payload_mux_sel == 2'b01));

    assign tx_stall_mac = (state == S_EXEC_RETX) || (state == S_EXEC_MGMT) ||
                          (payload_mux_sel == 2'b11) || (payload_mux_sel == 2'b10) ||
                          (!arq_disabled && !free_found && !active_data_in_flight);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) state <= S_IDLE;
        else        state <= next_state;
    end

    always @(*) begin
        next_state = state;
        case (state)
            S_IDLE: begin
                if (!header_gen_busy && !tx_trigger_gen) next_state = S_ARBITRATE;
            end
            
            S_ARBITRATE: begin
                // STRICT PRIORITY ENFORCEMENT:
                // Priority 1: Timer expired OR NAK received -> Retransmit!
                if (!arq_disabled && retx_needed)     next_state = S_EXEC_RETX;
                // Priority 2: 1Hz MGMT Schedule
                else if (mgmt_pending)                next_state = S_EXEC_MGMT;
                // Priority 3: Normal Ethernet Data available (and tracker slot available)
                else if (fso_data_valid && (arq_disabled || free_found)) next_state = S_EXEC_DATA;
                // Priority 4: Nothing to send -> Stream IDLE
                else                                  next_state = S_EXEC_IDLE;
            end

            S_EXEC_RETX, S_EXEC_MGMT, S_EXEC_DATA, S_EXEC_IDLE: begin
                next_state = S_WAIT_FRAME;
            end

            S_WAIT_FRAME: begin
                if (!header_gen_busy && !tx_trigger_gen) next_state = S_IDLE;
            end
            
            default: next_state = S_IDLE;
        endcase
    end

    // =======================================================
    // 4. UNIFIED OUTPUT, TRACKER & DDR4_ADDR EXECUTION LOGIC
    //    [Rev 2.5 - Fix R08] Single clocked always block owns ddr4_addr
    // =======================================================
    wire timer_tick_en = SIM_SCALE_ENABLE ? 1'b1 : tx_trigger_gen;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            global_txfn     <= 16'd0;
            tx_txfn_out     <= 16'd0;
            tx_frame_type   <= 2'b00;
            tx_trigger_gen  <= 1'b0;
            payload_mux_sel <= 2'b00;
            ddr4_write_req  <= 1'b0;
            ddr4_read_req   <= 1'b0;
            ddr4_delete_req <= 1'b0;
            ddr4_addr       <= 16'd0;
            mgmt_pending    <= 1'b0;
            target_index    <= {IDX_BITS{1'b0}};
            for (i = 0; i < TRACKER_DEPTH; i = i + 1) begin
                track_valid[i] <= 1'b0;
                track_txfn[i]  <= 16'd0;
                track_timer[i] <= 16'd0;
                track_retx[i]  <= 3'd0;
            end
        end else begin
            // Default pulse resets
            tx_trigger_gen  <= 1'b0;
            ddr4_write_req  <= 1'b0;
            ddr4_read_req   <= 1'b0;
            ddr4_delete_req <= 1'b0;

            // Latch 1Hz MGMT Trigger
            if (mgmt_tick_1hz) mgmt_pending <= 1'b1;

            // ---------------------------------------------------
            // A. Autonomous Timer Decrement & Max-Retry Exhaustion Drop
            // ---------------------------------------------------
            for (i = 0; i < TRACKER_DEPTH; i = i + 1) begin
                if (track_valid[i]) begin
                    if (track_timer[i] > 16'd0) begin
                        if (timer_tick_en) begin
                            track_timer[i] <= track_timer[i] - 1'b1;
                        end
                    end else if (drop_needed && (i[IDX_BITS-1:0] == drop_index) &&
                                 (state != S_EXEC_DATA) && (state != S_EXEC_RETX)) begin
                        track_valid[i]  <= 1'b0;
                        ddr4_delete_req <= 1'b1;
                        ddr4_addr       <= track_txfn[i];
                    end
                end
            end

            // ---------------------------------------------------
            // B. Process Incoming RX Feedback (ACK / NAK)
            // ---------------------------------------------------
            if (rx_ack_valid_in) begin
                for (i = 0; i < TRACKER_DEPTH; i = i + 1) begin
                    if (track_valid[i] && (track_txfn[i] == rx_rxfn_in)) begin
                        if (rx_ack_in == 1'b1) begin
                            track_valid[i]  <= 1'b0;
                            ddr4_delete_req <= 1'b1;
                            ddr4_addr       <= rx_rxfn_in;
                        end else begin
                            track_timer[i]  <= 16'd0;
                        end
                    end
                end
            end

            // ---------------------------------------------------
            // C. State Machine Command & Tracker Slot Execution
            // ---------------------------------------------------
            case (state)
                S_ARBITRATE: begin
                    if (!arq_disabled && retx_needed)      target_index <= retx_index;
                    else if (fso_data_valid && free_found) target_index <= free_index;
                end

                S_EXEC_RETX: begin
                    tx_txfn_out     <= track_txfn[target_index];
                    tx_frame_type   <= 2'b01;
                    payload_mux_sel <= 2'b11;
                    tx_trigger_gen  <= 1'b1;
                    ddr4_read_req   <= 1'b1;
                    ddr4_addr       <= track_txfn[target_index];

                    track_retx[target_index]  <= track_retx[target_index] + 1'b1;
                    track_timer[target_index] <= active_holdoff_limit;
                end

                S_EXEC_MGMT: begin
                    tx_txfn_out     <= global_txfn;
                    tx_frame_type   <= 2'b10;
                    payload_mux_sel <= 2'b10;
                    tx_trigger_gen  <= 1'b1;
                    mgmt_pending    <= 1'b0;
                    global_txfn     <= global_txfn + 1'b1;
                end

                S_EXEC_DATA: begin
                    tx_txfn_out     <= global_txfn;
                    tx_frame_type   <= 2'b01;
                    payload_mux_sel <= 2'b01;
                    tx_trigger_gen  <= 1'b1;
                    ddr4_write_req  <= ~arq_disabled;
                    ddr4_addr       <= global_txfn;
                    global_txfn     <= global_txfn + 1'b1;

                    if (!arq_disabled && free_found) begin
                        track_valid[target_index] <= 1'b1;
                        track_txfn[target_index]  <= global_txfn;
                        track_timer[target_index] <= active_holdoff_limit;
                        track_retx[target_index]  <= 3'd0;
                    end
                end

                S_EXEC_IDLE: begin
                    tx_txfn_out     <= global_txfn;
                    tx_frame_type   <= 2'b00;
                    payload_mux_sel <= 2'b00;
                    tx_trigger_gen  <= 1'b1;
                    global_txfn     <= global_txfn + 1'b1;
                end
            endcase
        end
    end

endmodule