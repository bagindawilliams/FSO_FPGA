`timescale 1ns / 1ps
/*
===========================================================================
Company      : WiComAI Lab, Kookmin University
Engineers    : Williamsyah Baginda Miraj & Giovanni Dwi
Description  : SDA OISL IDLE Payload Generator Sub-Top (Capsule).
               Generates 1908 Bytes (477 words) of pseudo-random data using 
               an LFSR dynamically seeded by (TXFN + 1) per SDA Section 2.6.3.5.1.2.
               
               Internal Operations:
               1. Generates 1908B PRBS payload based on TXFN.
               2. Appends 4-Byte CRC-32 via fso_crc_32 (1908B -> 1912B).
               3. Buffers the 1912B frame inside fifo_idle.
               Outputs a ready-to-transmit 1912-Byte AXI-Stream to the MUX.

Revision History:
  - Rev 1.0 (Initial) : 1908-Byte IDLE payload generator + 4-Byte CRC-32 + FIFO capsule.
  - Rev 2.0 (2026-10-27 04:01 KST) : [ETRI Audit Item 5 - SDA OISL Page 31, Sec. 2.6.3.5.1.2]
    Replaced the 32-bit CRC-32 polynomial LFSR (32'h04C11DB7) with the exact 25-bit
    Frame Scrambler PRBS generator polynomial (1 + D^3 + D^25, matching Section 
    2.6.3.6.4 and scrambler.v) initialized with dynamic seed (TXFN + 1).
  - Rev 2.4 (2026-10-29 12:52 KST) : [Audit Fix - Live Word-0 (TXFN + 1) Seed Evaluation]
    Evaluated Word 0 of each IDLE frame directly from the live seed_val.
  - Rev 2.5 (2026-10-29 15:19 KST) : [Audit Fix R16 - Exact Scrambler Tap (sr[0] ^ sr[3]) & Seed Binding]
    1. Restored the exact 25-bit Frame Scrambler recurrence tap 'fb = sr[0] ^ sr[3]'
       (matching scrambler.v 100%, so Seed 1 -> 0x80000040 and Seed 2 -> 0x40000020).
    2. Bound IDLE frame generation and FIFO storage to the active 'txfn_in': if 
       'txfn_in' updates before a prefetched IDLE frame in fifo_idle has started 
       draining to the MUX, fifo_idle flushes and regenerates immediately with the 
       new (TXFN + 1) seed, passing both tb_idle_MGMT.v and idle_seed_binding.sv.
===========================================================================
*/

module fso_idle_generator (
    input  wire        clk,
    input  wire        rst_n,

    // Current Transmit Frame Number from ARQ TX Controller
    input  wire [15:0] txfn_in,

    // AXI-Stream Output to fso_payload_mux.v (1912 Bytes)
    output wire [31:0] m_axis_tdata,
    output wire        m_axis_tvalid,
    output wire        m_axis_tlast,
    input  wire        m_axis_tready
);

    localparam MAX_WORDS = 9'd477; // 477 words * 4 bytes = 1908 Bytes
    
    localparam S_INIT = 1'b0,
               S_GEN  = 1'b1;

    reg        state, next_state;
    reg [8:0]  word_cnt;
    reg [24:0] lfsr_q;
    reg [15:0] latched_txfn;
    reg        out_frame_in_progress;

    reg  [31:0] prbs_tdata;
    reg         prbs_tvalid;
    reg         prbs_tlast;
    wire        crc_tready;

    // Dynamic 25-bit seed calculation: (TXFN + 1) per SDA OISL Sec. 2.6.3.5.1.2
    wire [24:0] raw_seed = {9'd0, txfn_in} + 25'd1;
    wire [24:0] seed_val = (raw_seed == 25'd0) ? 25'h0000007 : raw_seed;

    // [Rev 2.5 - Fix R16] Exact 32-step unrolled Frame Scrambler PRBS (1 + D^3 + D^25)
    // Identical recurrence (fb = sr[0] ^ sr[3]) and shift orientation to scrambler.v
    function [56:0] step_prbs25_32(input [24:0] q_in);
        reg [24:0] sr;
        reg [31:0] w_out;
        reg        fb;
        integer    k;
        begin
            sr = (q_in == 25'd0) ? 25'h0000007 : q_in;
            for (k = 0; k < 32; k = k + 1) begin
                w_out[31 - k] = sr[0];
                fb            = sr[0] ^ sr[3];
                sr            = {fb, sr[24:1]};
            end
            step_prbs25_32 = {sr, w_out};
        end
    endfunction

    wire [24:0] active_q_in = (word_cnt == 9'd0) ? seed_val : lfsr_q;
    wire [56:0] prbs_next   = step_prbs25_32(active_q_in);

    // Track whether downstream MUX has started consuming the current buffered IDLE frame
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            out_frame_in_progress <= 1'b0;
        end else if (m_axis_tvalid && m_axis_tready) begin
            if (m_axis_tlast)
                out_frame_in_progress <= 1'b0;
            else
                out_frame_in_progress <= 1'b1;
        end
    end

    // If txfn_in changes before downstream starts consuming a prefetched frame, flush & re-seed!
    wire seed_changed_while_idle = (txfn_in != latched_txfn) && !out_frame_in_progress;
    wire sub_rst_n               = rst_n && !seed_changed_while_idle;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state        <= S_INIT;
            word_cnt     <= 9'd0;
            lfsr_q       <= 25'h0000001;
            latched_txfn <= 16'd0;
        end else if (seed_changed_while_idle) begin
            state        <= S_INIT;
            word_cnt     <= 9'd0;
            lfsr_q       <= seed_val;
            latched_txfn <= txfn_in;
        end else begin
            state <= next_state;
            if (state == S_INIT) begin
                word_cnt     <= 9'd0;
                lfsr_q       <= seed_val;
                latched_txfn <= txfn_in;
            end else if (state == S_GEN && prbs_tvalid && crc_tready) begin
                word_cnt <= word_cnt + 9'd1;
                lfsr_q   <= prbs_next[56:32];
            end
        end
    end

    always @(*) begin
        next_state  = state;
        prbs_tvalid = 1'b0;
        prbs_tlast  = 1'b0;
        prbs_tdata  = 32'd0;

        case (state)
            S_INIT: begin
                // Only generate a new IDLE frame when FIFO is empty (!m_axis_tvalid)
                if (crc_tready && !m_axis_tvalid && !seed_changed_while_idle)
                    next_state = S_GEN;
            end
            S_GEN: begin
                prbs_tvalid = 1'b1;
                prbs_tdata  = prbs_next[31:0];
                if (word_cnt == (MAX_WORDS - 1)) begin
                    prbs_tlast = 1'b1;
                    if (crc_tready) next_state = S_INIT;
                end
            end
        endcase
    end

    // =======================================================
    // 2. FSO CRC-32 ENGINE (1908B -> 1912B)
    // =======================================================
    wire [31:0] crc_tdata;
    wire        crc_tvalid;
    wire        crc_tlast;
    wire        fifo_tready;

    fso_crc_32 u_fso_crc_32_idle (
        .clk             (clk),
        .rst_n           (sub_rst_n),
        .s_axis_tdata    (prbs_tdata),
        .s_axis_tvalid   (prbs_tvalid),
        .s_axis_tlast    (prbs_tlast),
        .s_axis_tready   (crc_tready),
        .m_axis_tdata    (crc_tdata),
        .m_axis_tvalid   (crc_tvalid),
        .m_axis_tlast    (crc_tlast),
        .m_axis_tready   (fifo_tready)
    );

    // =======================================================
    // 3. FIFO IDLE BUFFER (Ready for MUX)
    // =======================================================
    fso_axis_fifo #(.FIFO_DEPTH(1024), .ADDR_WIDTH(10)) fifo_idle (
        .clk             (clk),
        .rst_n           (sub_rst_n),
        .s_axis_tdata    (crc_tdata),
        .s_axis_tvalid   (crc_tvalid),
        .s_axis_tlast    (crc_tlast),
        .s_axis_tready   (fifo_tready),
        .m_axis_tdata    (m_axis_tdata),
        .m_axis_tvalid   (m_axis_tvalid),
        .m_axis_tlast    (m_axis_tlast),
        .m_axis_tready   (m_axis_tready)
    );

endmodule