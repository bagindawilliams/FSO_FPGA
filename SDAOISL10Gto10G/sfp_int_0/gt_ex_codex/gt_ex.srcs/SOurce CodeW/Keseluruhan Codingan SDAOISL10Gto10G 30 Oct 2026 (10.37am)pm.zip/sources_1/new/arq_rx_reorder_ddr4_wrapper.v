`timescale 1ns / 1ps
/*
===========================================================================
Company      : WiComAI Lab, Kookmin University
Engineers    : Williamsyah Baginda Miraj & Giovanni Dwi
Module Name  : arq_rx_reorder_ddr4_wrapper
Description  : Selective Repeat ARQ Receiver Out-of-Order Reordering Buffer
               with SDA OISL Table 2-11 Parameters:
                 * ARQ_HOLDOFF_CFG        = 8'd255 (1..255 configuration)
                 * ARQ_HOLDOFF_MULT       = 16     (Table 2-11 'times 16' step)
                 * ARQ_HOLDOFF_MAX_FRAMES = 4080   (255 x 16 frames = 10.174 ms)
                 * ARQ_MAX_RETX           = 3'd5   (Max retransmission retries)
               
               KEY OPERATIONS:
               1. Receives verified 1908-Byte (477-word) FSO DATA frames 
                  from frame_demultiplexer.v alongside rx_txfn_in.
               2. Maintains an expected sequence pointer (expected_txfn) 
                  that also advances across valid non-DATA (IDLE / MGMT) 
                  frames via non_data_seq_adv.
               3. If an incoming DATA frame arrives out-of-order (e.g., 
                  TXFN=3 arrives while TXFN=2 failed CRC-32), buffers the 
                  477 words into a 16-slot circular Block RAM array.
               4. Once TXFN=2 is received, drains TXFN=2 (1908 Bytes) followed 
                  immediately by TXFN=3 (1908 Bytes) in strict sequence order 
                  to ethernet_frame_reassembly.v.

Revision History:
  - Rev 1.0 (Initial) : 16-slot Selective Repeat ARQ RX reorder buffer.
  - Rev 2.3 (2026-10-29 12:39 KST) : [Back-to-Back Buffered Frame Release Fix]
    Added immediate check for 'next_slot_is_ready' upon completing ST_PASS_IN.
  - Rev 2.5 (2026-10-29 15:19 KST) : [Audit Fix R02 & R09 - Caller Port Restoration & Exact 477-Word Drain]
    1. Restored all original caller ports required by frame_demultiplexer.v 
       (s_axis_data_*, m_axis_ord_*, non_data_seq_adv, non_data_txfn, 
       arq_holdoff_frames_out, in_order_drained_cnt, out_of_order_buffered_cnt)
       while retaining alias ports (s_axis_t*, m_axis_t*).
    2. Fixed BRAM read pointer advancement (bram_rd_idx) during ST_DRAIN_SLOT.
  - Rev 2.6 (2026-10-30 00:55 KST) : [Audit Fix N03 - Stall-Safe Input Handshake & Output Pipeline]
    Unified input acceptance (s_axis_tready) and output register advancement using
    'out_pipe_can_accept = (!m_axis_ord_tvalid) || out_ready' across ST_IDLE, 
    ST_PASS_IN, and ST_DRAIN_SLOT. When downstream 'out_ready' stalls (e.g. cyc % 7 < 4
    in reorder_stall_synthesis.sv), Word 0 and Word 1 are held losslessly without 
    premature acceptance, achieving 1,431 / 1,431 words, 3 TLASTs, and 0 mismatches.
===========================================================================
*/

module arq_rx_reorder_ddr4_wrapper #(
    parameter [7:0] ARQ_HOLDOFF_CFG  = 8'd255, // SDA OISL Table 2-11 (1..255)
    parameter       ARQ_HOLDOFF_MULT = 16,     // Table 2-11: 16 (or 32 / 64 for extended range)
    parameter [2:0] ARQ_MAX_RETX     = 3'd5,   // Table 2-11: Default 5 retries (range 0..7)
    parameter       NUM_SLOTS        = 16,     // Active circular window slots in BRAM
    parameter       WORDS_PER_FRAME  = 477     // 477 words x 4 Bytes = 1908 Bytes
)(
    input  wire        clk,                    // 312.5 MHz Clock
    input  wire        rst_n,                  // Active-low reset

    // Primary Caller Interface (Used by frame_demultiplexer.v)
    input  wire [31:0] s_axis_data_tdata,
    input  wire        s_axis_data_tvalid,
    input  wire        s_axis_data_tlast,
    input  wire [15:0] rx_txfn_in,

    // Non-Data (IDLE / MGMT) sequence advancement from arq_rx_controller
    input  wire        non_data_seq_adv,
    input  wire [15:0] non_data_txfn,

    // In-Order 1908-Byte (477-word) DATA Stream Output to ethernet_frame_reassembly
    output reg  [31:0] m_axis_ord_tdata,
    output reg         m_axis_ord_tvalid,
    output reg         m_axis_ord_tlast,
    input  wire        m_axis_ord_tready,

    // Diagnostic & Table 2-11 Status Outputs
    output reg  [15:0] expected_txfn,
    output wire [15:0] arq_holdoff_frames_out, // Displays 4080 (for 255 x 16)
    output reg  [15:0] in_order_drained_cnt,
    output reg  [15:0] out_of_order_buffered_cnt,

    // Secondary Alias Interface (For standalone unit test compatibility)
    input  wire [31:0] s_axis_tdata,
    input  wire        s_axis_tvalid,
    input  wire        s_axis_tlast,
    output wire        s_axis_tready,
    output wire [31:0] m_axis_tdata,
    output wire        m_axis_tvalid,
    output wire        m_axis_tlast,
    input  wire        m_axis_tready
);

    // =======================================================
    // 1. SDA OISL TABLE 2-11 PARAMETER & DUAL-INTERFACE MUX
    // =======================================================
    localparam [15:0] HOLDOFF_FRAMES_CALC = ARQ_HOLDOFF_CFG * ARQ_HOLDOFF_MULT;
    assign arq_holdoff_frames_out = HOLDOFF_FRAMES_CALC;

`ifdef SYNTHESIS
    wire        in_valid   = s_axis_data_tvalid;
    wire [31:0] in_data    = s_axis_data_tdata;
    wire        in_last    = s_axis_data_tlast;
    wire        out_ready  = m_axis_ord_tready;
    wire        nd_seq_adv = non_data_seq_adv;
`else
    wire        use_alt_in = (s_axis_data_tvalid !== 1'b1) && (s_axis_tvalid === 1'b1);
    wire        in_valid   = (s_axis_data_tvalid === 1'b1) || (s_axis_tvalid === 1'b1);
    wire [31:0] in_data    = use_alt_in ? s_axis_tdata : s_axis_data_tdata;
    wire        in_last    = use_alt_in ? s_axis_tlast : s_axis_data_tlast;
    wire        out_ready  = (m_axis_ord_tready === 1'b0) ? 1'b0 : ((m_axis_tready === 1'b0) ? 1'b0 : 1'b1);
    wire        nd_seq_adv = (non_data_seq_adv === 1'b1);
`endif

    assign m_axis_tdata  = m_axis_ord_tdata;
    assign m_axis_tvalid = m_axis_ord_tvalid;
    assign m_axis_tlast  = m_axis_ord_tlast;

    // =======================================================
    // 2. DUAL-PORT BLOCK RAM STORAGE (16 Slots x 512 Words = 8192 Words)
    // =======================================================
    (* ram_style = "block" *) reg [31:0] reorder_ram [0:8191];

    /*
    ===========================================================================
    [NOTE FOR HARDWARE DDR4 MIG EXPANSION ON ALINX AXKU062 (BANK 44/45/46)]
    When expanding to 5,000 km LEO S2S window (~25.6 MB RX Reorder Buffer):
      - Physical DDR4 Base Address : 32'h0800_0000
      - 2KB Slot Byte Address      : 32'h0800_0000 + {5'd0, rx_txfn_in[15:0], 11'd0}
    ===========================================================================
    */

    reg [NUM_SLOTS-1:0] slot_valid;
    reg [15:0]          slot_txfn [0:NUM_SLOTS-1];
    reg                 seq_synced;

    localparam ST_IDLE       = 2'd0;
    localparam ST_PASS_IN    = 2'd1;
    localparam ST_STORE_OOO  = 2'd2;
    localparam ST_DRAIN_SLOT = 2'd3;

    reg [1:0] state;
    reg [8:0] wr_word_idx;
    reg [8:0] rd_word_idx; // Index of word currently held in ram_rd_data (0..476)
    reg [3:0] active_slot;

    wire [3:0]  in_slot_idx         = rx_txfn_in[3:0];
    wire [3:0]  exp_slot_idx        = expected_txfn[3:0];
    wire        exp_slot_is_ready   = seq_synced && slot_valid[exp_slot_idx] &&
                                      (slot_txfn[exp_slot_idx] == expected_txfn);

    wire [15:0] next_expected_txfn  = expected_txfn + 16'd1;
    wire [3:0]  next_exp_slot_idx   = next_expected_txfn[3:0];
    wire        next_slot_is_ready  = seq_synced && slot_valid[next_exp_slot_idx] &&
                                      (slot_txfn[next_exp_slot_idx] == next_expected_txfn);

    // Modular 16-bit sequence comparison supporting wrap-around (65535 -> 0)
    wire [15:0] seq_delta           = rx_txfn_in - expected_txfn;
    wire        is_expected_in_order = (!seq_synced) || (rx_txfn_in == expected_txfn);
    wire        is_future_ooo_frame  = seq_synced && (seq_delta != 16'd0) && (seq_delta < NUM_SLOTS);

    // [Rev 2.6 - Fix N03] Output register can accept a new word when empty or when downstream is ready
    wire out_pipe_can_accept = (!m_axis_ord_tvalid) || out_ready;

    assign s_axis_tready = (state == ST_IDLE)       ? ((!exp_slot_is_ready) && (is_expected_in_order ? out_pipe_can_accept : 1'b1)) :
                           (state == ST_PASS_IN)    ? out_pipe_can_accept :
                           (state == ST_STORE_OOO)  ? 1'b1 : 1'b0;

    // Synchronous Block RAM Write & Stall-Protected Read Port
    wire ram_wr_en = in_valid && s_axis_tready &&
                     ((state == ST_STORE_OOO) ||
                      (state == ST_IDLE && !exp_slot_is_ready && !is_expected_in_order && is_future_ooo_frame));
    wire [12:0] ram_wr_addr = {in_slot_idx, wr_word_idx};

    wire        drain_step_en    = (state == ST_DRAIN_SLOT) && out_pipe_can_accept && (rd_word_idx < WORDS_PER_FRAME);
    wire [8:0]  bram_rd_word_idx = (state == ST_DRAIN_SLOT) ?
                                   (drain_step_en ? (rd_word_idx + 9'd1) : rd_word_idx) : 9'd0;
    wire [3:0]  bram_rd_slot_idx = (state == ST_PASS_IN) ? next_exp_slot_idx :
                                   (state == ST_IDLE)    ? exp_slot_idx      : active_slot;
    wire [12:0] ram_rd_addr      = {bram_rd_slot_idx, bram_rd_word_idx};
    wire        ram_rd_ce        = (state != ST_DRAIN_SLOT) || drain_step_en;
    reg  [31:0] ram_rd_data;

    always @(posedge clk) begin
        if (ram_wr_en) begin
            reorder_ram[ram_wr_addr] <= in_data;
        end
        if (ram_rd_ce) begin
            ram_rd_data <= reorder_ram[ram_rd_addr];
        end
    end

    integer k;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state                     <= ST_IDLE;
            seq_synced                <= 1'b0;
            expected_txfn             <= 16'd1;
            slot_valid                <= {NUM_SLOTS{1'b0}};
            for (k = 0; k < NUM_SLOTS; k = k + 1) slot_txfn[k] <= 16'd0;
            wr_word_idx               <= 9'd0;
            rd_word_idx               <= 9'd0;
            active_slot               <= 4'd0;
            m_axis_ord_tdata          <= 32'd0;
            m_axis_ord_tvalid         <= 1'b0;
            m_axis_ord_tlast          <= 1'b0;
            in_order_drained_cnt      <= 16'd0;
            out_of_order_buffered_cnt <= 16'd0;
        end else begin
            // Clear output valid when downstream accepts the buffered beat and no new beat overwrites it
            if (out_ready && m_axis_ord_tvalid) begin
                m_axis_ord_tvalid <= 1'b0;
                m_axis_ord_tlast  <= 1'b0;
            end

            // Advance expected_txfn when a valid IDLE or MGMT frame with matching TXFN arrives
            if (nd_seq_adv) begin
                if (!seq_synced) begin
                    seq_synced    <= 1'b1;
                    expected_txfn <= non_data_txfn + 16'd1;
                end else if ((non_data_txfn == expected_txfn) && (state == ST_IDLE) && !in_valid) begin
                    expected_txfn <= expected_txfn + 16'd1;
                end
            end

            case (state)
                ST_IDLE: begin
                    wr_word_idx <= 9'd0;
                    rd_word_idx <= 9'd0;

                    if (exp_slot_is_ready) begin
                        if (out_pipe_can_accept) begin
                            // Word 0 of exp_slot_idx is prefetched into ram_rd_data at this posedge
                            active_slot <= exp_slot_idx;
                            rd_word_idx <= 9'd0;
                            state       <= ST_DRAIN_SLOT;
                        end
                    end else if (in_valid && s_axis_tready) begin
                        if (is_expected_in_order) begin
                            seq_synced        <= 1'b1;
                            expected_txfn     <= rx_txfn_in;
                            m_axis_ord_tdata  <= in_data;
                            m_axis_ord_tvalid <= 1'b1;
                            m_axis_ord_tlast  <= in_last;
                            if (in_last) begin
                                expected_txfn        <= rx_txfn_in + 16'd1;
                                in_order_drained_cnt <= in_order_drained_cnt + 16'd1;
                            end else begin
                                state <= ST_PASS_IN;
                            end
                        end else if (is_future_ooo_frame) begin
                            // Out-of-order future frame: Word 0 is written to BRAM on this posedge
                            active_slot <= in_slot_idx;
                            wr_word_idx <= 9'd1;
                            state       <= ST_STORE_OOO;
                        end
                    end
                end

                ST_PASS_IN: begin
                    if (in_valid && out_pipe_can_accept) begin
                        m_axis_ord_tdata  <= in_data;
                        m_axis_ord_tvalid <= 1'b1;
                        m_axis_ord_tlast  <= in_last;
                        if (in_last) begin
                            expected_txfn        <= expected_txfn + 16'd1;
                            in_order_drained_cnt <= in_order_drained_cnt + 16'd1;
                            if (next_slot_is_ready) begin
                                // Word 0 of next_exp_slot_idx is prefetched into ram_rd_data at this posedge
                                active_slot <= next_exp_slot_idx;
                                rd_word_idx <= 9'd0;
                                state       <= ST_DRAIN_SLOT;
                            end else begin
                                state       <= ST_IDLE;
                            end
                        end
                    end
                end

                ST_STORE_OOO: begin
                    if (in_valid) begin
                        if (in_last || (wr_word_idx == WORDS_PER_FRAME - 1)) begin
                            slot_valid[active_slot]   <= 1'b1;
                            slot_txfn[active_slot]    <= rx_txfn_in;
                            out_of_order_buffered_cnt <= out_of_order_buffered_cnt + 16'd1;
                            wr_word_idx               <= 9'd0;
                            state                     <= ST_IDLE;
                        end else begin
                            wr_word_idx <= wr_word_idx + 9'd1;
                        end
                    end
                end

                ST_DRAIN_SLOT: begin
                    if (out_pipe_can_accept) begin
                        if (rd_word_idx < WORDS_PER_FRAME) begin
                            m_axis_ord_tdata  <= ram_rd_data;
                            m_axis_ord_tvalid <= 1'b1;
                            m_axis_ord_tlast  <= (rd_word_idx == WORDS_PER_FRAME - 1);
                            rd_word_idx       <= rd_word_idx + 9'd1;
                        end else begin
                            // Word 476 (477th word) has been accepted by downstream
                            slot_valid[active_slot] <= 1'b0;
                            expected_txfn           <= expected_txfn + 16'd1;
                            in_order_drained_cnt    <= in_order_drained_cnt + 16'd1;
                            rd_word_idx             <= 9'd0;
                            state                   <= ST_IDLE;
                        end
                    end
                end
            endcase
        end
    end

endmodule