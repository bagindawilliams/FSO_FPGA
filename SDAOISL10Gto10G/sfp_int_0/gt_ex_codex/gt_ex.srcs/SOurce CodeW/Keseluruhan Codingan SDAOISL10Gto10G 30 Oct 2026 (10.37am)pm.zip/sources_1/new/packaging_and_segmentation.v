`timescale 1ns / 1ps
/*
===========================================================================
Company      : WiComAI Lab, Kookmin University
Engineers    : Williamsyah Baginda Miraj & Giovanni Dwi
Module Name  : packaging_and_segmentation
Description  : Ethernet Payload Segmentation and Zero-Padding Engine.
               Slices incoming Ethernet packets into fixed 1900-Byte 
               segments (475 words x 32-bit) and pads short packets with 
               zeros up to the 1900-Byte boundary.
               
               Revision Notes:
               - Separated 'fifo_ram' array write from the asynchronous reset 
                 block so Vivado infers Distributed LUTRAM cleanly.
               - Connected 'seg_valid_bytes' to 'valid_byte_cnt' to resolve 
                 unconnected output warnings.
               - [Rev 2.0 - 2026-10-27 04:34 KST - Target B6.1 Audit Fix]:
                 Added segment-level valid Ethernet byte tracking.
               - [Rev 2.1 - 2026-10-28 13:56 KST - Internal Audit Fix #5]:
                 Added exact s_axis_tlast packet-length descriptor tracking (pkt_len_fifo).
               - [Rev 2.2 - 2026-10-28 14:55 KST - Store-and-Segment Multi-Packet Fix]:
                 Eliminated dual-block writes to 'pkt_len_fifo' and added Store-and-Segment
                 completion gating (pkt_complete_in_fifo) for IPv4 and non-IPv4 packets.
               - [Rev 2.3 - 2026-10-29 12:39 KST - Inclusive Cycle Byte Count Alignment]:
                 Added combinational '+ 11'd4' on active S_PASS words so 'seg_valid_bytes'
                 reports 1900 B (instead of 1896 B) on the 475th word when m_axis_tlast == 1.
               - [Rev 2.5 - 2026-10-29 16:42 KST - Audit Fix R12 - Byte-Accurate Partial Tail & Super-Jumbo Hold]:
                 1. Added 's_axis_tkeep_bytes [2:0]' (1..4 valid bytes, defaulting to 4 
                    when unconnected) and stored it in 'fifo_ram[35:33]' so non-multiple-of-4 
                    packets (65B, 66B, 67B, 1518B, 1901B) accumulate exact byte counts.
                 2. Raised store-and-segment pre-buffer fallback threshold from 500 to 950 
                    words (3,800 Bytes).
               - [Rev 2.6 (2026-10-30 00:55 KST) - Audit Fix N07 - 14-Bit Super-Jumbo Length Handshake]:
                 1. Expanded 'fifo_ram' depth to 2048 words (8,192 Bytes) so packets up to 
                    4,096B..7,200B complete 'pkt_len_fifo' before Word 0 is popped.
                 2. During the S_HDR1 wait cycle (hdr_wait_cyc == 1, while m_axis_tready == 0)
                    of an initial segment with total length > 2,047 Bytes, transmits the upper 
                    3 bits of the 14-bit packet length ({8'hA5, head_pkt_total_bytes[13:11]}) 
                    over 'seg_valid_bytes[10:0]' to fso_payload.v, preserving 100% 11-bit port 
                    compatibility while supporting full 14-bit packet lengths (up to 16,383B).
===========================================================================
*/

module packaging_and_segmentation #(
    parameter MAX_WORDS = 475 // 475 words x 4 Bytes = 1900 Bytes
)(
    input  wire        clk,
    input  wire        rst_n,

    input  wire [31:0] s_axis_tdata,
    input  wire        s_axis_tvalid,
    input  wire        s_axis_tlast,
    output wire        s_axis_tready,
    input  wire [2:0]  s_axis_tkeep_bytes, // Optional 1..4 valid byte count (defaults to 4)

    output reg  [31:0] m_axis_tdata,
    output reg         m_axis_tvalid,
    output reg         m_axis_tlast,
    input  wire        m_axis_tready,
    output wire [10:0] seg_valid_bytes
);

    // Default to 4 valid bytes if s_axis_tkeep_bytes is left unconnected (1'bz / 1'bx / 0)
    wire [2:0] in_word_bytes = ((^s_axis_tkeep_bytes === 1'bx) || (s_axis_tkeep_bytes == 3'd0)) ?
                               3'd4 : s_axis_tkeep_bytes;

    // [Rev 2.6 - Fix N07] 2048-Word Elastic FIFO (8,192 Bytes) for Super-Jumbo frames
    (* ram_style = "distributed" *) reg [35:0] fifo_ram [0:2047];
    reg [10:0] wr_ptr;
    reg [10:0] rd_ptr;
    reg [11:0] fifo_count;

    // Single-Driver Packet Length Descriptor FIFO (Written ONLY on s_axis_tlast)
    (* ram_style = "distributed" *) reg [13:0] pkt_len_fifo [0:63];
    reg [5:0]  len_wr_ptr;
    reg [5:0]  len_rd_ptr;
    reg [13:0] wr_pkt_byte_acc;

    wire fifo_empty      = (fifo_count == 12'd0);
    wire fifo_full       = (fifo_count >= 12'd2000);
    assign s_axis_tready = !fifo_full;

    wire write_en             = s_axis_tvalid && s_axis_tready;
    wire read_en;
    wire pkt_complete_in_fifo = (len_wr_ptr != len_rd_ptr);

    // Purely Synchronous RAM Write (Strictly Single-Driver for both LUTRAMs)
    always @(posedge clk) begin
        if (write_en) begin
            fifo_ram[wr_ptr] <= {in_word_bytes, s_axis_tlast, s_axis_tdata};
            if (s_axis_tlast) begin
                pkt_len_fifo[len_wr_ptr] <= wr_pkt_byte_acc + {11'd0, in_word_bytes};
            end
        end
    end

    // Write Pointer, Packet Length Accumulator, and FIFO Occupancy Counter
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            wr_ptr          <= 11'd0;
            fifo_count      <= 12'd0;
            len_wr_ptr      <= 6'd0;
            wr_pkt_byte_acc <= 14'd0;
        end else begin
            if (write_en) begin
                wr_ptr <= wr_ptr + 11'd1;
                if (s_axis_tlast) begin
                    len_wr_ptr      <= len_wr_ptr + 6'd1;
                    wr_pkt_byte_acc <= 14'd0;
                end else begin
                    wr_pkt_byte_acc <= wr_pkt_byte_acc + {11'd0, in_word_bytes};
                end
            end
            if (write_en && !read_en)
                fifo_count <= fifo_count + 12'd1;
            else if (!write_en && read_en)
                fifo_count <= fifo_count - 12'd1;
        end
    end

    // Segmentation & Padding FSM
    localparam S_PASS = 1'b0;
    localparam S_PAD  = 1'b1;

    reg         state;
    reg  [8:0]  word_cnt;
    reg  [10:0] active_seg_bytes;
    reg         in_cont_seg;
    reg  [13:0] cont_rem_bytes_reg;
    reg  [1:0]  hdr_wait_cyc;
    wire [35:0] rd_data       = fifo_ram[rd_ptr];
    wire [2:0]  rd_word_bytes = (rd_data[35:33] == 3'd0) ? 3'd4 : rd_data[35:33];

    wire [13:0] head_pkt_total_bytes = in_cont_seg ? cont_rem_bytes_reg : pkt_len_fifo[len_rd_ptr];
    wire        seg_data_ready       = !fifo_empty && (in_cont_seg || pkt_complete_in_fifo || (fifo_count >= 12'd1800));

    assign read_en = (state == S_PASS) && seg_data_ready && m_axis_tready;

    // Accumulate exact rd_word_bytes (1..4) on each S_PASS word
    wire [10:0] cur_seg_valid_bytes = (state == S_PASS && m_axis_tvalid) ?
                                      ((word_cnt == 9'd0) ? {8'd0, rd_word_bytes} :
                                                            (active_seg_bytes + {8'd0, rd_word_bytes})) :
                                      active_seg_bytes;

    // [Rev 2.6 - Fix N07] On word_cnt == 0 while downstream fso_payload is in S_IDLE/S_HDR1
    // (m_axis_tready == 0):
    // - hdr_wait_cyc == 0 (S_IDLE): present lower 11 bits head_pkt_total_bytes[10:0]
    // - hdr_wait_cyc == 1 (S_HDR1): if > 2047B, present upper 3 bits {8'hA5, head_pkt_total_bytes[13:11]}
    // - When m_axis_tready == 1 (or hdr_wait_cyc == 2): present 1900B for > 2047B or exact length <= 2047B
    wire [10:0] start_meta_11b = (!m_axis_tready && (hdr_wait_cyc == 2'd0)) ? head_pkt_total_bytes[10:0] :
                                 (!m_axis_tready && (hdr_wait_cyc == 2'd1) && (head_pkt_total_bytes > 14'd2047)) ?
                                     {8'hA5, head_pkt_total_bytes[13:11]} :
                                 (head_pkt_total_bytes > 14'd2047) ? 11'd1900 : head_pkt_total_bytes[10:0];

    assign seg_valid_bytes = (state == S_PASS && word_cnt == 9'd0) ?
                             (seg_data_ready ? start_meta_11b : 11'd2000) :
                             cur_seg_valid_bytes;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state              <= S_PASS;
            word_cnt           <= 9'd0;
            rd_ptr             <= 11'd0;
            len_rd_ptr         <= 6'd0;
            active_seg_bytes   <= 11'd0;
            in_cont_seg        <= 1'b0;
            cont_rem_bytes_reg <= 14'd0;
            hdr_wait_cyc       <= 2'd0;
        end else begin
            if (state == S_PASS && word_cnt == 9'd0 && m_axis_tvalid && !m_axis_tready) begin
                if (hdr_wait_cyc < 2'd2)
                    hdr_wait_cyc <= hdr_wait_cyc + 2'd1;
            end else begin
                hdr_wait_cyc <= 2'd0;
            end

            if (m_axis_tvalid && m_axis_tready) begin
                if (state == S_PASS) begin
                    rd_ptr           <= rd_ptr + 11'd1;
                    active_seg_bytes <= cur_seg_valid_bytes;

                    if (rd_data[32]) begin
                        // End of Ethernet packet (s_axis_tlast == 1): pop descriptor FIFO
                        len_rd_ptr         <= len_rd_ptr + 6'd1;
                        in_cont_seg        <= 1'b0;
                        cont_rem_bytes_reg <= 14'd0;
                        if (word_cnt == MAX_WORDS - 1) begin
                            word_cnt <= 9'd0;
                        end else begin
                            word_cnt <= word_cnt + 9'd1;
                            state    <= S_PAD;
                        end
                    end else if (word_cnt == MAX_WORDS - 1) begin
                        // Reached 1900-Byte boundary without tlast -> Packet continues in next segment!
                        word_cnt           <= 9'd0;
                        in_cont_seg        <= 1'b1;
                        cont_rem_bytes_reg <= head_pkt_total_bytes - 14'd1900;
                    end else begin
                        word_cnt <= word_cnt + 9'd1;
                    end
                end else if (state == S_PAD) begin
                    if (word_cnt == MAX_WORDS - 1) begin
                        word_cnt <= 9'd0;
                        state    <= S_PASS;
                    end else begin
                        word_cnt <= word_cnt + 9'd1;
                    end
                end
            end
        end
    end

    always @(*) begin
        if (state == S_PASS) begin
            m_axis_tvalid = seg_data_ready;
            m_axis_tdata  = m_axis_tvalid ? rd_data[31:0] : 32'd0;
            m_axis_tlast  = m_axis_tvalid && (word_cnt == MAX_WORDS - 1);
        end else begin
            m_axis_tvalid = 1'b1;
            m_axis_tdata  = 32'd0;
            m_axis_tlast  = (word_cnt == MAX_WORDS - 1);
        end
    end

endmodule