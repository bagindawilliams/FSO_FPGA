`timescale 1ns / 1ps
/*
===========================================================================
Company      : WiComAI Lab, Kookmin University
Engineers    : Williamsyah Baginda Miraj & Giovanni Dwi
Description  : SDA Encoder Grand Top Module.

Revision History:
  - Rev 1.0 (Initial) : SDA Encoder top-level integration.
  - Rev 2.2 (2026-10-28 14:55 KST) : Added 'seg_valid_bytes [10:0]' input port 
    and forwarded it to u_eth_fso_framer for dynamic packet length encapsulation.
  - Rev 2.5 (2026-10-29 16:42 KST) : [Audit Fix R19 - ARQ Feedback CDC Synchronizer]
    Added 2-stage (* ASYNC_REG = "TRUE" *) synchronizer registers (arq_rxfn_sync1/2,
    arq_ack_sync1/2, arq_valid_sync1/2) in the clk_gth domain to safely transfer the
    closed-loop ARQ feedback transaction from the receiver clock domain.
  - Rev 2.7 (2026-10-30 01:55 KST) : [Audit Fix N05 & N06 - Coherent Edge-Qualified CDC & Peer ACK Routing]
    1. [Fix N06]: Upgraded ARQ feedback CDC from independent bit sampling to a 
       3-stage edge-qualified coherent capture: when the synchronized valid signal 
       rises (arq_valid_sync2 && !arq_valid_sync3), the settled 16-bit frame number 
       and ACK bit are atomically latched into 'arq_rxfn_coherent' and 'arq_ack_coherent'
       alongside a 1-cycle 'arq_valid_pulse'.
    2. [Fix N05]: Added optional 'peer_rxfn_in', 'peer_ack_in', and 'peer_ack_valid_in'
       ports with matching coherent CDC synchronization to support independent local 
       and remote peer ARQ feedback paths in u_eth_fso_framer.
  - Rev 2.8 (2026-10-30 11:45 KST) : [Audit Fix A09 & A18 - Toggle-Handshake CDC Event Capture & 14-Bit Metadata]
    1. [Fix A09]: Upgraded the ARQ feedback CDC interface to an Event-Driven Toggle 
       Synchronizer with Source Holding Latches ('src_arq_toggle', 'src_arq_rxfn_hold', 
       'src_arq_ack_hold' triggered on posedge rx_ack_valid_in).
    2. [Fix A18]: Widened 'seg_valid_bytes' port to 14 bits ([13:0]) to match 
       eth_rx_front_end_top.v and ethernet_fso_framer.v with zero width warnings.
  - Rev 2.9 (2026-10-30 18:25 KST) : [Audit Fix B14 - 4-Entry Event FIFO Ring Buffer CDC]
    Upgraded the ARQ feedback CDC from a 1-bit toggle to a 4-Entry Event Ring Buffer 
    ('src_arq_rxfn_q[0:3]', 'src_arq_ack_q[0:3]', and 3-bit write pointer 'src_arq_wr_ptr')
    synchronized across 2 (* ASYNC_REG = "TRUE" *) stages into 'clk_gth' and drained 
    sequentially by 'dst_arq_rd_ptr'. This guarantees that:
      (a) Single sub-cycle pulses (3.103 ns in cdc_3103ps_reset.sv) are captured 1/1,
      (b) Back-to-back pulses between destination clock edges (cdc_reset_double_cancel.sv)
          increment the write pointer by +2 without self-cancellation (EVENTS_CAPTURED 2), and
      (c) Closely spaced events with distinct payloads (1111 then 2222 in 
          cdc_reset_payload_pair.sv) are queued into separate slots (0 and 1) and 
          delivered in exact order without overwriting (1111 then 2222).
  - Rev 3.0 (2026-10-30 23:10 KST) : [Audit Fix B14 - 16-Entry Gray-Coded Async FIFO with Full Protection]
    1. Expanded the ARQ and Peer feedback CDC queues from 4 entries to 16 entries 
       ('src_arq_rxfn_q[0:15]', 'src_arq_ack_q[0:15]') with 5-bit Gray-coded write/read
       pointers ('src_arq_wr_gray', 'dst_arq_rd_gray') synchronized across domains.
    2. Added full-queue protection ('!src_arq_full') and overflow counters 
       ('arq_cdc_overflow_cnt', 'peer_cdc_overflow_cnt') so burst stress tests of 5 or 8
       back-to-back events (cdc_queue_burst5.sv and cdc_queue_burst8.sv) are captured 
       100% in order (1..5 and 1..8) without overwriting slot 0 or wrapping to empty.
===========================================================================
*/

module sda_encoder #(
    parameter SIM_MODE            = 1,
    parameter LOOPBACK_ARQ_DIRECT = 1
)(
    input  wire        clk_logic, // 200.0 MHz
    input  wire        clk_gth,   // 312.5 MHz Continuous Clock
    input  wire        rst_n,

    input  wire [31:0] s_axis_eth_tdata,
    input  wire        s_axis_eth_tvalid,
    input  wire        s_axis_eth_tlast,
    output wire        s_axis_eth_tready,
    input  wire [13:0] seg_valid_bytes,  // [Rev 2.8 - Fix A18] Full 14-bit length metadata

    input  wire        mgmt_trigger_1hz,
    input  wire [5:0]  rx_phy_ts_sec,
    input  wire [39:0] rx_phy_ts_picosec,
    input  wire [5:0]  tx_phy_ts_sec,
    input  wire [39:0] tx_phy_ts_picosec,
    input  wire [63:0] range_meters,
    input  wire [31:0] range_ts_sec,
    input  wire [39:0] range_ts_picosec,
    input  wire        ts_valid,
    input  wire [5:0]  tod_seconds_in, 
    input  wire [3:0]  fcch_opcode,    
    input  wire [15:0] fcch_pl,        

    // Local RX CRC Feedback (or shared loopback feedback)
    input  wire [15:0] rx_rxfn_in,      
    input  wire        rx_ack_in,       
    input  wire        rx_ack_valid_in,

    // Optional Remote Peer Header ACK Feedback
    input  wire [15:0] peer_rxfn_in,
    input  wire        peer_ack_in,
    input  wire        peer_ack_valid_in,

    output wire [31:0] tx_fso_data_out,
    output wire        tx_fso_valid_out,
    output wire        eth_data_error_flag
);

    // =======================================================
    // [Rev 3.0 - Fix B14] 16-ENTRY GRAY-CODED ASYNC EVENT FIFO WITH FULL GUARD
    // =======================================================
    function [4:0] bin2gray5(input [4:0] b);
        begin
            bin2gray5 = (b >> 1) ^ b;
        end
    endfunction

    function [4:0] gray2bin5(input [4:0] g);
        reg [4:0] b;
        begin
            b[4] = g[4];
            b[3] = b[4] ^ g[3];
            b[2] = b[3] ^ g[2];
            b[1] = b[2] ^ g[1];
            b[0] = b[1] ^ g[0];
            gray2bin5 = b;
        end
    endfunction

    wire        arq_valid_clean  = (rx_ack_valid_in === 1'b1);
    wire [15:0] arq_rxfn_clean   = (^rx_rxfn_in === 1'bx) ? 16'd0 : rx_rxfn_in;
    wire        arq_ack_clean    = (rx_ack_in === 1'b1);

    wire        peer_valid_clean = (peer_ack_valid_in === 1'b1);
    wire [15:0] peer_rxfn_clean  = (^peer_rxfn_in === 1'bx) ? 16'd0 : peer_rxfn_in;
    wire        peer_ack_clean   = (peer_ack_in === 1'b1);

    // 1. Source 16-Slot Event FIFO for Local RX CRC Feedback
    reg [4:0]  src_arq_wr_bin;
    reg [4:0]  src_arq_wr_gray;
    reg [15:0] src_arq_rxfn_q [0:15];
    reg        src_arq_ack_q  [0:15];
    reg [15:0] arq_cdc_overflow_cnt;
    reg [4:0]  dst_arq_rd_bin;
    integer    q_i;

    wire       src_arq_full     = ((src_arq_wr_bin - dst_arq_rd_bin) >= 5'd16);
    wire [4:0] src_arq_next_bin = src_arq_wr_bin + 5'd1;

    always @(posedge arq_valid_clean or negedge rst_n) begin
        if (!rst_n) begin
            src_arq_wr_bin       <= 5'd0;
            src_arq_wr_gray      <= 5'd0;
            arq_cdc_overflow_cnt <= 16'd0;
            for (q_i = 0; q_i < 16; q_i = q_i + 1) begin
                src_arq_rxfn_q[q_i] <= 16'd0;
                src_arq_ack_q[q_i]  <= 1'b0;
            end
        end else if (!src_arq_full) begin
            src_arq_rxfn_q[src_arq_wr_bin[3:0]] <= arq_rxfn_clean;
            src_arq_ack_q[src_arq_wr_bin[3:0]]  <= arq_ack_clean;
            src_arq_wr_bin                      <= src_arq_next_bin;
            src_arq_wr_gray                     <= bin2gray5(src_arq_next_bin);
        end else begin
            arq_cdc_overflow_cnt <= arq_cdc_overflow_cnt + 16'd1;
        end
    end

    // 2. Source 16-Slot Event FIFO for Remote Peer Header ACK
    reg [4:0]  src_peer_wr_bin;
    reg [4:0]  src_peer_wr_gray;
    reg [15:0] src_peer_rxfn_q [0:15];
    reg        src_peer_ack_q  [0:15];
    reg [15:0] peer_cdc_overflow_cnt;
    reg [4:0]  dst_peer_rd_bin;
    integer    p_i;

    wire       src_peer_full     = ((src_peer_wr_bin - dst_peer_rd_bin) >= 5'd16);
    wire [4:0] src_peer_next_bin = src_peer_wr_bin + 5'd1;

    always @(posedge peer_valid_clean or negedge rst_n) begin
        if (!rst_n) begin
            src_peer_wr_bin       <= 5'd0;
            src_peer_wr_gray      <= 5'd0;
            peer_cdc_overflow_cnt <= 16'd0;
            for (p_i = 0; p_i < 16; p_i = p_i + 1) begin
                src_peer_rxfn_q[p_i] <= 16'd0;
                src_peer_ack_q[p_i]  <= 1'b0;
            end
        end else if (!src_peer_full) begin
            src_peer_rxfn_q[src_peer_wr_bin[3:0]] <= peer_rxfn_clean;
            src_peer_ack_q[src_peer_wr_bin[3:0]]  <= peer_ack_clean;
            src_peer_wr_bin                       <= src_peer_next_bin;
            src_peer_wr_gray                      <= bin2gray5(src_peer_next_bin);
        end else begin
            peer_cdc_overflow_cnt <= peer_cdc_overflow_cnt + 16'd1;
        end
    end

    // 3. 2-Stage Gray-Pointer Destination Synchronizers & In-Order Drain in clk_gth
    (* ASYNC_REG = "TRUE" *) reg [4:0] arq_wr_gray_s1,  arq_wr_gray_s2;
    (* ASYNC_REG = "TRUE" *) reg [4:0] peer_wr_gray_s1, peer_wr_gray_s2;

    reg [15:0] arq_rxfn_coherent;
    reg        arq_ack_coherent;
    reg        arq_valid_pulse;

    reg [15:0] peer_rxfn_coherent;
    reg        peer_ack_coherent;
    reg        peer_valid_pulse;

    wire [4:0] dst_arq_wr_bin_sync  = gray2bin5(arq_wr_gray_s2);
    wire [4:0] dst_peer_wr_bin_sync = gray2bin5(peer_wr_gray_s2);

    always @(posedge clk_gth or negedge rst_n) begin
        if (!rst_n) begin
            arq_wr_gray_s1     <= 5'd0;
            arq_wr_gray_s2     <= 5'd0;
            dst_arq_rd_bin     <= 5'd0;
            arq_rxfn_coherent  <= 16'd0;
            arq_ack_coherent   <= 1'b0;
            arq_valid_pulse    <= 1'b0;

            peer_wr_gray_s1    <= 5'd0;
            peer_wr_gray_s2    <= 5'd0;
            dst_peer_rd_bin    <= 5'd0;
            peer_rxfn_coherent <= 16'd0;
            peer_ack_coherent  <= 1'b0;
            peer_valid_pulse   <= 1'b0;
        end else begin
            // Synchronize Gray write pointers into clk_gth domain
            arq_wr_gray_s1  <= src_arq_wr_gray;
            arq_wr_gray_s2  <= arq_wr_gray_s1;
            peer_wr_gray_s1 <= src_peer_wr_gray;
            peer_wr_gray_s2 <= peer_wr_gray_s1;

            if (dst_arq_rd_bin != dst_arq_wr_bin_sync) begin
                arq_rxfn_coherent <= src_arq_rxfn_q[dst_arq_rd_bin[3:0]];
                arq_ack_coherent  <= src_arq_ack_q[dst_arq_rd_bin[3:0]];
                arq_valid_pulse   <= 1'b1;
                dst_arq_rd_bin    <= dst_arq_rd_bin + 5'd1;
            end else begin
                arq_valid_pulse   <= 1'b0;
            end

            if (dst_peer_rd_bin != dst_peer_wr_bin_sync) begin
                peer_rxfn_coherent <= src_peer_rxfn_q[dst_peer_rd_bin[3:0]];
                peer_ack_coherent  <= src_peer_ack_q[dst_peer_rd_bin[3:0]];
                peer_valid_pulse   <= 1'b1;
                dst_peer_rd_bin    <= dst_peer_rd_bin + 5'd1;
            end else begin
                peer_valid_pulse   <= 1'b0;
            end
        end
    end

    wire [7:0]   framer_hdr_tdata; 
    wire         framer_hdr_tvalid;
    wire         framer_hdr_tlast;
    wire         framer_hdr_tready;

    wire [31:0]  framer_fso_tdata;
    wire         framer_fso_tvalid;
    wire         framer_fso_tlast;
    wire         framer_fso_tready;

    wire         cdc1_ready_flag;
    assign framer_hdr_tready = cdc1_ready_flag;
    assign framer_fso_tready = cdc1_ready_flag;

    wire         cdc1_hdr_dv;
    wire [7:0]   cdc1_hdr_data;
    wire         cdc1_load_dv;
    wire [63:0]  cdc1_load_data;

    wire         fec_valid;
    wire [95:0]  fec_data;

    wire [71:0]  preamble_data;

    wire         gb_valid;
    wire [127:0] gb_data;
    wire [15:0]  gb_keep;

    wire         cdc2_valid;
    wire [31:0]  cdc2_data;

    ethernet_fso_framer #(
        .LOOPBACK_ARQ_DIRECT (LOOPBACK_ARQ_DIRECT)
    ) u_eth_fso_framer (
        .clk                 (clk_gth),
        .rst_n               (rst_n),
        .s_axis_eth_tdata    (s_axis_eth_tdata),
        .s_axis_eth_tvalid   (s_axis_eth_tvalid),
        .s_axis_eth_tlast    (s_axis_eth_tlast),
        .s_axis_eth_tready   (s_axis_eth_tready),
        .seg_valid_bytes     (seg_valid_bytes),
        .mgmt_trigger_1hz    (mgmt_trigger_1hz),
        .rx_phy_ts_sec       (rx_phy_ts_sec),
        .rx_phy_ts_picosec   (rx_phy_ts_picosec),
        .tx_phy_ts_sec       (tx_phy_ts_sec),
        .tx_phy_ts_picosec   (tx_phy_ts_picosec),
        .range_meters        (range_meters),
        .range_ts_sec        (range_ts_sec),
        .range_ts_picosec    (range_ts_picosec),
        .ts_valid            (ts_valid),
        .tod_seconds_in      (tod_seconds_in),
        .fcch_opcode         (fcch_opcode),
        .fcch_pl             (fcch_pl),
        .rx_rxfn_in          (arq_rxfn_coherent),
        .rx_ack_in           (arq_ack_coherent),
        .rx_ack_valid_in     (arq_valid_pulse),
        .peer_rxfn_in        (peer_rxfn_coherent),
        .peer_ack_in         (peer_ack_coherent),
        .peer_ack_valid_in   (peer_valid_pulse),
        .m_axis_hdr_tdata    (framer_hdr_tdata),
        .m_axis_hdr_tvalid   (framer_hdr_tvalid),
        .m_axis_hdr_tlast    (framer_hdr_tlast),
        .m_axis_hdr_tready   (framer_hdr_tready),
        .m_axis_fso_tdata    (framer_fso_tdata),
        .m_axis_fso_tvalid   (framer_fso_tvalid),
        .m_axis_fso_tlast    (framer_fso_tlast),
        .m_axis_fso_tready   (framer_fso_tready),
        .eth_data_error_flag (eth_data_error_flag)
    );

    x_gth_logic u_cdc_tx_1 (
        .clk_gth             (clk_gth),
        .clk_logic           (clk_logic),
        .rst_n               (rst_n),
        .en_head             (framer_hdr_tvalid),
        .en_load             (framer_fso_tvalid),
        .header_in           (framer_hdr_tdata), 
        .payload_in          (framer_fso_tdata),
        .cdc_ready           (cdc1_ready_flag),
        .header_dv           (cdc1_hdr_dv),
        .header              (cdc1_hdr_data),
        .payload_dv          (cdc1_load_dv),
        .payload             (cdc1_load_data)
    );

    core_tx u_encoder_fec (
        .clk                 (clk_logic),
        .rst_n               (rst_n),
        .en_head             (cdc1_hdr_dv),
        .en_load             (cdc1_load_dv),
        .header              (cdc1_hdr_data),
        .payload             (cdc1_load_data),
        .flag                (fec_valid),
        .data_out            (fec_data)
    );

    preamble_gen u_preamble_gen (
        .preamble_out        (preamble_data)
    );

    mux_gearbox_128 u_mux_gearbox (
        .clk                 (clk_logic),
        .rst_n               (rst_n),
        .preamble_data       (preamble_data),
        .lpc_data            (fec_data),
        .lpc_valid           (fec_valid),
        .cdc_data            (gb_data),
        .cdc_valid           (gb_valid),
        .cdc_keep            (gb_keep)
    );

    x_logic_gth u_cdc_tx_2 (
        .clk_gth             (clk_gth),
        .clk_logic           (clk_logic),
        .rst_n               (rst_n),
        .en                  (1'b1),
        .data_in             (gb_data),
        .data_in_dv          (gb_valid),
        .cdc_keep            (gb_keep),
        .flag                (cdc2_valid),
        .data_out            (cdc2_data)
    );

    error_inject #(
        .SIM_MODE            (SIM_MODE)
    ) u_error_injector (
        .clk                 (clk_gth),
        .rst_n               (rst_n),
        .en                  (cdc2_valid),
        .data_in             (cdc2_data),
        .flag                (tx_fso_valid_out),
        .data_out            (tx_fso_data_out)
    );

endmodule