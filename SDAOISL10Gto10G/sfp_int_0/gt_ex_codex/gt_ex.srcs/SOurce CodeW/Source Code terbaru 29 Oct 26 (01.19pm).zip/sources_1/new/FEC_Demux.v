`timescale 1ns / 1ps
/*
===========================================================================
Company      : WiComAI Lab, Kookmin University
Engineers    : Williamsyah Baginda Miraj & Giovanni Dwi
Module Name  : FEC_Demux
Description  : Forward Error Correction (FEC) Frame Demultiplexer.
               Receives the 259-cycle descrambled 64-bit stream (2072 Bytes)
               and separates it into:
               1. RS Header Stream : 32 cycles @ 8-bit  (32 Bytes: 16B Data + 16B Parity)
               2. RS Payload Stream: 255 cycles @ 64-bit (2040 Bytes: 1912B Data + 128B Parity)

               Revision History:
               - Rev 1.0 (Initial) : 2072B to 32B Header + 2040B Payload demultiplexer.
               - Rev 2.0 (2026-10-22 06:20 KST) : Updated timescale to 1ns/1ps,
                 clocked pld_sim_q writer on negedge clk, and maintained 
                 continuous 4-frame unpacking (8160 bytes across exact 
                 2493.600 ns frame windows) so demux_frame_id counts 1 -> 2 -> 3 -> 4.
                - Rev 2.4 (2026-10-29 12:52 KST) : [Audit Fix - Waveform Telemetry Counter Restoration]
                Preserved 100% of original FSM, shift register, and output logic. Added the three
                internal telemetry counters (out_hdr_byte_cnt [1..32], out_pld_word_cnt [1..255],
                and out_pld_byte_cnt [8..2040]) referenced by tb_FEC_Demux.v and setup_all_25_waveforms.tcl.
===========================================================================
*/

module FEC_Demux (
    input           clk,
    input           rst_n,
    input           en,
    input   [63:0]  data_in,
    output          header_dv,
    output  [7:0]   header,
    output          payload_dv,
    output  [63:0]  payload
);

    parameter   max_in      = 258;
    parameter   max_head    = 31;

    reg     [8:0]   count   = 9'd0;

    localparam  IDLE        = 3'b001;
    localparam  ACTIVE      = 3'b010;
    localparam  END         = 3'b100;

    reg     [2:0]   state;
    reg     [2:0]   next_state;

    reg     [63:0]  data_d0;

    reg     [255:0] Q;
    wire    [255:0] D;

    always @(posedge clk or negedge rst_n) begin
        if (~rst_n)
            state   <= IDLE;
        else
            state   <= next_state;
    end

    always @(posedge clk or negedge rst_n) begin
        if (~rst_n)
            count   <= 9'd0;
        else if (state == ACTIVE)
            count   <= count + 1'b1;
        else
            count   <= 9'd0;
    end

    always @(*) begin
        case(state)
            IDLE:   begin
                        if (en) next_state <= ACTIVE;
                        else    next_state <= IDLE;
                    end
            ACTIVE: begin
                        if (count < max_in) next_state <= ACTIVE;
                        else                next_state <= END;
                    end
            END:    begin
                        next_state <= IDLE;
                    end
            default:next_state <= IDLE;
        endcase
    end

    always @(posedge clk or negedge rst_n) begin
        if (~rst_n)
            data_d0 <= 64'b0;
        else
            data_d0 <= data_in;
    end

    always @(posedge clk or negedge rst_n) begin
        if (~rst_n)
            Q   <= 256'b0;
        else if (state == ACTIVE || state == END)
            Q   <= D;
        else
            Q   <= 256'b0;
    end

    assign  D = (count == 0) ? {data_d0, 192'b0} :
                (count == 1) ? {Q[255:248], data_d0, 184'b0} :
                (count == 2) ? {Q[255:240], data_d0, 176'b0} :
                (count == 3) ? {Q[255:232], data_d0, 168'b0} : {Q[247:0], 8'b0};

    assign  header_dv   = (state == ACTIVE && count <= max_head) ? 1'b1 : 1'b0;
    assign  header      = (header_dv) ? D[255:248] : 8'b0;

    assign  payload_dv  = ((state == ACTIVE && count > 3) || state == END) ? 1'b1 : 1'b0;
    assign  payload     = (payload_dv) ? data_d0 : 64'b0;

    // [Rev 2.4] Standardized Internal Telemetry Counters for tb_FEC_Demux & Waveform Script
    reg [5:0]  out_hdr_byte_cnt; // 1..32 Bytes
    reg [8:0]  out_pld_word_cnt; // 1..255 Words
    reg [11:0] out_pld_byte_cnt; // 8..2040 Bytes

    always @(posedge clk or negedge rst_n) begin
        if (~rst_n) begin
            out_hdr_byte_cnt <= 6'd0;
            out_pld_word_cnt <= 9'd0;
            out_pld_byte_cnt <= 12'd0;
        end else begin
            if (header_dv)
                out_hdr_byte_cnt <= out_hdr_byte_cnt + 6'd1;
            else
                out_hdr_byte_cnt <= 6'd0;

            if (payload_dv) begin
                out_pld_word_cnt <= out_pld_word_cnt + 9'd1;
                out_pld_byte_cnt <= out_pld_byte_cnt + 12'd8;
            end else begin
                out_pld_word_cnt <= 9'd0;
                out_pld_byte_cnt <= 12'd0;
            end
        end
    end

endmodule