`timescale 1ns / 100ps
/*
===========================================================================
Company      : WiComAI Lab, Kookmin University
Engineers    : Williamsyah Baginda Miraj & Giovanni Dwi
Module Name  : arq_rx_reorder_ddr4_wrapper
Description  : Selective Repeat ARQ Receiver Reorder Buffer (Data Plane).
               
               SDA OISL TABLE 2-11 & SDA OCT COMPLIANCE:
               - Implements the Selective Repeat ARQ receiver sliding window
                 and in-order delivery buffer (inspired by SDA OCT) while 
                 strictly adhering to SDA OISL Table 2-11 parameters:
                 * ARQ_HOLDOFF_CFG        = 8'd255 (8-bit register: 1..255)
                 * ARQ_HOLDOFF_MULT       = 16     (Table 2-11 'times 16' step,
                                                    configurable to 32 or 64)
                 * ARQ_HOLDOFF_MAX_FRAMES = 4080   (255 x 16 frames = 10.174 ms)
                 * ARQ_MAX_RETX           = 3'd5   (Max retransmission retries)
               
               KEY HARDWARE OPERATIONS:
               1. Stores incoming verified 1908-Byte (477-word) DATA frames 
                  into a circular Block RAM indexed by rx_txfn_in[3:0].
               2. Maintains the receiver sequence counter 'expected_txfn'.
               3. If an out-of-order frame arrives (e.g., TXFN=3 arrives while 
                  TXFN=2 failed CRC-32 and is awaiting retransmission), buffers 
                  TXFN=3 in slot 3 and holds egress until TXFN=2 arrives.
               4. Once TXFN=2 is received, drains TXFN=2 (1908 Bytes) followed 
                  immediately by TXFN=3 (1908 Bytes) in strict sequence order 
                  to ethernet_frame_reassembly.v.
Revision History:
  - Rev 1.0 (Initial) : 16-slot Selective Repeat ARQ RX reorder buffer.
  - Rev 2.3 (2026-10-29 12:39 KST) : [Back-to-Back Buffered Frame Release Fix]
    Preserved 100% of original module structure, ports, and parameters 
    (NUM_SLOTS = 16, WORDS_PER_FRAME = 477). Added immediate check for 
    'next_slot_is_ready' upon completing ST_PASS_IN so buffered out-of-order 
    frames (e.g., TXFN=3 after retransmitted TXFN=2) drain immediately 
    without waiting for an extra idle event.
===========================================================================
*/

module arq_rx_reorder_ddr4_wrapper #(
    parameter NUM_SLOTS       = 16,
    parameter WORDS_PER_FRAME = 477 // 477 words x 4 Bytes = 1908 Bytes
)(
    input  wire        clk,
    input  wire        rst_n,

    // Sequence Number of Current Frame from Header Parser
    input  wire [15:0] rx_txfn_in,

    // Verified 1908-Byte DATA Stream from frame_demultiplexer
    input  wire [31:0] s_axis_tdata,
    input  wire        s_axis_tvalid,
    input  wire        s_axis_tlast,
    output wire        s_axis_tready,

    // In-Order 1908-Byte DATA Stream to ethernet_frame_reassembly
    output reg  [31:0] m_axis_tdata,
    output reg         m_axis_tvalid,
    output reg         m_axis_tlast,
    input  wire        m_axis_tready,

    // Diagnostic Telemetry Output
    output reg  [15:0] expected_txfn
);

    // 16 Slots x 512 Words x 32-bit = 8192 Words (32 KB Block RAM)
    (* ram_style = "block" *) reg [31:0] reorder_ram [0:8191];

    /*
    ===========================================================================
    [NOTE FOR HARDWARE DDR4 MIG EXPANSION ON ALINX AXKU062 (BANK 44/45/46)]
    When expanding to 5,000 km LEO S2S window (~25.6 MB RX Reorder Buffer):
      - Physical DDR4 Base Address : 32'h0800_0000
      - 2KB Slot Byte Address      : 32'h0800_0000 + {5'd0, rx_txfn_in[15:0], 11'd0}
    ===========================================================================
    */

    reg [NUM_SLOTS-1:0] slot_valid;
    reg [15:0]          slot_txfn [0:NUM_SLOTS-1];
    reg                 seq_synced;

    localparam ST_IDLE       = 2'd0;
    localparam ST_PASS_IN    = 2'd1;
    localparam ST_STORE_OOO  = 2'd2;
    localparam ST_DRAIN_SLOT = 2'd3;

    reg [1:0] state;
    reg [8:0] wr_word_idx;
    reg [8:0] rd_word_idx;
    reg [3:0] active_slot;

    wire [3:0]  in_slot_idx         = rx_txfn_in[3:0];
    wire [3:0]  exp_slot_idx        = expected_txfn[3:0];
    wire        exp_slot_is_ready   = seq_synced && slot_valid[exp_slot_idx] &&
                                      (slot_txfn[exp_slot_idx] == expected_txfn);

    wire [15:0] next_expected_txfn  = expected_txfn + 16'd1;
    wire [3:0]  next_exp_slot_idx   = next_expected_txfn[3:0];
    wire        next_slot_is_ready  = seq_synced && slot_valid[next_exp_slot_idx] &&
                                      (slot_txfn[next_exp_slot_idx] == next_expected_txfn);

    wire is_expected_in_order = (!seq_synced) || (rx_txfn_in == expected_txfn);
    wire is_future_ooo_frame  = seq_synced && (rx_txfn_in > expected_txfn) &&
                                ((rx_txfn_in - expected_txfn) < NUM_SLOTS);

    assign s_axis_tready = (state == ST_PASS_IN) ? m_axis_tready : (state != ST_DRAIN_SLOT);

    // Synchronous Block RAM Write & Read Port
    wire ram_wr_en = s_axis_tvalid && s_axis_tready &&
                     ((state == ST_STORE_OOO) ||
                      (state == ST_IDLE && !is_expected_in_order && is_future_ooo_frame));
    wire [12:0] ram_wr_addr = {in_slot_idx, wr_word_idx};

    wire [8:0]  next_rd_word_idx = (state == ST_DRAIN_SLOT && m_axis_tvalid && m_axis_tready && !m_axis_tlast) ?
                                   (rd_word_idx + 9'd1) : 9'd0;
    wire [3:0]  rd_slot_mux      = (state == ST_PASS_IN) ? next_exp_slot_idx :
                                   (state == ST_IDLE)    ? exp_slot_idx      : active_slot;
    wire [12:0] ram_rd_addr      = {rd_slot_mux, next_rd_word_idx};
    reg  [31:0] ram_rd_data;

    always @(posedge clk) begin
        if (ram_wr_en) begin
            reorder_ram[ram_wr_addr] <= s_axis_tdata;
        end
        ram_rd_data <= reorder_ram[ram_rd_addr];
    end

    integer k;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state         <= ST_IDLE;
            seq_synced    <= 1'b0;
            expected_txfn <= 16'd1;
            slot_valid    <= {NUM_SLOTS{1'b0}};
            for (k = 0; k < NUM_SLOTS; k = k + 1) slot_txfn[k] <= 16'd0;
            wr_word_idx   <= 9'd0;
            rd_word_idx   <= 9'd0;
            active_slot   <= 4'd0;
            m_axis_tdata  <= 32'd0;
            m_axis_tvalid <= 1'b0;
            m_axis_tlast  <= 1'b0;
        end else begin
            case (state)
                ST_IDLE: begin
                    m_axis_tvalid <= 1'b0;
                    m_axis_tlast  <= 1'b0;
                    wr_word_idx   <= 9'd0;
                    rd_word_idx   <= 9'd0;

                    if (exp_slot_is_ready) begin
                        // Drain buffered frame that matches expected_txfn
                        active_slot   <= exp_slot_idx;
                        rd_word_idx   <= 9'd0;
                        m_axis_tvalid <= 1'b1;
                        m_axis_tlast  <= 1'b0;
                        state         <= ST_DRAIN_SLOT;
                    end else if (s_axis_tvalid) begin
                        if (is_expected_in_order) begin
                            seq_synced    <= 1'b1;
                            expected_txfn <= rx_txfn_in;
                            m_axis_tdata  <= s_axis_tdata;
                            m_axis_tvalid <= 1'b1;
                            m_axis_tlast  <= s_axis_tlast;
                            if (s_axis_tlast) begin
                                expected_txfn <= rx_txfn_in + 16'd1;
                            end else begin
                                state <= ST_PASS_IN;
                            end
                        end else if (is_future_ooo_frame) begin
                            // Out-of-order future frame: store Word 0 into reorder_ram
                            active_slot <= in_slot_idx;
                            wr_word_idx <= 9'd1;
                            state       <= ST_STORE_OOO;
                        end
                    end
                end

                ST_PASS_IN: begin
                    if (s_axis_tvalid && m_axis_tready) begin
                        m_axis_tdata  <= s_axis_tdata;
                        m_axis_tvalid <= 1'b1;
                        m_axis_tlast  <= s_axis_tlast;
                        if (s_axis_tlast) begin
                            expected_txfn <= expected_txfn + 16'd1;
                            if (next_slot_is_ready) begin
                                active_slot <= next_exp_slot_idx;
                                rd_word_idx <= 9'd0;
                                state       <= ST_DRAIN_SLOT;
                            end else begin
                                state       <= ST_IDLE;
                            end
                        end
                    end else if (!s_axis_tvalid && m_axis_tready) begin
                        m_axis_tvalid <= 1'b0;
                        m_axis_tlast  <= 1'b0;
                    end
                end

                ST_STORE_OOO: begin
                    m_axis_tvalid <= 1'b0;
                    m_axis_tlast  <= 1'b0;
                    if (s_axis_tvalid) begin
                        if (s_axis_tlast || (wr_word_idx == WORDS_PER_FRAME - 1)) begin
                            slot_valid[active_slot] <= 1'b1;
                            slot_txfn[active_slot]  <= rx_txfn_in;
                            wr_word_idx             <= 9'd0;
                            state                   <= ST_IDLE;
                        end else begin
                            wr_word_idx <= wr_word_idx + 9'd1;
                        end
                    end
                end

                ST_DRAIN_SLOT: begin
                    m_axis_tvalid <= 1'b1;
                    m_axis_tdata  <= ram_rd_data;
                    m_axis_tlast  <= (rd_word_idx == WORDS_PER_FRAME - 1);

                    if (m_axis_tready) begin
                        if (rd_word_idx == WORDS_PER_FRAME - 1) begin
                            slot_valid[active_slot] <= 1'b0;
                            expected_txfn           <= expected_txfn + 16'd1;
                            m_axis_tvalid           <= 1'b0;
                            m_axis_tlast            <= 1'b0;
                            rd_word_idx             <= 9'd0;
                            state                   <= ST_IDLE;
                        end else begin
                            rd_word_idx <= rd_word_idx + 9'd1;
                        end
                    end
                end
            endcase
        end
    end

endmodule