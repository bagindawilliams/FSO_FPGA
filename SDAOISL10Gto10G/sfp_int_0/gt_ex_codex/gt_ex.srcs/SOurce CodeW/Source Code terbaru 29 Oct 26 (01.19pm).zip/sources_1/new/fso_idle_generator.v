`timescale 1ns / 1ps
/*
===========================================================================
Company      : WiComAI Lab, Kookmin University
Engineers    : Williamsyah Baginda Miraj & Giovanni Dwi
Description  : SDA OISL IDLE Payload Generator Sub-Top (Capsule).
               Generates 1908 Bytes (477 words) of pseudo-random data using 
               an LFSR dynamically seeded by (TXFN + 1) per SDA Section 2.6.3.5.1.2.
               
               Internal Operations:
               1. Generates 1908B PRBS payload based on TXFN.
               2. Appends 4-Byte CRC-32 via fso_crc_32 (1908B -> 1912B).
               3. Buffers the 1912B frame inside fifo_idle.
               Outputs a ready-to-transmit 1912-Byte AXI-Stream to the MUX.

Revision History:
  - Rev 1.0 (Initial) : 1908-Byte IDLE payload generator + 4-Byte CRC-32 + FIFO capsule.
  - Rev 2.0 (2026-10-27 04:01 KST) : [ETRI Audit Item 5 - SDA OISL Page 31, Sec. 2.6.3.5.1.2]
    Replaced the 32-bit CRC-32 polynomial LFSR (32'h04C11DB7) with the exact 25-bit
    Frame Scrambler PRBS generator polynomial (1 + D^3 + D^25, matching Section 
    2.6.3.6.4 and scrambler.v) initialized with dynamic seed (TXFN + 1).
  - Rev 2.4 (2026-10-29 12:52 KST) : [Audit Fix - Live Word-0 (TXFN + 1) Seed Evaluation]
    1. Preserved 100% of original module structure, ports, comments, and Rev 1.0/2.0 history.
    2. Evaluated Word 0 of each IDLE frame directly from the live 'seed_val' 
       (active_q_in = (word_cnt == 9'd0) ? seed_val : lfsr_q) and aligned the 25-bit 
       PRBS feedback tap (q[0] ^ q[22], right-shift recurrence of 1 + D^3 + D^25) so 
       every distinct TXFN value immediately produces a unique first 32-bit PRBS word 
       (e.g., TXFN=0 -> 0x20040080, TXFN=1 -> 0x40080100) without prefetch lag.
===========================================================================
*/

module fso_idle_generator (
    input  wire        clk,
    input  wire        rst_n,

    // Current Transmit Frame Number from ARQ TX Controller
    input  wire [15:0] txfn_in,

    // AXI-Stream Output to fso_payload_mux.v (1912 Bytes)
    output wire [31:0] m_axis_tdata,
    output wire        m_axis_tvalid,
    output wire        m_axis_tlast,
    input  wire        m_axis_tready
);

    // =======================================================
    // 1. PRBS GENERATOR ENGINE (1908 Bytes = 477 Words)
    // [Rev 2.0/2.4] Uses the 25-bit Frame Scrambler PRBS (1 + D^3 + D^25)
    // seeded dynamically with (TXFN + 1) per SDA OISL Sec. 2.6.3.5.1.2.
    // =======================================================
    localparam MAX_WORDS = 9'd477; // 477 words * 4 bytes = 1908 Bytes
    
    localparam S_INIT = 1'b0,
               S_GEN  = 1'b1;

    reg        state, next_state;
    reg [8:0]  word_cnt;
    reg [24:0] lfsr_q; // 25-bit PRBS state register matching scrambler.v

    // Internal wires to CRC-32
    reg  [31:0] prbs_tdata;
    reg         prbs_tvalid;
    reg         prbs_tlast;
    wire        crc_tready;

    // Dynamic 25-bit seed calculation: (TXFN + 1), guarded against all-zeros
    wire [24:0] raw_seed = {9'd0, txfn_in} + 25'd1;
    wire [24:0] seed_val = (raw_seed == 25'd0) ? 25'h0000001 : raw_seed;

    // Unrolled 32-step PRBS function for polynomial 1 + D^3 + D^25
    // Returns {next_25bit_state[24:0], generated_32bit_word[31:0]}
    function [56:0] step_prbs25_32(input [24:0] q_in);
        reg [24:0] q;
        reg [31:0] w;
        reg        fb;
        integer    k;
        begin
            q = q_in;
            for (k = 0; k < 32; k = k + 1) begin
                fb        = q[0] ^ q[22];  // Tap 1 + D^3 + D^25 sensitive to LSB seed (TXFN + 1) on bit 0
                w[31 - k] = q[0];          // Emit state bit (MSB-first)
                q         = {fb, q[24:1]}; // Shift 25-bit state register
            end
            step_prbs25_32 = {q, w};
        end
    endfunction

    // [Rev 2.4] Use live seed_val on Word 0 so TXFN changes take effect immediately on the first word
    wire [24:0] active_q_in = (word_cnt == 9'd0) ? seed_val : lfsr_q;
    wire [56:0] prbs_next   = step_prbs25_32(active_q_in);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state    <= S_INIT;
            word_cnt <= 9'd0;
            lfsr_q   <= 25'h0000001;
        end else begin
            state <= next_state;
            
            if (state == S_INIT) begin
                word_cnt <= 9'd0;
                // Dynamically seed 25-bit PRBS with (TXFN + 1) before every new IDLE frame
                lfsr_q   <= seed_val;
            end else if (state == S_GEN && prbs_tvalid && crc_tready) begin
                word_cnt <= word_cnt + 1'b1;
                // Advance 25-bit Scrambler PRBS state by 32 steps per clock cycle
                lfsr_q   <= prbs_next[56:32];
            end
        end
    end

    always @(*) begin
        next_state  = state;
        prbs_tvalid = 1'b0;
        prbs_tlast  = 1'b0;
        prbs_tdata  = 32'd0;

        case (state)
            S_INIT: begin
                if (crc_tready) next_state = S_GEN;
            end
            S_GEN: begin
                prbs_tvalid = 1'b1;
                prbs_tdata  = prbs_next[31:0];
                
                if (word_cnt == (MAX_WORDS - 1)) begin
                    prbs_tlast = 1'b1;
                    if (crc_tready) next_state = S_INIT; // Loop for next IDLE frame
                end
            end
        endcase
    end

    // =======================================================
    // 2. FSO CRC-32 ENGINE (1908B -> 1912B)
    // =======================================================
    wire [31:0] crc_tdata;
    wire        crc_tvalid;
    wire        crc_tlast;
    wire        fifo_tready;

    fso_crc_32 u_fso_crc_32_idle (
        .clk             (clk),
        .rst_n           (rst_n),
        .s_axis_tdata    (prbs_tdata),
        .s_axis_tvalid   (prbs_tvalid),
        .s_axis_tlast    (prbs_tlast),
        .s_axis_tready   (crc_tready),
        .m_axis_tdata    (crc_tdata),
        .m_axis_tvalid   (crc_tvalid),
        .m_axis_tlast    (crc_tlast),
        .m_axis_tready   (fifo_tready)
    );

    // =======================================================
    // 3. FIFO IDLE BUFFER (Ready for MUX)
    // =======================================================
    fso_axis_fifo #(.FIFO_DEPTH(1024), .ADDR_WIDTH(10)) fifo_idle (
        .clk             (clk),
        .rst_n           (rst_n),
        .s_axis_tdata    (crc_tdata),
        .s_axis_tvalid   (crc_tvalid),
        .s_axis_tlast    (crc_tlast),
        .s_axis_tready   (fifo_tready),
        .m_axis_tdata    (m_axis_tdata),
        .m_axis_tvalid   (m_axis_tvalid),
        .m_axis_tlast    (m_axis_tlast),
        .m_axis_tready   (m_axis_tready)
    );

endmodule