`timescale 1ns / 100ps
/*
===========================================================================
Company      : WiComAI Lab, Kookmin University / ETRI Daejeon
Engineers    : Irzal Zaini & Williamsyah Baginda Miraj
Module Name  : syndrome_unit
Description  : Reed-Solomon Syndrome Computation Unit over GF(2^8).
               Evaluates the incoming codeword at 16 consecutive roots 
               (alpha^0 to alpha^15) over a 256-cycle evaluation window.
               For shortened RS(32,16) headers, the 223 trailing zero cycles 
               automatically shift the codeword roots to align with the 
               Chien search starting position (alpha^-254).

Revision History:
  - Rev 1.0 (Initial) : Syndrome computation for roots alpha^0..alpha^15 over 0x11D.
  - Rev 2.0 (2026-10-27 03:54 KST) : [ETRI Audit Item 2 & 3 - SDA OISL Page 37, Sec. 2.6.3.6.3]
    Updated the 16 syndrome evaluation roots (gf_0..gf_f) to r_k = alpha^((11*(120+k)) % 255)
    for j = 120..135 over GF(2^8) 0x187:
      j=120 (alpha^45)=8'h78, j=121 (alpha^56)=8'h3f, j=122 (alpha^67)=8'hac, j=123 (alpha^78)=8'h13,
      j=124 (alpha^89)=8'h84, j=125 (alpha^100)=8'h06, j=126 (alpha^111)=8'he0, j=127 (alpha^122)=8'h8a,
      j=128 (alpha^133)=8'h9c, j=129 (alpha^144)=8'h88, j=130 (alpha^155)=8'h41, j=131 (alpha^166)=8'h73,
      j=132 (alpha^177)=8'h35, j=133 (alpha^188)=8'h0b, j=134 (alpha^199)=8'h0a, j=135 (alpha^210)=8'ha7.
  - Rev 2.3 (2026-10-29 12:39 KST) : [Audit Fix F10 - Enable Gating Against Invalid Tail Bytes]
    Preserved original module structure and parameter max = 255. Added registered
    enable qualifier 'en_d0' so Q[0..15] updates strictly when en_d0 == 1'b1 and holds
    its evaluated syndrome when en == 0, preventing trailing non-zero bytes on data_in
    from corrupting the syndrome.
===========================================================================
*/

module syndrome_unit # (parameter max = 255) (
    input           clk,
    input           rst_n,
    input           en,
    input   [7:0]   data_in,
    output          flag,
    output  [127:0] syndrome
);

    reg     [7:0]   count   = 8'd0;

    localparam  IDLE        = 3'b001;
    localparam  ACTIVE      = 3'b010;
    localparam  END         = 3'b100;

    reg     [2:0]   state;
    reg     [2:0]   next_state;

    reg     [7:0]   data_d0;
    reg             en_d0;

    reg     [7:0]   Q   [0:15];
    wire    [7:0]   D   [0:15];
    wire    [7:0]   R   [0:15];

    always @(posedge clk or negedge rst_n) begin
        if (~rst_n)
            state   <= IDLE;
        else
            state   <= next_state;
    end

    always @(posedge clk or negedge rst_n) begin
        if (~rst_n)
            count   <= 8'd0;
        else if (state == ACTIVE)
            count   <= count + 1'b1;
        else
            count   <= 8'd0;
    end

    always @(*) begin
        case(state)
            IDLE:   begin
                        if (en) next_state <= ACTIVE;
                        else    next_state <= IDLE;
                    end
            ACTIVE: begin
                        if (count < max)    next_state <= ACTIVE;
                        else                next_state <= END;
                    end
            END:    begin
                        next_state <= IDLE;
                    end
            default:next_state <= IDLE;
        endcase
    end

    always @(posedge clk or negedge rst_n) begin
        if (~rst_n) begin
            data_d0 <= 8'b0;
            en_d0   <= 1'b0;
        end else begin
            data_d0 <= en ? data_in : 8'b0;
            en_d0   <= en;
        end
    end

    reg [7:0] i;
    always @(posedge clk or negedge rst_n) begin
        if (~rst_n) begin
            for (i = 0; i < 16; i = i + 1)
                Q[i] <= 8'b0;
        end
        else if (state == IDLE) begin
            if (en) begin
                for (i = 0; i < 16; i = i + 1)
                    Q[i] <= 8'b0;
            end
        end
        else if ((state == ACTIVE || state == END) && en_d0) begin
            for (i = 0; i < 16; i = i + 1)
                Q[i] <= D[i];
        end
    end

    // [Rev 2.0 - 2026-10-27 03:54 KST] Updated to SDA OISL v2.1.2 Page 37
    // roots r_k = alpha^((11*(120+k)) mod 255) over GF(2^8) 0x187:
    multiplier gf_0 (8'h78, Q[0],  R[0]);
    multiplier gf_1 (8'h3f, Q[1],  R[1]);
    multiplier gf_2 (8'hac, Q[2],  R[2]);
    multiplier gf_3 (8'h13, Q[3],  R[3]);
    multiplier gf_4 (8'h84, Q[4],  R[4]);
    multiplier gf_5 (8'h06, Q[5],  R[5]);
    multiplier gf_6 (8'he0, Q[6],  R[6]);
    multiplier gf_7 (8'h8a, Q[7],  R[7]);
    multiplier gf_8 (8'h9c, Q[8],  R[8]);
    multiplier gf_9 (8'h88, Q[9],  R[9]);
    multiplier gf_a (8'h41, Q[10], R[10]);
    multiplier gf_b (8'h73, Q[11], R[11]);
    multiplier gf_c (8'h35, Q[12], R[12]);
    multiplier gf_d (8'h0b, Q[13], R[13]);
    multiplier gf_e (8'h0a, Q[14], R[14]);
    multiplier gf_f (8'ha7, Q[15], R[15]);

    assign  D[0]  = R[0]  ^ data_d0;
    assign  D[1]  = R[1]  ^ data_d0;
    assign  D[2]  = R[2]  ^ data_d0;
    assign  D[3]  = R[3]  ^ data_d0;
    assign  D[4]  = R[4]  ^ data_d0;
    assign  D[5]  = R[5]  ^ data_d0;
    assign  D[6]  = R[6]  ^ data_d0;
    assign  D[7]  = R[7]  ^ data_d0;
    assign  D[8]  = R[8]  ^ data_d0;
    assign  D[9]  = R[9]  ^ data_d0;
    assign  D[10] = R[10] ^ data_d0;
    assign  D[11] = R[11] ^ data_d0;
    assign  D[12] = R[12] ^ data_d0;
    assign  D[13] = R[13] ^ data_d0;
    assign  D[14] = R[14] ^ data_d0;
    assign  D[15] = R[15] ^ data_d0;

    assign  syndrome = en_d0 ?
                       {D[0], D[1], D[2], D[3], D[4], D[5], D[6], D[7], D[8], D[9], D[10], D[11], D[12], D[13], D[14], D[15]} :
                       {Q[0], Q[1], Q[2], Q[3], Q[4], Q[5], Q[6], Q[7], Q[8], Q[9], Q[10], Q[11], Q[12], Q[13], Q[14], Q[15]};
    assign  flag     = (state == END);

endmodule